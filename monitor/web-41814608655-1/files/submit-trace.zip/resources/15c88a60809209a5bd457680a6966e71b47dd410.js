import {
  BUSY_JS,
  InMemoryStorage,
  LABELS,
  PRIMARY_COLOR_JS,
  RESOLVE_LOCALE_JS,
  REVEAL_TIMEOUT_MS,
  RTL_LOCALES,
  STORAGE_KEYS,
  SUBMIT_ERROR_JS,
  SUPPORTED_LANGUAGES,
  TrackingManager,
  buildFontFaceCss,
  buildFontFamilyValue,
  buildSurveyIdentity,
  createDefaultStorage,
  directionFor,
  getLabels,
  isRtlLanguage,
  resolveActionLabels,
  resolveLocale,
  sdkWarn,
  setLogger,
  style_default
} from "./chunk-DNBFTJCA.mjs";

// src/types/index.ts
var POPUP_TRIGGER_CONDITION_STATUSES = [
  "SHOWED",
  "PARTIAL",
  "COMPLETED"
];

// src/triggers/index.ts
function toNumericValue(value, fallback) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}
function setupTrigger(popups, trigger) {
  switch (trigger.type) {
    case "time":
      setupTimeTrigger(popups, trigger);
      break;
    case "scroll":
      setupScrollTrigger(popups, trigger);
      break;
    case "exit":
      setupExitTrigger(popups, trigger);
      break;
    case "event":
      setupEventTrigger(popups, trigger);
      break;
    case "click":
      setupClickTrigger(popups, trigger);
      break;
  }
}
function setupTimeTrigger(popups, trigger) {
  const delay = toNumericValue(trigger.value, 5e3);
  setTimeout(() => {
    popups.triggerSurvey(trigger.surveyId, trigger.popupId);
  }, delay);
  popups.debug(`Time trigger set for ${delay}ms`);
}
function setupScrollTrigger(popups, trigger) {
  const threshold = toNumericValue(trigger.value, 50);
  const handler = () => {
    const scrollPercentage = window.scrollY / (document.documentElement.scrollHeight - window.innerHeight) * 100;
    if (scrollPercentage >= threshold) {
      popups.triggerSurvey(trigger.surveyId, trigger.popupId);
      window.removeEventListener("scroll", handler);
    }
  };
  window.addEventListener("scroll", handler);
  popups.debug(`Scroll trigger set for ${threshold}%`);
}
function setupExitTrigger(popups, trigger) {
  if (typeof window === "undefined") return;
  const delaySeconds = parseExitDelaySeconds(trigger.value);
  const historyRef = window.history;
  const originalPushState = historyRef.pushState.bind(historyRef);
  const originalReplaceState = historyRef.replaceState.bind(historyRef);
  let lastUrl = normalizeUrl(window.location.href);
  let lastQueuedKey = "";
  let lastQueuedAt = 0;
  const queueLeave = (fromRaw, toRaw) => {
    const from = normalizeUrl(fromRaw);
    const to = normalizeUrl(toRaw);
    if (!from || !to || from === to) return;
    const key = `${from}=>${to}`;
    const now = Date.now();
    if (key === lastQueuedKey && now - lastQueuedAt < 150) return;
    lastQueuedKey = key;
    lastQueuedAt = now;
    popups.queueExitPopup(trigger.surveyId, delaySeconds, from, trigger.popupId);
  };
  const handleNavigation = (to) => {
    const from = lastUrl;
    queueLeave(from, to);
    lastUrl = normalizeUrl(to);
  };
  const handleDocumentClick = (event) => {
    if (event.defaultPrevented) return;
    if (event.button !== 0) return;
    if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    const anchor = event.target?.closest?.("a");
    if (!(anchor instanceof HTMLAnchorElement)) return;
    const href = anchor.getAttribute("href");
    if (!href || href.startsWith("javascript:") || href.startsWith("mailto:") || href.startsWith("tel:")) {
      return;
    }
    const target = anchor.getAttribute("target");
    if (target && target !== "_self") return;
    let destination;
    try {
      destination = new URL(href, window.location.href);
    } catch {
      return;
    }
    if (destination.origin !== window.location.origin) return;
    queueLeave(window.location.href, destination.href);
  };
  const handleHashChange = (event) => {
    const to = event.newURL || window.location.href;
    const from = event.oldURL || lastUrl;
    queueLeave(from, to);
    lastUrl = normalizeUrl(to);
  };
  const handlePopState = () => {
    handleNavigation(window.location.href);
  };
  historyRef.pushState = function(data, unused, url) {
    const from = window.location.href;
    const result = originalPushState(data, unused, url);
    queueLeave(from, window.location.href);
    lastUrl = normalizeUrl(window.location.href);
    return result;
  };
  historyRef.replaceState = function(data, unused, url) {
    const from = window.location.href;
    const result = originalReplaceState(data, unused, url);
    queueLeave(from, window.location.href);
    lastUrl = normalizeUrl(window.location.href);
    return result;
  };
  document.addEventListener("click", handleDocumentClick, true);
  window.addEventListener("hashchange", handleHashChange);
  window.addEventListener("popstate", handlePopState);
  popups.debug("Exit trigger set (deferred to next route)", {
    surveyId: trigger.surveyId,
    delaySeconds
  });
}
function setupEventTrigger(popups, trigger) {
  popups.debug("Event trigger registered", {
    popupId: trigger.popupId,
    surveyId: trigger.surveyId,
    eventName: String(trigger.value || "")
  });
}
function parseExitDelaySeconds(value) {
  if (typeof value === "number" && Number.isFinite(value)) {
    return Math.max(0, value);
  }
  if (typeof value === "string" && value.trim()) {
    const parsed = Number(value);
    if (Number.isFinite(parsed)) return Math.max(0, parsed);
  }
  return 0;
}
function normalizeUrl(value) {
  if (!value) return "";
  const withoutIndex = value.replace(/\/index\.html(?=($|[?#]))/i, "");
  return withoutIndex.length > 1 && withoutIndex.endsWith("/") ? withoutIndex.slice(0, -1) : withoutIndex;
}
function setupClickTrigger(popups, trigger) {
  const targetId = typeof trigger.value === "string" ? trigger.value : "";
  if (!targetId) {
    popups.debug("Click trigger missing element id", trigger);
    return;
  }
  const attach = () => {
    const el = document.getElementById(targetId);
    if (!el) {
      popups.debug("Click trigger target not found", targetId);
      return false;
    }
    const handler = (e) => {
      if (e.defaultPrevented) return;
      popups.triggerSurvey(trigger.surveyId, trigger.popupId);
      el.removeEventListener("click", handler);
    };
    el.addEventListener("click", handler);
    popups.debug(`Click trigger set for #${targetId}`);
    return true;
  };
  if (typeof document === "undefined") return;
  if (attach()) return;
  window.addEventListener("DOMContentLoaded", () => attach(), { once: true });
}

// src/config/env.ts
var ENVIRONMENT_MAP = {
  development: {
    apiBaseUrl: "https://api-dev.deepdots.com"
  },
  production: {
    apiBaseUrl: "https://api.deepdots.com"
  }
};
function resolveEnvironment(nodeEnv) {
  return ENVIRONMENT_MAP[nodeEnv || "production"];
}

// src/ui/surveyHtml.ts
var REVEAL_JS = `
function ddCreateReveal(popup, onReveal, timeoutMs){
  var revealed=false, timer=null;
  function reveal(){
    if(revealed){ return; }
    revealed=true;
    if(timer){ clearTimeout(timer); timer=null; }
    onReveal();
  }
  function revealWhenPainted(){
    if(revealed){ return; }
    var imgs=popup.querySelectorAll('img'), pending=[];
    for(var i=0;i<imgs.length;i++){ if(!imgs[i].complete){ pending.push(imgs[i]); } }
    if(!pending.length){ reveal(); return; }
    var left=pending.length;
    function onSettled(){ left--; if(left<=0){ reveal(); } }
    for(var j=0;j<pending.length;j++){
      pending[j].addEventListener('load', onSettled);
      pending[j].addEventListener('error', onSettled);
    }
  }
  timer=setTimeout(reveal, timeoutMs);
  return { reveal: reveal, whenPainted: revealWhenPainted };
}`;
var POSITION_MAP = {
  center: { justifyContent: "center", alignItems: "center", padding: "0", background: "rgba(0,0,0,0.5)" },
  bottom: { justifyContent: "center", alignItems: "flex-end", padding: "16px", background: "transparent" },
  "bottom-right": { justifyContent: "flex-end", alignItems: "flex-end", padding: "16px", background: "transparent" },
  "bottom-left": { justifyContent: "flex-start", alignItems: "flex-end", padding: "16px", background: "transparent" },
  top: { justifyContent: "center", alignItems: "flex-start", padding: "16px", background: "transparent" },
  "top-right": { justifyContent: "flex-end", alignItems: "flex-start", padding: "16px", background: "transparent" },
  "top-left": { justifyContent: "flex-start", alignItems: "flex-start", padding: "16px", background: "transparent" }
};
function jsonForScript(value) {
  return JSON.stringify(value ?? null).replace(/</g, "\\u003C").replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");
}
function trimmedOrNull(value) {
  const trimmed = typeof value === "string" ? value.trim() : "";
  return trimmed ? value : null;
}
function buildSurveyHtml(opts) {
  const env = opts.env === "development" ? "dev" : "prod";
  const version = opts.version ?? "2.2.37";
  const cdn = `https://cdn.jsdelivr.net/npm/@magicfeedback/native@${version}/dist/magicfeedback-sdk.browser.js`;
  const sid = jsonForScript(opts.surveyId);
  const pid = jsonForScript(opts.productId);
  const profileJson = jsonForScript(opts.profile ?? []);
  const metaJson = jsonForScript(opts.metadata ?? []);
  const fontFaceCss = opts.font ? buildFontFaceCss(opts.font.family, opts.font.url) : "";
  const fontFamilyValue = opts.font ? buildFontFamilyValue(opts.font.family) : "-apple-system,system-ui,sans-serif";
  const popupClass = opts.font?.family ? "deepdots-popup deepdots-has-font" : "deepdots-popup";
  const isDark = opts.theme === "dark";
  const popupBg = isDark ? "#1e1e1e" : "#fff";
  const colorScheme = isDark ? "dark" : "light";
  const textPrimary = isDark ? "#f0f0f0" : "#111";
  const textMuted = isDark ? "#9ca3af" : "#6b7280";
  const trackBg = isDark ? "#3f3f46" : "#e5e7eb";
  const pos = POSITION_MAP[opts.position ?? "center"] ?? POSITION_MAP.center;
  const chrome = opts.chrome !== false;
  const bodyBg = chrome ? pos.background : "transparent";
  const bodyPadding = chrome ? pos.padding : "0";
  const bodyDisplay = chrome ? "flex" : "block";
  const cardBg = chrome ? popupBg : "transparent";
  const cardShadow = chrome ? "0 4px 6px rgba(0,0,0,0.1)" : "none";
  const cardRadius = chrome ? "8px" : "0";
  const cardMaxWidth = chrome ? "600px" : "none";
  const cardWidth = chrome ? "90%" : "100%";
  const cardMinHeight = chrome ? "200px" : "0";
  const cardHeight = chrome ? "auto" : "100%";
  const cardMaxHeight = chrome ? "90vh" : "100%";
  const mobileCard = chrome ? `.deepdots-popup{width:calc(100% - 24px);max-width:calc(100% - 24px);border-radius:12px;padding:calc(16px + env(safe-area-inset-top)) 16px calc(16px + env(safe-area-inset-bottom)) 16px}` : `.deepdots-popup{width:100%;max-width:100%;border-radius:0;padding:16px}`;
  const titleJson = jsonForScript(opts.title ?? "");
  const customCss = (opts.surveyCss ?? "").replace(/<\/\s*style/gi, "<\\/style");
  const progressPref = opts.showProgressBar === void 0 ? "null" : String(opts.showProgressBar);
  const initLabels = getLabels(opts.language);
  const initActionLabels = resolveActionLabels(opts.actions, opts.language);
  const backLabel = jsonForScript(initActionLabels.back);
  const startLabel = jsonForScript(initActionLabels.start);
  const completeLabel = jsonForScript(initActionLabels.complete);
  const submitLabel = jsonForScript(initActionLabels.accept);
  const cancelLabel = jsonForScript(initActionLabels.decline);
  const labelsTableJson = jsonForScript(LABELS);
  const actionOverridesJson = jsonForScript({
    accept: trimmedOrNull(opts.actions?.accept?.label),
    start: trimmedOrNull(opts.actions?.start?.label),
    complete: trimmedOrNull(opts.actions?.complete?.label),
    back: trimmedOrNull(opts.actions?.back?.label),
    decline: trimmedOrNull(opts.actions?.decline?.label)
  });
  const initLangJson = jsonForScript(opts.language ?? "");
  const initDirection = directionFor(opts.language);
  const rtlLocalesJson = jsonForScript(RTL_LOCALES);
  return `<!DOCTYPE html><html><head>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<meta name="color-scheme" content="${colorScheme}"/>
<style>
${style_default}
${fontFaceCss}
html,body{margin:0;padding:0;height:100%;font-family:${fontFamilyValue}}
/* Apertura diferida: ni la tarjeta ni el velo se pintan hasta que el survey est\xE1 listo
   (\`dd-ready\`). Si el fondo entrara antes, en RN se ver\xEDa el velo oscuro varios cientos de ms
   antes que el contenido, que es la misma mala sensaci\xF3n que el spinner. */
body{display:${bodyDisplay};justify-content:${pos.justifyContent};align-items:${pos.alignItems};background:transparent;padding:${bodyPadding};box-sizing:border-box}
body.dd-ready{background:${bodyBg}}
#dd-popup{visibility:hidden}
body.dd-ready #dd-popup{visibility:visible}
.deepdots-popup{position:relative;display:flex;flex-direction:column;justify-content:flex-start;background:${cardBg};color-scheme:${colorScheme};border-radius:${cardRadius};padding:24px;box-shadow:${cardShadow};max-width:${cardMaxWidth};width:${cardWidth};min-height:${cardMinHeight};height:${cardHeight};max-height:${cardMaxHeight};box-sizing:border-box}
.deepdots-popup-header{display:flex;justify-content:space-between;align-items:center;gap:12px;width:100%;flex:0 0 auto}
/* Neutraliza la regla \`.deepdots-popup h2\` del CSS del survey (uppercase, centrado y
   margin-bottom 40px), pensada para los enunciados y no para el t\xEDtulo de la cabecera. */
#dd-title{margin:0;font-family:var(--deepdots-font,'Montserrat',inherit);font-size:17px;font-weight:600;line-height:1.3;color:${textPrimary};text-transform:none;text-align:start;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
#dd-close{background:transparent;border:none;width:32px;height:32px;display:flex;align-items:center;justify-content:center;border-radius:8px;cursor:pointer;color:${textPrimary};padding:4px;flex:0 0 auto;margin-inline-start:auto}
/* Progreso alineado con la cabecera: sin padding horizontal propio, lo marca la tarjeta.
   El vertical es el mismo arriba y abajo, y del mismo valor que el padding de la tarjeta. */
.deepdots-progress{display:none;flex-direction:column;gap:8px;width:100%;flex:0 0 auto;padding:16px 0;box-sizing:border-box}
.deepdots-progress-head{display:flex;flex-direction:row;justify-content:space-between;align-items:center;width:100%;gap:8px}
#dd-progress-label{font-size:13px;line-height:1.2}
/* "Question 1" en negrita y "of 3" en regular gris, como el mockup. */
#dd-progress-current{font-weight:700;color:${textPrimary}}
#dd-progress-total{font-weight:400;color:${textMuted}}
#dd-progress-followup{display:none;font-size:12px;font-weight:600;color:#fff;background:rgba(59,130,246,0.44);border-radius:999px;padding:2px 10px}
.deepdots-progress-track{width:100%;height:4px;border-radius:999px;background:${trackBg};overflow:hidden}
#dd-progress-bar{height:100%;width:0%;background:#22C55E;border-radius:999px;transition:width 450ms ease}
/* El popup es una columna: solo el bloque de preguntas hace scroll, para que el footer
   con las acciones quede siempre visible en el borde inferior (antes viv\xEDa dentro del
   \xE1rea scrollable y hab\xEDa que bajar hasta el final para ver "Send"). */
/* Sin sangrado extra: el contenido se alinea con el t\xEDtulo y con la barra de progreso (antes
   sumaba 20px a los lados sobre el padding de la tarjeta y quedaba m\xE1s adentro que la cabecera). */
/* Sin barra de progreso, este padding-top es el que separa la cabecera de la pregunta. Con
   barra, el JS lo pone a 0 y el hueco lo aporta el padding inferior del bloque de progreso,
   de modo que el espacio por arriba y por abajo de la barra es id\xE9ntico. */
.deepdots-popup-container-content{display:flex;flex-direction:column;flex:1 1 auto;min-height:0;padding:16px 0 0 0;overflow:hidden;box-sizing:border-box}
/* El enunciado trae margin-top:20px del CSS de surveys, que sumaba al hueco de la barra y
   descompensaba la simetr\xEDa. Solo se anula en el primero: entre preguntas sigue separando. */
.deepdots-popup .magicfeedback-questions .magicfeedback-div:first-child .magicfeedback-label{margin-top:0}
.deepdots-popup-main{display:flex;flex-direction:column;width:100%;flex:1 1 auto;min-height:0;overflow-y:auto;overflow-x:hidden;position:relative}
#dd-form-wrapper{width:100%;flex:1 1 auto}
#mf{width:100%;box-sizing:border-box;visibility:hidden}
.deepdots-popup-main *{max-width:100%;box-sizing:border-box}
/* El margen lateral lo pone la tarjeta: el CSS del survey lo a\xF1ade otra vez en el contenedor, en
   el formulario y en el bloque de cada pregunta, y eso deja el enunciado y las opciones m\xE1s
   adentro que el logo, el t\xEDtulo y la barra de progreso. Solo el lateral; el vertical separa las
   preguntas. Mismas reglas que en el popup DOM (renderPopup.ts). */
.deepdots-popup .magicfeedback-container,
.deepdots-popup .magicfeedback-form,
.deepdots-popup .magicfeedback-div{padding-left:0;padding-right:0}
#dd-logo{max-height:40px;max-width:100%;object-fit:contain;display:block;margin:12px 0 0 0}
.deepdots-error-hint{display:none;margin:12px 0 0 0;padding:10px 12px;border-radius:6px;background:#FEF3C7;color:#92400E;border:1px solid #FCD34D;font-size:13px}
/* Pantalla final: el HTML del editor de la plataforma (imagen + texto), centrado. */
.deepdots-load-error{display:none;width:100%;text-align:center;padding:24px 0;font-size:15px;color:${textPrimary}}
.deepdots-success{display:none;width:100%;text-align:center;padding:24px 0;color:${textPrimary}}
.deepdots-success img{max-width:100%;height:auto;margin:0 auto 16px auto;display:block}
.deepdots-success p{margin:0;font-size:16px;font-weight:600;line-height:1.4}
.deepdots-popup-footer{display:flex;flex-direction:row-reverse;justify-content:space-between;align-items:center;gap:4px;margin-top:auto;width:100%;padding-top:12px}
.dd-nav-btn{display:none;border:none;min-height:44px;padding:12px 24px;border-radius:999px;cursor:pointer;font-size:15px;font-weight:600;align-items:center;justify-content:center;text-align:center}
/* Secundario como bot\xF3n de texto: sin borde ni fondo, para que el primario sea la \xFAnica CTA. */
#dd-back{background:transparent;color:${textMuted};border:none}
#dd-start,#dd-complete,#dd-submit,#dd-cancel{background:#1E293B;color:#fff;border:none}
#dd-submit:disabled,#dd-start:disabled,#dd-back:disabled,#dd-complete:disabled{opacity:0.6;cursor:not-allowed}
.mf-spinner{display:none;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%)}
.mf-spinner-circle{width:28px;height:28px;border:3px solid #e0e6ed;border-top-color:#1E293B;border-radius:50%;animation:ddspin 0.9s linear infinite}
@keyframes ddspin{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}
@media (max-width:640px){
  ${mobileCard}
  /* Apilados: la acci\xF3n principal (Send/Start/Complete) arriba y Back debajo. El orden del
     DOM ya es ese, as\xED que \`column\` (no \`column-reverse\`) es lo que lo respeta. */
  .deepdots-popup-footer{flex-direction:column;gap:4px}
  .dd-nav-btn{width:100%}
  .magicfeedback-checkbox-container,.magicfeedback-radio-container{margin:4px 0;padding:4px 8px}
  .magicfeedback-checkbox label,.magicfeedback-radio-container label{font-size:15px}
  .deepdots-popup input[type="radio"]{margin:6px 0 6px 8px}
  .deepdots-popup input[type="checkbox"]{width:16px;height:16px}
}
${customCss}
</style>
</head><body>
<div class="${popupClass}" id="dd-popup" dir="${initDirection}">
  <div class="deepdots-popup-header">
    <h2 id="dd-title" class="deepdots-popup-title" hidden></h2>
    <button type="button" id="dd-close" aria-label="${initLabels.closeAria}">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M5 5L19 19M5 19L19 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="butt"/>
      </svg>
    </button>
  </div>
  <div class="deepdots-progress" id="dd-progress">
    <div class="deepdots-progress-head">
      <span id="dd-progress-label"><span id="dd-progress-current"></span><span id="dd-progress-total"></span></span>
      <span id="dd-progress-followup">${initLabels.followUp}</span>
    </div>
    <div class="deepdots-progress-track"><div id="dd-progress-bar"></div></div>
  </div>
  <div class="deepdots-popup-container-content" id="dd-content">
    <div class="deepdots-popup-main" id="dd-main">
      <div id="dd-form-wrapper">
        <div class="mf-spinner" id="dd-spinner" role="status" aria-label="${initLabels.loadingAria}"><div class="mf-spinner-circle"></div></div>
        <div id="mf"></div>
      </div>
      <div class="deepdots-load-error" id="dd-load-error" role="alert"></div>
      <div class="deepdots-error-hint" id="dd-error" role="alert" aria-live="polite"></div>
    </div>
    <div class="deepdots-popup-footer" id="dd-footer">
      <button type="button" class="dd-nav-btn" id="dd-submit"></button>
      <button type="button" class="dd-nav-btn" id="dd-back"></button>
      <button type="button" class="dd-nav-btn" id="dd-complete"></button>
      <button type="button" class="dd-nav-btn" id="dd-start"></button>
      <button type="button" class="dd-nav-btn" id="dd-cancel"></button>
    </div>
  </div>
</div>
<script>
(function(){
  function emit(s){ try{ if(window.ReactNativeWebView){ window.ReactNativeWebView.postMessage(s); } }catch(e){} }
  function emitJSON(n,p){ try{ emit(JSON.stringify({name:n,payload:p||{}})); }catch(e){} }
  var ddLastReportedError=null;
  window.DeepdotsClose = function(){ emitJSON('popup_close'); };
  var chromeOn=${chrome ? "true" : "false"};

  var popup=document.getElementById('dd-popup');
  var main=document.getElementById('dd-main');
  var content=document.getElementById('dd-content');
  var footer=document.getElementById('dd-footer');
  var spinner=document.getElementById('dd-spinner');
  var formHost=document.getElementById('mf');
  var formWrapper=document.getElementById('dd-form-wrapper');
  var errorHint=document.getElementById('dd-error');
  var backBtn=document.getElementById('dd-back');
  var startBtn=document.getElementById('dd-start');
  var completeBtn=document.getElementById('dd-complete');
  var submitBtn=document.getElementById('dd-submit');
  var cancelBtn=document.getElementById('dd-cancel');
  var loadErrorEl=document.getElementById('dd-load-error');
  var titleEl=document.getElementById('dd-title');
  var progressEl=document.getElementById('dd-progress');
  var progressLabel=document.getElementById('dd-progress-label');
  var progressCurrent=document.getElementById('dd-progress-current');
  var progressTotal=document.getElementById('dd-progress-total');
  var progressFollowUp=document.getElementById('dd-progress-followup');
  var progressBar=document.getElementById('dd-progress-bar');
  var closeEl=document.getElementById('dd-close');

  // --- i18n del chrome -------------------------------------------------------------------
  // La tabla completa viaja embebida porque el idioma del survey (\`formData.lang[0]\`) solo se
  // conoce ya dentro del WebView. \`ddResolveLocale\` es el espejo del \`resolveLocale\` de TS
  // (paridad cubierta por test).
  var DD_LABELS=${labelsTableJson};
  var DD_ACTION_OVERRIDES=${actionOverridesJson};
  ${RESOLVE_LOCALE_JS}
  var DD_LABELS_ACTIVE=DD_LABELS[ddResolveLocale(${initLangJson})];
  var DD_RTL=${rtlLocalesJson};
  function ddIsRtl(lang){ return DD_RTL.indexOf(ddResolveLocale(lang))!==-1; }
  function ddApplyLabels(lang){
    var next=DD_LABELS[ddResolveLocale(lang)];
    if(!next) return;
    DD_LABELS_ACTIVE=next;
    // El survey ya se ha volteado a s\xED mismo: el chrome tiene que acompa\xF1arlo.
    popup.setAttribute('dir', ddIsRtl(lang) ? 'rtl' : 'ltr');
    backBtn.textContent=DD_ACTION_OVERRIDES.back||next.back;
    startBtn.textContent=DD_ACTION_OVERRIDES.start||next.start;
    completeBtn.textContent=DD_ACTION_OVERRIDES.complete||next.complete;
    submitBtn.textContent=DD_ACTION_OVERRIDES.accept||next.accept;
    cancelBtn.textContent=DD_ACTION_OVERRIDES.decline||next.decline;
    loadErrorEl.textContent=next.errorLoad;
    if(closeEl){ closeEl.setAttribute('aria-label',next.closeAria); }
    if(spinner){ spinner.setAttribute('aria-label',next.loadingAria); }
    progressFollowUp.textContent=next.followUp;
  }

  function setTitle(t){
    if(!t) return;
    titleEl.textContent=t;
    titleEl.hidden=false;
  }
  setTitle(${titleJson});

  // Estado de la barra de progreso. \`progressPref\` null = manda la plataforma (style).
  var progressPref=${progressPref};
  var progressEnabled=progressPref===true;
  var progressShowUnit=true;
  var progressUnit='fraction';
  var onStartPage=false;

  function updateProgress(p){
    var total=p&&typeof p.total==='number'?p.total:0;
    var progress=p&&typeof p.progress==='number'?p.progress:0;
    // Solo tiene sentido con m\xE1s de una p\xE1gina, fuera de la pantalla de inicio y sin completar.
    if(!progressEnabled||onStartPage||p&&p.completed||total<=1){
      progressEl.style.display='none';
      // Sin barra, el hueco cabecera\u2192pregunta lo pone el contenido.
      content.style.paddingTop='16px';
      return;
    }
    progressEl.style.display='flex';
    // Con barra, el hueco inferior ya lo pone el bloque de progreso: no duplicarlo.
    content.style.paddingTop='0';
    // Espejo de LineProgressQuestion (MagicSurvey): la barra usa el valor real (las follow-up
    // suman +0.5 y avanzan media casilla) y la etiqueta redondea hacia abajo, porque una
    // follow-up es un paso DENTRO de la misma pregunta, no la siguiente.
    var current=Math.min(total,Math.max(1,progress+1));
    var pct=Math.min(100,Math.max(0,(current/total)*100));
    progressBar.style.width=pct+'%';
    var label=Math.min(total,Math.max(1,Math.floor(progress)+1));
    progressLabel.style.display=progressShowUnit?'block':'none';
    if(progressUnit==='percentage'){
      progressCurrent.textContent=Math.round(pct)+'%';
      progressTotal.textContent='';
    } else {
      progressCurrent.textContent=DD_LABELS_ACTIVE.question+' '+label;
      progressTotal.textContent=' '+DD_LABELS_ACTIVE.of+' '+total;
    }
    progressFollowUp.style.display=p&&p.followup?'inline-block':'none';
  }

  backBtn.textContent=${backLabel};
  startBtn.textContent=${startLabel};
  completeBtn.textContent=${completeLabel};
  submitBtn.textContent=${submitLabel};
  cancelBtn.textContent=${cancelLabel};

  closeEl.onclick=function(){ emitJSON('popup_close'); };
  backBtn.onclick=function(){ if(window.DeepdotsForm && window.DeepdotsForm.back){ window.DeepdotsForm.back(); } };
  startBtn.onclick=function(){
    if(window.DeepdotsForm && window.DeepdotsForm.startForm){
      window.DeepdotsForm.startForm();
      onStartPage=false;
      updateProgress({ progress:window.DeepdotsForm.progress, total:window.DeepdotsForm.total, completed:false, followup:false });
    }
  };
  completeBtn.onclick=function(){ emitJSON('popup_close'); };
  // \xDAnica acci\xF3n del survey que no carga: cierra igual que la X.
  cancelBtn.onclick=function(){ emitJSON('popup_close'); };
  var surveyCompletedEmitted=false;
  submitBtn.onclick=function(){
    if(surveyCompletedEmitted) return;
    if(window.DeepdotsForm && window.DeepdotsForm.send){ window.DeepdotsForm.send(); }
  };

  // Mensaje final configurado en la plataforma (\`style.successMessage\`). Se guarda al cargar
  // y se pinta al completar. Va por innerHTML porque es HTML del editor de la plataforma
  // (imagen + texto), igual que ya hace \`renderStartMessage\` con el mensaje de inicio.
  var successMessageHtml='';
  function showSuccessScreen(){
    progressEl.style.display='none';
    var wrapper=document.getElementById('dd-form-wrapper');
    if(wrapper){ wrapper.style.display='none'; }
    var done=document.getElementById('dd-success');
    if(!done){
      done=document.createElement('div');
      done.id='dd-success';
      done.className='deepdots-success';
      main.insertBefore(done, errorHint);
    }
    done.innerHTML=successMessageHtml || '<p>Thank you for your feedback!</p>';
    done.style.display='block';
  }

  // Profundidad de navegaci\xF3n DENTRO del survey: +1 por p\xE1gina avanzada, -1 al volver.
  // Sustituye a la condici\xF3n \`total>1 && progress>0 && progress<total\`, que escond\xEDa el
  // Back siempre que la siguiente pantalla era una follow-up din\xE1mica: las follow-up no
  // entran en el grafo (suman +0.5 al progress y no tocan el total), as\xED que un survey de
  // una pregunta con follow-up tiene total=1 y nunca cumpl\xEDa \`total>1\`.
  var pageDepth=0;

  function updateNavButtons(){
    updateButtons(pageDepth>0?'in_progress_next':'in_progress_first');
  }

  function updateButtons(state){
    backBtn.style.display='none';
    startBtn.style.display='none';
    submitBtn.style.display='none';
    completeBtn.style.display='none';
    cancelBtn.style.display='none';
    backBtn.style.width='';
    startBtn.style.width='';
    submitBtn.style.width='';
    completeBtn.style.width='';
    if(state==='start'){
      startBtn.style.display='inline-flex';
      startBtn.style.width='100%';
    } else if(state==='in_progress_first'){
      submitBtn.style.display='inline-flex';
    } else if(state==='in_progress_next'){
      backBtn.style.display='inline-flex';
      submitBtn.style.display='inline-flex';
    } else if(state==='completed'){
      completeBtn.style.display='inline-flex';
      completeBtn.style.width='100%';
    } else if(state==='load_error'){
      cancelBtn.style.display='inline-flex';
    }
  }

${PRIMARY_COLOR_JS}
${BUSY_JS}
${SUBMIT_ERROR_JS}
${REVEAL_JS}
  // Foco en la primera pregunta si es de escribir. Al navegar lo pone @magicfeedback/native
  // (autofocus:'navigation'); la apertura la decide el popup, que es quien sabe cu\xE1ndo se revela.
  // Necesita el popup revelado y el survey cargado, que llegan en cualquier orden, y solo con
  // rat\xF3n o trackpad: en t\xE1ctil sacar\xEDa el teclado sin que el usuario haya tocado nada.
  var ddRevealed=false, ddSurveyLoaded=false, ddOpenFocusDone=false;
  function ddAutofocusOnOpen(){
    if(ddOpenFocusDone || !ddRevealed || !ddSurveyLoaded){ return; }
    ddOpenFocusDone=true;
    var fine=typeof window.matchMedia==='function' && window.matchMedia('(pointer: fine)').matches;
    var f=window.DeepdotsForm;
    if(fine && f && typeof f.focusFirstQuestion==='function'){ f.focusFirstQuestion(); }
  }
  // El popup se ense\xF1a cuando el survey est\xE1 pintado; \`ready\` deja al host abrir su propio
  // Modal en ese momento en vez de montar un WebView en blanco.
  var ddReveal=ddCreateReveal(popup, function(){
    document.body.classList.add('dd-ready');
    emitJSON('ready');
    ddRevealed=true;
    ddAutofocusOnOpen();
  }, ${REVEAL_TIMEOUT_MS});

  function setLoading(isLoading){
    spinner.style.display=isLoading?'flex':'none';
    // El spinner no tapa el survey (28px en posicion absoluta), asi que sin esto el usuario
    // puede seguir cambiando de opcion mientras se envia la pagina, y ese cambio ya no viaja
    // con ella. Se bloquea el wrapper, que es el elemento estable: el div de dentro lo
    // sustituye @magicfeedback/native por su propio contenedor al generar el survey.
    ddSetSurveyBusy(formWrapper, isLoading);
    if(!isLoading){
      formHost.style.visibility='visible';
      // Fin de la carga, sea por survey cargado o por error. Entre p\xE1ginas es no-op: la
      // revelaci\xF3n solo act\xFAa la primera vez.
      ddReveal.whenPainted();
    }
    footer.style.display=isLoading?'none':'flex';
    backBtn.disabled=isLoading; startBtn.disabled=isLoading; completeBtn.disabled=isLoading; submitBtn.disabled=isLoading;
    if(isLoading){ updateButtons(null); }
  }
  setLoading(true);

  // Survey que no ha cargado (406 de /info, sin red, bundle del CDN ca\xEDdo). Antes se emit\xEDa
  // \`loaded\` y se pintaba un Send sobre un survey vac\xEDo. Espejo de KMP: aviso traducido, la X
  // sigue, un \xFAnico Cancel, y se revela ya (manda \`ready\`): no hay nada m\xE1s que esperar.
  // No es interacci\xF3n del usuario: el renderer no lo convierte en popup_clicked.
  var ddLoadFailed=false;
  function ddShowLoadError(name, reason){
    if(ddLoadFailed){ return; }
    ddLoadFailed=true;
    var why=(reason && reason.message) ? reason.message : String(reason);
    emitJSON(name, { message: why });
    progressEl.style.display='none';
    formWrapper.style.display='none';
    errorHint.style.display='none';
    loadErrorEl.textContent=DD_LABELS_ACTIVE.errorLoad;
    loadErrorEl.style.display='block';
    setLoading(false);
    updateButtons('load_error');
    ddReveal.reveal();
  }

  var initialized=false;
  function initMF(){
    if(initialized || !window.magicfeedback) return initialized;
    initialized=true;
    try{
      window.magicfeedback.init({ debug:false, env:'${env}' });
      var form = window.magicfeedback.form(${sid}, ${pid}, ${profileJson}, ${metaJson});
      window.DeepdotsForm = form;
      var stylesInjected=false;
      form.generate('mf', {
        addButton:false,
        getMetaData:true,
        // La pantalla final la pinta el popup: renderSuccess de @magicfeedback/native usa
        // textContent, as\xED que el mensaje de la plataforma (HTML con imagen) no se ver\xEDa, y su
        // fallback es un literal gen\xE9rico que ignora style.successMessage.
        addSuccessScreen:false,
        // Surveys multi-idioma: native pide a la API este idioma (el del init o el del
        // dispositivo); si el survey no lo tiene, la API sirve el idioma por defecto.
        lang:${initLangJson}||undefined,
        // Foco en la primera pregunta de escribir tras Start, Siguiente o Atr\xE1s. Las versiones
        // de native sin esta opci\xF3n la ignoran.
        autofocus:'navigation',
        onLoadedEvent:function(args){
          if(args && args.error){ ddShowLoadError('error:load', args.error); return; }
          // Idioma en el que native muestra el survey: manda sobre el del init para que el
          // chrome no se quede en ingl\xE9s delante de un survey traducido. Native < 2.3 no lo
          // env\xEDa: entonces el primero de formData.lang (el idioma por defecto).
          var shown=args && typeof args.lang==='string' && args.lang.trim() ? args.lang : null;
          var langs=shown ? [shown] : (args && args.formData ? args.formData.lang : null);
          if(langs && langs.length){
            for(var li=0;li<langs.length;li++){
              if(typeof langs[li]==='string' && langs[li].trim()){ ddApplyLabels(langs[li]); break; }
            }
          }
          var s=args && args.formData ? args.formData.style : null;
          if(s && !stylesInjected){
            stylesInjected=true;
            if(s.successMessage){ successMessageHtml=s.successMessage; }
            // La barra de progreso la decide el host (init) y, si no se pronuncia, la plataforma.
            if(progressPref===null){ progressEnabled=s.showProgressBar===true; }
            if(s.showProgressUnit!==undefined){ progressShowUnit=s.showProgressUnit!==false; }
            if(s.progressUnit){ progressUnit=s.progressUnit; }
            if(s.loadingBarColor){ progressBar.style.background=s.loadingBarColor; progressFollowUp.style.background=s.loadingBarColor; }
            if(chromeOn && s.boxBackgroundColor){ popup.style.background=s.boxBackgroundColor; }
            if(s.contentAlign){ main.style.justifyContent = s.contentAlign==='center' ? 'center' : 'flex-start'; }
            // El survey pinta sus controles con --mf-primary, que sale de primaryColor; si la
            // integraci\xF3n solo configura el del bot\xF3n, el popup mezclar\xEDa el color de la marca
            // con el gris azulado por defecto del paquete.
            ddApplySurveyPrimaryColor(popup, s);
            if(s.buttonPrimaryColor){
              submitBtn.style.background=s.buttonPrimaryColor; submitBtn.style.border='none'; submitBtn.style.color='#fff';
              startBtn.style.background=s.buttonPrimaryColor; startBtn.style.border='none'; startBtn.style.color='#fff';
              completeBtn.style.background=s.buttonPrimaryColor; completeBtn.style.border='none'; completeBtn.style.color='#fff';
            }
            if(s.buttonSecondaryColor){
              // Bot\xF3n de texto: solo ti\xF1e la etiqueta, sin recuperar fondo ni borde.
              backBtn.style.background='transparent'; backBtn.style.color=s.buttonSecondaryColor; backBtn.style.border='none';
            }
            if(s.logo && !document.getElementById('dd-logo')){
              var logoImg=document.createElement('img');
              logoImg.id='dd-logo'; logoImg.src=s.logo; logoImg.alt='Logo';
              if(s.logoSize==='small'){ logoImg.style.maxHeight='30px'; }
              else if(s.logoSize==='medium'){ logoImg.style.maxHeight='50px'; }
              else if(s.logoSize==='large'){ logoImg.style.maxHeight='70px'; }
              // M\xE1rgenes l\xF3gicos: con un survey RTL el popup va con dir="rtl" y el logo
              // tiene que acompa\xF1ar al chrome. En LTR el resultado es el mismo de antes.
              if(s.logoPosition==='left'){ logoImg.style.margin='12px 0 0 0'; logoImg.style.setProperty('margin-inline-start','0'); logoImg.style.setProperty('margin-inline-end','16px'); }
              else if(s.logoPosition==='right'){ logoImg.style.margin='12px 0 0 0'; logoImg.style.setProperty('margin-inline-start','auto'); logoImg.style.setProperty('margin-inline-end','0'); }
              else if(s.logoPosition==='center'){ logoImg.style.margin='12px auto 0 auto'; }
              // Encima de la barra de progreso, como hermano del header (espejo de ui/logo.ts en
              // web). Fuera de #dd-main, as\xED el logo no se va con el scroll del formulario.
              popup.insertBefore(logoImg, progressEl);
            }
            if(s.startMessage && s.startMessage!==''){ onStartPage=true; updateButtons('start'); }
            else { updateButtons('in_progress_first'); }
          } else {
            updateButtons('in_progress_first');
          }
          // El total solo se conoce una vez montado el form; sin \xE9l no hay barra que pintar.
          updateProgress({ progress:form.progress, total:form.total, completed:false, followup:false });
          emitJSON('loaded');
          setLoading(false);
          // La primera carga es la apertura; las siguientes (tras Start) las enfoca native.
          if(!ddSurveyLoaded){ ddSurveyLoaded=true; ddAutofocusOnOpen(); }
        },
        beforeSubmitEvent:function(){
          setLoading(true);
          emitJSON('before_submit');
        },
        afterSubmitEvent:function(p){
          if(p && p.error){
            setLoading(false);
            var ddErr=ddClassifySubmitError(p.error);
            if(ddErr.reason==='required'){
              // La p\xE1gina no ha cambiado: el estado de navegaci\xF3n se queda como estaba.
              errorHint.textContent=DD_LABELS_ACTIVE.errorRequired;
              errorHint.style.display='block';
              updateNavButtons();
              return;
            }
            errorHint.textContent=DD_LABELS_ACTIVE.errorSubmit;
            errorHint.style.display='block';
            // Un solo aviso por fallo: native repite el mismo objeto al cerrar el survey.
            if(p.error!==ddLastReportedError){
              ddLastReportedError=p.error;
              emitJSON('survey_error', ddErr);
            }
            return;
          }
          errorHint.style.display='none';
          setLoading(false);
          if(p && p.completed){
            surveyCompletedEmitted=true;
            showSuccessScreen();
            updateButtons('completed');
            updateProgress(p);
            emitJSON('survey_completed', p);
            return;
          }
          pageDepth++;
          updateNavButtons();
          updateProgress(p);
          emitJSON('after_submit', p);
        },
        onBackEvent:function(p){
          // Con error ("No page found") no hubo navegaci\xF3n: la profundidad no se toca.
          if(!(p&&p.error)){ pageDepth=Math.max(0,pageDepth-1); }
          updateNavButtons();
          // onBackEvent no trae \`total\`: se lee del form, que es su due\xF1o.
          updateProgress({ progress:p&&p.progress, total:form.total, completed:false, followup:p&&p.followup });
          emitJSON('back', p);
        }
      }).catch(function(e){ ddShowLoadError('error:init', e); });
    }catch(e){ ddShowLoadError('error:exception', e); }
    return true;
  }
  var s=document.createElement('script'); s.src=${JSON.stringify(cdn)}; s.async=true;
  s.onload=function(){ initMF(); };
  s.onerror=function(){ ddShowLoadError('error:load', 'survey script failed to load'); };
  document.head.appendChild(s);
  var tries=0, t=setInterval(function(){ if(initMF()||++tries>40){ clearInterval(t); } },150);
})();
<\/script>
</body></html>`;
}

// src/platform/react-native-renderer.ts
var NATIVE_READY_GRACE_MS = 500;
var ReactNativePopupRenderer = class {
  constructor(options = {}) {
    this.options = options;
    this.emitFn = null;
    this.onCloseFn = null;
    this.currentSurveyId = null;
    this.partialEmitted = false;
    this.readyEmitted = false;
    this.readyTimer = null;
  }
  init() {
  }
  show(surveyId, productId, actions, emit, onClose, env = "production", userId, style, sessionId, miniService, analyticsFeedbackSessionId, renderChrome, options) {
    this.emitFn = emit;
    this.onCloseFn = onClose;
    this.currentSurveyId = surveyId;
    this.partialEmitted = false;
    this.readyEmitted = false;
    this.armReadyFallback(surveyId);
    const { profile, metadata } = buildSurveyIdentity(userId ?? null, sessionId ?? null, miniService ?? null, analyticsFeedbackSessionId ?? null);
    const html = buildSurveyHtml({
      surveyId,
      productId,
      env,
      profile,
      metadata,
      font: style?.font,
      theme: style?.theme,
      position: style?.position,
      actions,
      // renderChrome:false (init) → HTML sin tarjeta/overlay: el host lo envuelve en su Modal.
      chrome: renderChrome,
      title: options?.title,
      showProgressBar: options?.showProgressBar,
      surveyCss: options?.surveyCss,
      language: options?.language
    });
    if (this.options.onShow) {
      this.options.onShow({ surveyId, productId, html });
    } else {
      sdkWarn(
        "[Deepdots] ReactNativePopupRenderer has no onShow: pass { onShow } to new ReactNativePopupRenderer({...}) to mount the survey WebView."
      );
    }
  }
  hide() {
    this.clearReadyFallback();
    this.options.onHide?.();
    this.currentSurveyId = null;
  }
  /** Respaldo del aviso de listo por si el WebView no llega a ejecutar el HTML. */
  armReadyFallback(surveyId) {
    this.clearReadyFallback();
    if (!this.options.onReady) return;
    this.readyTimer = setTimeout(() => {
      this.readyTimer = null;
      this.emitReady(surveyId);
    }, REVEAL_TIMEOUT_MS + NATIVE_READY_GRACE_MS);
  }
  clearReadyFallback() {
    if (this.readyTimer !== null) {
      clearTimeout(this.readyTimer);
      this.readyTimer = null;
    }
  }
  /** Idempotente: el WebView puede avisar a la vez que vence el respaldo. */
  emitReady(surveyId) {
    if (this.readyEmitted) return;
    this.readyEmitted = true;
    this.clearReadyFallback();
    this.options.onReady?.({ surveyId });
  }
  /**
   * El host la conecta al `onMessage` del WebView. Traduce los mensajes del survey a
   * eventos del SDK: primera interacción → `popup_clicked` (PARTIAL), completado →
   * `survey_completed` (COMPLETED) y cierra el popup.
   */
  handleMessage(raw) {
    const surveyId = this.currentSurveyId;
    if (!surveyId || !this.emitFn) return;
    let name;
    let payload;
    try {
      ({ name, payload } = JSON.parse(raw));
    } catch {
      name = raw;
    }
    switch (name) {
      case "ready":
        this.emitReady(surveyId);
        break;
      case "loaded":
        break;
      case "before_submit":
      case "after_submit":
      case "back":
        if (!this.partialEmitted) {
          this.partialEmitted = true;
          this.emitFn("popup_clicked", surveyId, { action: "partial" });
        }
        break;
      case "survey_completed":
        this.emitFn("survey_completed", surveyId);
        break;
      case "survey_error":
        this.emitFn("survey_error", surveyId, { reason: payload?.reason, message: payload?.message });
        break;
      case "popup_close":
        this.onCloseFn?.();
        break;
      default:
        if (typeof name === "string" && name.startsWith("error:")) this.emitReady(surveyId);
        break;
    }
  }
};
function isReactNativeEnv() {
  return typeof navigator !== "undefined" && navigator.product === "ReactNative";
}
function createReactNativeRenderer() {
  return new ReactNativePopupRenderer();
}

// src/ui/preload.ts
var defaultLoader = () => import("./renderPopup-BKZPAZZG.mjs");
var pending = null;
function preloadRenderPopup(loader = defaultLoader) {
  if (pending) return pending;
  try {
    pending = loader().then(() => void 0).catch(() => {
      pending = null;
    });
  } catch {
    pending = null;
    return Promise.resolve();
  }
  return pending;
}
function schedulePreloadRenderPopup(loader) {
  const run = () => {
    void preloadRenderPopup(loader);
  };
  const idle = globalThis.requestIdleCallback;
  if (typeof idle === "function") {
    idle(run, { timeout: 2e3 });
    return;
  }
  setTimeout(run, 0);
}

// src/platform/renderer.ts
var NoopPopupRenderer = class {
  show() {
  }
  hide() {
  }
};
var BrowserPopupRenderer = class {
  constructor() {
    this.container = null;
    this.visible = false;
  }
  init() {
    if (typeof document === "undefined") return;
    if (!this.container) {
      this.container = document.createElement("div");
      this.container.id = "deepdots-popup-container";
      this.container.style.cssText = `
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          display: none;
          z-index: 999999;
          background: rgba(0, 0, 0, 0.5);
          justify-content: center;
          align-items: center;
        `;
    }
    if (!document.body.contains(this.container)) {
      document.body.appendChild(this.container);
    }
  }
  /**
   * Descarga el chunk de `renderPopup` antes de que ningún trigger dispare, para que abrir el
   * popup no empiece por esperar ~238 KB de JS.
   */
  preload() {
    schedulePreloadRenderPopup();
  }
  show(surveyId, productId, actions, emit, onClose, env = "production", userId, style, sessionId, miniService, analyticsFeedbackSessionId, _renderChrome, options) {
    if (this.visible) return;
    if (!this.container || !document.body.contains(this.container)) this.init();
    if (!this.container) return;
    this.visible = true;
    const container = this.container;
    void import("./renderPopup-BKZPAZZG.mjs").then(
      ({ renderPopup }) => {
        renderPopup(container, surveyId, productId, actions, emit, onClose, env, userId, style, sessionId, miniService, analyticsFeedbackSessionId, options);
      },
      (error) => {
        this.visible = false;
        sdkWarn("[Deepdots] popup renderer failed to load:", error);
      }
    );
  }
  isShowing() {
    return this.visible;
  }
  hide() {
    this.visible = false;
    if (this.container) {
      this.container.style.display = "none";
      this.container.style.visibility = "";
      this.container.style.pointerEvents = "";
      this.container.innerHTML = "";
    }
  }
};
function createDefaultRenderer() {
  if (typeof document === "undefined") {
    if (isReactNativeEnv()) return createReactNativeRenderer();
    return new NoopPopupRenderer();
  }
  if (isReactNativeEnv()) return createReactNativeRenderer();
  return new BrowserPopupRenderer();
}

// src/analytics/analytics-manager.ts
function createDryRunSink(log = console.log) {
  return (payload, meta) => {
    if (meta?.resetSession) return;
    log(
      "[DeepdotsAnalytics] (dry-run \xB7 NOT sent \xB7 no init.analytics) POST /sdk/feedback \u2192",
      JSON.stringify(payload, null, 2)
    );
  };
}
var dryRunSink = createDryRunSink();
var AnalyticsManager = class {
  constructor(options = {}) {
    this.events = [];
    this.attributes = {};
    /** Métricas del host (valores medibles persistentes). Sobrescriben por key; se reenvían en cada flush. */
    this.metrics = {};
    /** Mini-services activos: nombre → timestamp de entrada. El orden de inserción marca el "más reciente". */
    this.activeMiniServices = /* @__PURE__ */ new Map();
    this.sink = options.sink ?? dryRunSink;
    this.now = options.now ?? (() => Date.now());
    this.publicKey = options.publicKey;
    this.language = options.language;
    this.device = options.device;
    this.platform = options.platform ?? "web";
    this.maxBatchSize = options.maxBatchSize ?? 20;
    this.maxBufferedEvents = options.maxBufferedEvents ?? 200;
    this.onFlushNeeded = options.onFlushNeeded;
  }
  /** Actualiza campos de device en runtime (p.ej. country/city tras resolver geo). */
  updateDevice(partial) {
    this.device = { ...this.device, ...partial };
  }
  /** Mezcla user attributes (se coercionan a string). Mutable en runtime. */
  setUserAttributes(attrs) {
    for (const [k, v] of Object.entries(attrs)) {
      if (!k) continue;
      this.attributes[k] = String(v);
    }
  }
  /**
   * Registra/actualiza una métrica (valor medible). Persistente: se reenvía en cada flush.
   * Repetir la misma key SOBRESCRIBE; el valor se coerciona a string; ignora key vacía.
   */
  setMetric(key, value) {
    if (!key) return;
    this.metrics[key] = String(value);
  }
  /**
   * Marca el inicio de un mini-service; etiqueta los eventos siguientes con `mini_service`.
   * Admite varios activos a la vez (concurrencia); el "actual" para etiquetar es el más reciente.
   * Reentrar con un nombre ya activo refresca su orden y su tiempo de entrada.
   */
  enterMiniService(name, entryPointType) {
    this.activeMiniServices.delete(name);
    this.activeMiniServices.set(name, this.now());
    this.track("deepdots_mini_service_enter", { entry_point_type: entryPointType ?? null });
  }
  /**
   * Cierra el mini-service `name` emitiendo `mini_service_exit` con su duración (#27).
   * No-op si ese nombre no está activo. Cierre coherente con concurrencia.
   */
  exitMiniService(name) {
    const enteredAt = this.activeMiniServices.get(name);
    if (enteredAt === void 0) return;
    const durationSeconds = Math.max(0, Math.round((this.now() - enteredAt) / 1e3));
    this.activeMiniServices.delete(name);
    this.track("deepdots_mini_service_exit", { mini_service: name, duration_seconds: durationSeconds });
  }
  /** Cierra TODOS los mini-services activos (orden LIFO). Para el cierre por lifecycle (background/cierre). */
  exitAllMiniServices() {
    for (const name of Array.from(this.activeMiniServices.keys()).reverse()) {
      this.exitMiniService(name);
    }
  }
  /**
   * Olvida la sesión en curso SIN emitir nada: vacía el buffer y los mini-services activos
   * (sin `mini_service_exit`). Para una sesión que el backend ya cerró por inactividad: lo
   * que quedara pendiente pertenecía a ella y no debe llegar con la sesión nueva.
   */
  discardSession(identity) {
    this.events = [];
    this.activeMiniServices.clear();
    try {
      void this.sink({ ...this.buildPayload(identity), events: [] }, { resetSession: true });
    } catch {
    }
  }
  /**
   * Olvida lo que pertenecía al usuario anterior (user attributes + métricas) al cambiar de
   * usuario. NO toca el buffer de eventos: el cierre de sesión ya lo vació con la identidad
   * vieja, y lo que llegue después es del usuario nuevo.
   */
  resetUserScope() {
    this.attributes = {};
    this.metrics = {};
  }
  /** Registra un evento de analítica (modelo GA: nombre + params). */
  track(name, params) {
    const current = this.getMiniService();
    const merged = {
      ...current ? { mini_service: current } : {},
      ...params ?? {}
    };
    this.events.push({
      name,
      timestamp: this.now(),
      params: Object.keys(merged).length ? merged : void 0
    });
    this.enforceBufferCap();
    if (this.events.length >= this.maxBatchSize) {
      this.onFlushNeeded?.();
    }
  }
  /** Mini-service actual (el más reciente aún activo) para etiquetar eventos + metadata del survey (#33). */
  getMiniService() {
    let last = null;
    for (const name of this.activeMiniServices.keys()) last = name;
    return last;
  }
  /** Nº de eventos pendientes de flush. */
  pending() {
    return this.events.length;
  }
  /** Construye el envelope que se enviaría al endpoint de analytics. */
  buildPayload(identity) {
    return {
      publicKey: this.publicKey,
      userId: identity.userId,
      sessionId: identity.sessionId,
      context: {
        platform: this.platform,
        language: this.language,
        device: this.device,
        attributes: { ...this.attributes },
        metrics: { ...this.metrics }
      },
      events: [...this.events]
    };
  }
  /**
   * Envía (vía sink) el lote acumulado y vacía el buffer. No-op si no hay eventos.
   *
   * Si el sink falla de forma transitoria (promesa rechazada o excepción síncrona) el lote
   * se **re-encola** al principio del buffer y se reintenta en el siguiente flush: un error
   * de red o un 5xx no debe hacer desaparecer los eventos.
   */
  flush(identity, meta) {
    if (this.events.length === 0) return null;
    const batch = this.events;
    const payload = this.buildPayload(identity);
    this.events = [];
    let result;
    try {
      result = meta ? this.sink(payload, meta) : this.sink(payload);
    } catch {
      this.requeue(batch);
      return payload;
    }
    if (result && typeof result.then === "function") {
      result.catch(() => this.requeue(batch));
    }
    return payload;
  }
  /**
   * Devuelve un lote fallido al buffer, delante de lo que haya llegado mientras se enviaba
   * (orden cronológico). Con el buffer lleno se descartan los eventos más antiguos.
   */
  requeue(batch) {
    this.events = [...batch, ...this.events];
    this.enforceBufferCap();
  }
  /** Techo del buffer: si el envío lleva rato fallando, se sacrifica lo más antiguo. */
  enforceBufferCap() {
    const overflow = this.events.length - this.maxBufferedEvents;
    if (overflow > 0) this.events.splice(0, overflow);
  }
};

// src/analytics/feedback-payload.ts
function pushKV(list, key, value) {
  if (value === void 0 || value === null || value === "") return;
  list.push({ key, value: [String(value)] });
}
function buildAnalyticsFeedbackBody(envelope, keys, feedbackSessionId, options) {
  const { context } = envelope;
  const profile = [];
  pushKV(profile, "external-user-id", envelope.userId);
  const metadata = [];
  pushKV(metadata, "deepdots_user_id", envelope.userId);
  pushKV(metadata, "deepdots_session_id", envelope.sessionId);
  pushKV(metadata, "deepdots_platform", context.platform);
  pushKV(metadata, "deepdots_language", context.language);
  if (context.device) {
    const d = context.device;
    pushKV(metadata, "deepdots_device_type", d.device_type);
    pushKV(metadata, "deepdots_os_version", d.os_version);
    pushKV(metadata, "deepdots_device_model", d.device_model);
    pushKV(metadata, "deepdots_app_version", d.app_version);
    pushKV(metadata, "deepdots_user_agent", d.user_agent);
    pushKV(metadata, "deepdots_timezone", d.timezone);
    pushKV(metadata, "deepdots_referrer", d.referrer);
    pushKV(metadata, "deepdots_viewport_size", d.viewport_size);
    pushKV(metadata, "deepdots_screen_resolution", d.screen_resolution);
    pushKV(metadata, "deepdots_pixel_ratio", d.pixel_ratio);
    pushKV(metadata, "deepdots_entry_type", d.entry_type);
    pushKV(metadata, "deepdots_page_load_ms", d.page_load_ms);
    pushKV(metadata, "deepdots_connection_type", d.connection_type);
    pushKV(metadata, "deepdots_country", d.country);
    pushKV(metadata, "deepdots_city", d.city);
  }
  for (const [k, v] of Object.entries(context.attributes ?? {})) {
    pushKV(metadata, k, v);
  }
  for (const e of envelope.events) {
    metadata.push({
      key: e.name,
      value: [JSON.stringify({ timestamp: e.timestamp, ...e.params ?? {} })]
    });
  }
  const metrics = [];
  for (const [k, v] of Object.entries(context.metrics ?? {})) {
    pushKV(metrics, k, v);
  }
  return {
    feedback: {
      text: "",
      answers: [],
      metrics,
      metadata,
      profile,
      finished: false
    },
    publicKey: keys.publicKey,
    integration: keys.integration,
    // Único marcador de cierre acordado con backend: el último lote de la sesión.
    completed: options?.sessionEnd === true,
    ...feedbackSessionId ? { sessionId: feedbackSessionId } : {}
  };
}
var KEEPALIVE_MAX_BYTES = 6e4;
function isRetryableStatus(status) {
  return status >= 500 || status === 408 || status === 429;
}
async function safeBodyText(res) {
  try {
    return (await res.text()).slice(0, 500);
  } catch {
    return "";
  }
}
var PENDING_MAX = 50;
var PENDING_MAX_AGE_MS = 24 * 60 * 60 * 1e3;
var POST_TIMEOUT_MS = 2e4;
function pendingKey(integration) {
  return `__deepdots_analytics_pending__:${integration}`;
}
function generateSessionId() {
  const c = globalThis.crypto;
  if (typeof c?.randomUUID === "function") return c.randomUUID();
  const b = new Uint8Array(16);
  if (typeof c?.getRandomValues === "function") c.getRandomValues(b);
  else for (let i = 0; i < 16; i++) b[i] = Math.floor(Math.random() * 256);
  b[6] = b[6] & 15 | 64;
  b[8] = b[8] & 63 | 128;
  const h = Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}
function createFeedbackSink(options) {
  const url = `${options.baseUrl}/sdk/feedback`;
  const newSessionId = options.newSessionId ?? generateSessionId;
  const now = options.now ?? (() => Date.now());
  const storageKey = pendingKey(options.keys.integration);
  let feedbackSessionId = options.initialSessionId || void 0;
  let announcedId = feedbackSessionId;
  const pending2 = loadPending();
  let draining = null;
  function loadPending() {
    if (!options.storage) return [];
    try {
      const raw = options.storage.getItem(storageKey);
      const list = raw ? JSON.parse(raw) : [];
      return Array.isArray(list) ? list.filter((p) => p?.body && now() - p.at <= PENDING_MAX_AGE_MS) : [];
    } catch {
      return [];
    }
  }
  function savePending() {
    if (!options.storage) return;
    try {
      if (pending2.length) options.storage.setItem(storageKey, JSON.stringify(pending2));
      else options.storage.removeItem(storageKey);
    } catch {
    }
  }
  function addPending(batch) {
    pending2.push(batch);
    if (pending2.length > PENDING_MAX) pending2.splice(0, pending2.length - PENDING_MAX);
    savePending();
  }
  function removePending(batch) {
    const i = pending2.indexOf(batch);
    if (i >= 0) pending2.splice(i, 1);
    savePending();
  }
  async function post(body, final) {
    const json = JSON.stringify(body);
    const small = json.length <= KEEPALIVE_MAX_BYTES;
    if (final) options.log?.("[DeepdotsAnalytics] final flush via fetch keepalive");
    const f = options.fetchImpl ?? (typeof fetch !== "undefined" ? fetch : void 0);
    if (!f) {
      options.log?.("[DeepdotsAnalytics] no fetch available; payload not sent", body);
      return "drop";
    }
    let timer;
    try {
      const request = f(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: json,
        // La API autentica por `publicKey` en el body y responde `Allow-Origin: *`: una
        // petición con credenciales fallaría el CORS. Explícito para no depender del default.
        credentials: "omit",
        // keepalive: el POST sobrevive a la navegación mientras el body sea pequeño.
        ...small ? { keepalive: true } : {}
      });
      const timeout = new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error("timeout")), POST_TIMEOUT_MS);
      });
      const res = await Promise.race([request, timeout]);
      if (res.ok) return "ok";
      const detail = await safeBodyText(res);
      if (isRetryableStatus(res.status)) {
        options.log?.(`[DeepdotsAnalytics] POST /sdk/feedback ${res.status} (retryable): ${detail}`);
        return "retry";
      }
      options.log?.(
        `[DeepdotsAnalytics] POST /sdk/feedback rejected with ${res.status}; batch DISCARDED:`,
        detail
      );
      return "drop";
    } catch (error) {
      options.log?.("[DeepdotsAnalytics] POST /sdk/feedback failed (will retry):", error);
      return "retry";
    } finally {
      clearTimeout(timer);
    }
  }
  function delivered(body) {
    const id = body.sessionId;
    if (!id) return;
    try {
      if (body.completed) {
        options.onSessionClosed?.(id);
      } else if (id === feedbackSessionId && id !== announcedId) {
        announcedId = id;
        options.log?.("[DeepdotsAnalytics] feedback session open:", id);
        options.onSessionId?.(id);
      }
    } catch {
    }
  }
  async function send(batch, final, alreadyPending) {
    const result = await post(batch.body, final);
    if (result === "retry") {
      if (!alreadyPending) addPending(batch);
      return;
    }
    if (alreadyPending) removePending(batch);
    if (result === "ok") delivered(batch.body);
  }
  function drain() {
    const run = async () => {
      for (let i = 0; i < pending2.length; ) {
        const batch = pending2[i];
        await send(batch, false, true);
        if (pending2[i] === batch) return;
      }
    };
    const next = draining ? draining.then(run) : run();
    draining = next;
    void next.finally(() => {
      if (draining === next) draining = null;
    });
    return next;
  }
  if (pending2.length) {
    savePending();
    setTimeout(() => void drain(), 0);
  }
  return async (envelope, meta) => {
    if (meta?.resetSession) {
      feedbackSessionId = void 0;
      options.onSessionReset?.();
      return;
    }
    const final = meta?.final === true;
    const sessionEnd = meta?.sessionEnd === true;
    if (!feedbackSessionId) feedbackSessionId = newSessionId();
    const body = buildAnalyticsFeedbackBody(envelope, options.keys, feedbackSessionId, { sessionEnd });
    options.log?.("[DeepdotsAnalytics] POST /sdk/feedback \u2192", body);
    const batch = { body, at: now() };
    if (sessionEnd) {
      feedbackSessionId = void 0;
      options.onSessionReset?.();
      addPending(batch);
      await drain();
      return;
    }
    const retries = pending2.length ? drain() : null;
    await Promise.all([retries, send(batch, final, false)]);
  };
}

// src/analytics/suspended-session.ts
var SUSPENDED_SESSION_KEY = "deepdots.analytics.suspended";
function getSessionStorage() {
  try {
    return typeof window !== "undefined" && window.sessionStorage ? window.sessionStorage : null;
  } catch {
    return null;
  }
}
function writeSuspendedSession(storage, session) {
  try {
    storage.setItem(SUSPENDED_SESSION_KEY, JSON.stringify(session));
    return true;
  } catch {
    return false;
  }
}
function clearSuspendedSession(storage) {
  try {
    storage.removeItem(SUSPENDED_SESSION_KEY);
  } catch {
  }
}
function takeSuspendedSession(storage, match, now, windowMs) {
  let raw = null;
  try {
    raw = storage.getItem(SUSPENDED_SESSION_KEY);
  } catch {
    return null;
  }
  if (!raw) return null;
  clearSuspendedSession(storage);
  try {
    const s = JSON.parse(raw);
    if (typeof s.sessionId !== "string" || !s.sessionId) return null;
    if (typeof s.at !== "number" || now - s.at < 0 || now - s.at > windowMs) return null;
    if (s.integration !== match.integration) return null;
    if ((s.userId ?? null) !== match.userId) return null;
    return { sessionId: s.sessionId, integration: s.integration, userId: s.userId ?? null, at: s.at };
  } catch {
    return null;
  }
}

// src/tracking/navigation-observer.ts
var UUID_PREFIX = /^[0-9a-f]{8}-[0-9a-f]{4}-/i;
function screenPath(href) {
  let pathAndHash;
  try {
    const u = new URL(href, "http://deepdots.local");
    pathAndHash = u.pathname + (u.hash || "");
  } catch {
    pathAndHash = href;
  }
  return pathAndHash.replace(/\?[^#]*/g, "") || "/";
}
function normalizeScreen(href) {
  const pathAndHash = screenPath(href);
  const collapsed = pathAndHash.split("/").map((seg) => /^[0-9]+$/.test(seg) || UUID_PREFIX.test(seg) ? ":id" : seg).join("/");
  return collapsed || "/";
}
var NavigationObserver = class {
  constructor(options = {}) {
    this.listeners = /* @__PURE__ */ new Set();
    this.currentScreen = null;
    this.currentPath = null;
    this.entryAt = 0;
    this.installed = false;
    this.domHandlers = [];
    this.now = options.now ?? (() => Date.now());
  }
  onVisit(listener) {
    this.listeners.add(listener);
  }
  /** Fija la pantalla inicial (sin emitir visita; su duración se cierra al salir). */
  begin(href) {
    this.currentScreen = normalizeScreen(href);
    this.currentPath = screenPath(href);
    this.entryAt = this.now();
  }
  /** Navega a una pantalla nueva: cierra la anterior (emite visita) y abre la nueva. */
  visit(href) {
    const nextPath = screenPath(href);
    if (this.currentScreen != null && nextPath === this.currentPath) return;
    this.closeCurrent();
    this.currentScreen = normalizeScreen(href);
    this.currentPath = nextPath;
    this.entryAt = this.now();
  }
  /** Cierra la pantalla actual emitiendo su visita (p. ej. al cerrar la app/pestaña). */
  stop() {
    this.closeCurrent();
    this.currentScreen = null;
    this.currentPath = null;
  }
  /**
   * Olvida la pantalla actual SIN emitir su visita. Para una sesión que el backend ya dio
   * por cerrada: su visita no tiene dónde ir, y mandarla con la sesión nueva la contaría
   * donde no ocurrió. Después, `restart()` vuelve a empezar en la pantalla actual.
   */
  discard() {
    this.currentScreen = null;
    this.currentPath = null;
  }
  /**
   * Retoma el seguimiento en la pantalla actual tras un `stop()`, cuando se abre una sesión
   * nueva sin navegar (cambio de usuario, vuelta de la bfcache). No-op si nunca se instaló
   * (navegación manual por `setScreen`, RN) o si ya hay pantalla en curso.
   */
  restart() {
    if (!this.installed || this.currentScreen != null || typeof window === "undefined") return;
    this.begin(window.location.href);
  }
  /**
   * La pantalla en curso, sin cerrarla ni emitir nada; null si no hay (antes de `begin`, tras
   * `stop`/`discard`). Para que el `user_engagement` lleve la pantalla: si el cierre de la
   * sesión no llega nunca (pestaña dormida y descartada, app matada), la última pantalla no
   * tiene `page_view` y solo queda esto.
   */
  current() {
    if (this.currentScreen == null) return null;
    return {
      screen: this.currentScreen,
      path: this.currentPath ?? this.currentScreen,
      seconds: this.secondsSinceEntry(this.now())
    };
  }
  secondsSinceEntry(at) {
    return Math.max(0, Math.round((at - this.entryAt) / 1e3));
  }
  closeCurrent() {
    if (this.currentScreen == null) return;
    const exit = this.now();
    const visit = {
      screen: this.currentScreen,
      path: this.currentPath ?? this.currentScreen,
      entry: this.entryAt,
      exit,
      durationSeconds: this.secondsSinceEntry(exit)
    };
    this.listeners.forEach((l) => {
      try {
        l(visit);
      } catch {
      }
    });
  }
  /** Instala los hooks de History en el navegador y registra la pantalla actual. */
  install() {
    if (this.installed || typeof window === "undefined" || typeof history === "undefined") return;
    this.installed = true;
    const handle = () => this.visit(window.location.href);
    const originalPush = history.pushState.bind(history);
    const originalReplace = history.replaceState.bind(history);
    history.pushState = (data, unused, url) => {
      const r = originalPush(data, unused, url);
      handle();
      return r;
    };
    history.replaceState = (data, unused, url) => {
      const r = originalReplace(data, unused, url);
      handle();
      return r;
    };
    window.addEventListener("popstate", handle);
    window.addEventListener("hashchange", handle);
    this.domHandlers.push(() => {
      history.pushState = originalPush;
      history.replaceState = originalReplace;
      window.removeEventListener("popstate", handle);
      window.removeEventListener("hashchange", handle);
    });
    this.begin(window.location.href);
  }
  uninstall() {
    this.domHandlers.forEach((off) => off());
    this.domHandlers = [];
    this.installed = false;
  }
};

// src/analytics/device-info.ts
function parseDeviceType(ua) {
  const s = (ua || "").toLowerCase();
  if (/ipad|tablet|playbook|silk/.test(s) || /android/.test(s) && !/mobile/.test(s)) {
    return "tablet";
  }
  if (/mobi|iphone|ipod|windows phone/.test(s) || /android/.test(s) && /mobile/.test(s)) {
    return "mobile";
  }
  return "desktop";
}
function getEntryType() {
  if (typeof performance === "undefined") return void 0;
  const entries = performance.getEntriesByType("navigation");
  if (!entries.length) return void 0;
  return entries[0].type;
}
function getPageLoadMs() {
  if (typeof performance === "undefined") return void 0;
  const entries = performance.getEntriesByType("navigation");
  if (!entries.length) return void 0;
  const load = entries[0].loadEventEnd;
  return load > 0 ? Math.round(load) : void 0;
}
function getConnectionType() {
  if (typeof navigator === "undefined") return void 0;
  return navigator.connection?.effectiveType ?? void 0;
}
function collectDeviceInfo(appVersion) {
  const ua = typeof navigator !== "undefined" ? navigator.userAgent : "";
  return {
    device_type: parseDeviceType(ua),
    user_agent: ua || void 0,
    app_version: appVersion,
    timezone: typeof Intl !== "undefined" ? Intl.DateTimeFormat().resolvedOptions().timeZone : void 0,
    referrer: typeof document !== "undefined" && document.referrer ? document.referrer : void 0,
    viewport_size: typeof window !== "undefined" ? `${window.innerWidth}x${window.innerHeight}` : void 0,
    screen_resolution: typeof screen !== "undefined" ? `${screen.width}x${screen.height}` : void 0,
    pixel_ratio: typeof window !== "undefined" ? window.devicePixelRatio : void 0,
    entry_type: getEntryType(),
    page_load_ms: getPageLoadMs(),
    connection_type: getConnectionType()
  };
}

// src/analytics/geo-info.ts
var GEO_STORAGE_KEY = "deepdots.geo";
var GEO_TTL_MS = 30 * 24 * 60 * 60 * 1e3;
var GEO_TIMEOUT_MS = 3e3;
function readCachedGeo(storage, now) {
  try {
    const raw = storage.getItem(GEO_STORAGE_KEY);
    if (!raw) return null;
    const cached = JSON.parse(raw);
    if (typeof cached.ts !== "number" || now - cached.ts > GEO_TTL_MS) return null;
    const geo = {};
    if (cached.country) geo.country = cached.country;
    if (cached.city) geo.city = cached.city;
    return geo.country || geo.city ? geo : null;
  } catch {
    return null;
  }
}
function writeCachedGeo(storage, geo, now) {
  try {
    const payload = { ...geo, ts: now };
    storage.setItem(GEO_STORAGE_KEY, JSON.stringify(payload));
  } catch {
  }
}
var DEFAULT_GEO_PROVIDERS = [
  {
    // https://ipapi.co/json/
    url: "https://ipapi.co/json/",
    parse: (d) => geoFrom(d.country_code, d.city)
  },
  {
    // https://ipwho.is/ (devuelve success:false con 200 en errores)
    url: "https://ipwho.is/",
    parse: (d) => d.success === false ? null : geoFrom(d.country_code, d.city)
  },
  {
    // https://ipinfo.io/json (country = código ISO)
    url: "https://ipinfo.io/json",
    parse: (d) => geoFrom(d.country, d.city)
  }
];
function geoFrom(country, city) {
  const c = typeof country === "string" && country ? country : void 0;
  const t = typeof city === "string" && city ? city : void 0;
  if (!c && !t) return null;
  return { country: c, city: t };
}
async function fetchOne(provider, f, timeoutMs) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await f(provider.url, { signal: controller.signal });
    if (!res.ok) return null;
    const data = await res.json();
    return provider.parse(data);
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}
async function fetchGeo(options = {}) {
  const f = options.fetchImpl ?? (typeof fetch !== "undefined" ? fetch : void 0);
  if (!f) return null;
  const providers = options.providers ?? DEFAULT_GEO_PROVIDERS;
  const timeoutMs = options.timeoutMs ?? GEO_TIMEOUT_MS;
  for (const provider of providers) {
    const geo = await fetchOne(provider, f, timeoutMs);
    if (geo) return geo;
  }
  return null;
}

// src/analytics/language.ts
function clean(value) {
  const trimmed = value?.trim();
  return trimmed ? trimmed : void 0;
}
function resolveLanguage(sources) {
  const explicit = clean(sources.explicit);
  if (explicit) return explicit;
  const navLang = clean(sources.navigator?.language);
  if (navLang) return navLang;
  try {
    const locale = clean(sources.intl?.DateTimeFormat().resolvedOptions().locale);
    if (locale) return locale;
  } catch {
  }
  return void 0;
}

// src/analytics/engagement-tracker.ts
var EngagementTracker = class {
  constructor(now = () => Date.now()) {
    this.activeMs = 0;
    this.lastResumeAt = null;
    this.now = now;
  }
  /** Reanuda el conteo (pestaña visible / app en foreground). Idempotente. */
  resume() {
    if (this.lastResumeAt === null) this.lastResumeAt = this.now();
  }
  /** Pausa el conteo (pestaña oculta / app en background), acumulando el tramo activo. */
  pause() {
    if (this.lastResumeAt !== null) {
      this.activeMs += this.now() - this.lastResumeAt;
      this.lastResumeAt = null;
    }
  }
  /** Devuelve los ms activos acumulados desde la última lectura y reinicia (sin parar el timer). */
  consume() {
    if (this.lastResumeAt !== null) {
      const t = this.now();
      this.activeMs += t - this.lastResumeAt;
      this.lastResumeAt = t;
    }
    const ms = this.activeMs;
    this.activeMs = 0;
    return ms;
  }
  isActive() {
    return this.lastResumeAt !== null;
  }
};

// src/contact/contact-manager.ts
function stableSerialize(userId, attrs) {
  const sorted = {};
  for (const key of Object.keys(attrs).sort()) {
    sorted[key] = attrs[key];
  }
  return JSON.stringify({ userId, attributes: sorted });
}
var ContactManager = class {
  constructor(options) {
    this.storage = options.storage;
    this.publicKey = options.publicKey;
    this.userId = options.userId;
    this.post = options.post;
  }
  /**
   * Envía los atributos si cambiaron respecto a lo último enviado. La caché solo se guarda
   * cuando la API acepta el envío; si falla, la llamada siguiente reintenta. Nunca rechaza.
   * @returns `true` si se envió, `false` si no hubo cambios o el envío falló.
   */
  async setAttributes(attributes) {
    const serialized = stableSerialize(this.userId, attributes);
    const last = this.storage.getItem(STORAGE_KEYS.contactAttributes);
    if (last === serialized) return false;
    try {
      await this.post({
        publicKey: this.publicKey,
        userId: this.userId,
        userAttributes: attributes
      });
    } catch {
      return false;
    }
    this.storage.setItem(STORAGE_KEYS.contactAttributes, serialized);
    return true;
  }
};

// src/analytics/crash-reporter.ts
var STACK_MAX = 8e3;
var QUEUE_KEY = "deepdots.crash.queue";
var MAX_QUEUED = 20;
function crashRecordToParams(r) {
  const params = {
    crashed_at: r.crashedAt,
    crash_type: r.crashType,
    message: r.message,
    stack: r.stack,
    fatal: r.fatal,
    handled: r.handled,
    severity: r.severity
  };
  if (r.sessionId) params.crashed_session_id = r.sessionId;
  if (r.appVersion) params.crashed_app_version = r.appVersion;
  if (r.osVersion) params.crashed_os_version = r.osVersion;
  if (r.deviceModel) params.crashed_device_model = r.deviceModel;
  if (r.context) {
    for (const [k, v] of Object.entries(r.context)) params[`ctx_${k}`] = v;
  }
  return params;
}
var CrashReporter = class {
  constructor(options) {
    /** Los handlers de `window` ya están puestos: `install()` es idempotente. */
    this.windowInstalled = false;
    /** ErrorUtils ya enganchados: engancharlos dos veces capturaría cada error dos veces. */
    this.hookedErrorUtils = /* @__PURE__ */ new Set();
    this.options = options;
    this.now = options.now ?? (() => Date.now());
  }
  isEnabled() {
    return this.options.enabled ? this.options.enabled() : true;
  }
  /** Construye un CrashRecord capturando contexto en el momento del crash. */
  buildRecord(error, severity, handled, fatal, context) {
    const err = error;
    const isErr = error instanceof Error;
    const dev = this.options.device();
    const ctx = context ? Object.fromEntries(Object.entries(context).map(([k, v]) => [k, String(v)])) : void 0;
    return {
      crashedAt: this.now(),
      crashType: isErr && err.name || "Error",
      message: isErr ? String(err.message ?? "") : String(error),
      stack: (isErr && typeof err.stack === "string" ? err.stack : "").slice(0, STACK_MAX),
      fatal,
      handled,
      severity,
      sessionId: this.options.sessionId(),
      appVersion: dev.appVersion,
      osVersion: dev.osVersion,
      deviceModel: dev.deviceModel,
      context: ctx
    };
  }
  /** API pública del host: reporta un error (app viva) → emite el evento ya. */
  reportError(error, options = {}) {
    if (!this.isEnabled()) return;
    const severity = options.severity ?? "error";
    const handled = options.handled ?? true;
    const fatal = severity === "fatal";
    const record = this.buildRecord(error, severity, handled, fatal, options.context);
    this.options.emit(crashRecordToParams(record));
  }
  /** Captura un error no manejado (fatal) → persiste a disco para replay en el siguiente arranque. */
  captureUnhandled(error) {
    this.persist(this.buildRecord(error, "fatal", false, true));
  }
  /** Persiste un crash no capturado a disco para reenviarlo en el siguiente arranque. */
  persist(record) {
    let queue = [];
    try {
      const raw = this.options.storage.getItem(QUEUE_KEY);
      if (raw) queue = JSON.parse(raw);
      if (!Array.isArray(queue)) queue = [];
    } catch {
      queue = [];
    }
    queue.push(record);
    if (queue.length > MAX_QUEUED) queue = queue.slice(queue.length - MAX_QUEUED);
    try {
      this.options.storage.setItem(QUEUE_KEY, JSON.stringify(queue));
    } catch {
    }
  }
  /** Lee y vacía la cola de crashes pendientes (llamado en init para el replay). */
  drainPendingCrashes() {
    let queue = [];
    try {
      const raw = this.options.storage.getItem(QUEUE_KEY);
      if (raw) queue = JSON.parse(raw);
      if (!Array.isArray(queue)) queue = [];
    } catch {
      queue = [];
    }
    if (queue.length) {
      try {
        this.options.storage.removeItem(QUEUE_KEY);
      } catch {
      }
    }
    return queue;
  }
  /** Instala los handlers globales de errores no capturados (no-op sin `window`). Idempotente. */
  install() {
    if (this.windowInstalled) return;
    if (typeof window === "undefined" || typeof window.addEventListener !== "function") return;
    this.windowInstalled = true;
    window.addEventListener("error", (e) => {
      if (!this.isEnabled()) return;
      this.captureUnhandled(e.error ?? e.message ?? "error");
    });
    window.addEventListener("unhandledrejection", (e) => {
      if (!this.isEnabled()) return;
      this.captureUnhandled(e.reason ?? "unhandledrejection");
    });
  }
  /** Engancha `global.ErrorUtils` de RN (no hay `window`): persiste y encadena al handler previo. Idempotente por instancia de ErrorUtils. */
  installReactNative(errorUtils) {
    if (this.hookedErrorUtils.has(errorUtils)) return;
    this.hookedErrorUtils.add(errorUtils);
    const previous = errorUtils.getGlobalHandler?.();
    errorUtils.setGlobalHandler((error, isFatal) => {
      if (this.isEnabled()) this.captureUnhandled(error);
      previous?.(error, isFatal);
    });
  }
  /** @internal Test seam: ejercita el camino de persistencia (window handlers no son testeables en vitest). */
  _persistForTest(error) {
    this.captureUnhandled(error);
  }
};

// src/core/popup-state-store.ts
var POPUP_STATE_STORAGE_KEY = "deepdots.popups.state";
var MAX_TRACKED_POPUP_ENTRIES = 200;
function emptyState() {
  return { lastShown: {}, progress: {} };
}
function isValidTimestamp(value) {
  return typeof value === "number" && Number.isFinite(value);
}
function capEntries(entries, timestampOf) {
  if (entries.length <= MAX_TRACKED_POPUP_ENTRIES) return entries;
  return [...entries].sort((a, b) => timestampOf(b[1]) - timestampOf(a[1])).slice(0, MAX_TRACKED_POPUP_ENTRIES);
}
function readPopupState(storage) {
  let raw = null;
  try {
    raw = storage.getItem(POPUP_STATE_STORAGE_KEY);
  } catch {
    return emptyState();
  }
  if (!raw) return emptyState();
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return emptyState();
  }
  if (typeof parsed !== "object" || parsed === null) return emptyState();
  const source = parsed;
  const state = emptyState();
  if (typeof source.lastShown === "object" && source.lastShown !== null) {
    const valid = Object.entries(source.lastShown).filter((entry) => isValidTimestamp(entry[1]));
    capEntries(valid, (timestamp) => timestamp).forEach(([popupId, timestamp]) => {
      state.lastShown[popupId] = timestamp;
    });
  }
  if (typeof source.progress === "object" && source.progress !== null) {
    const valid = Object.entries(source.progress).filter((entry) => {
      const value = entry[1];
      if (typeof value !== "object" || value === null) return false;
      const candidate = value;
      return POPUP_TRIGGER_CONDITION_STATUSES.includes(candidate.status) && isValidTimestamp(candidate.timestamp);
    });
    capEntries(valid, (entry) => entry.timestamp).forEach(([surveyId, entry]) => {
      state.progress[surveyId] = { status: entry.status, timestamp: entry.timestamp };
    });
  }
  return state;
}
function writePopupState(storage, state) {
  const capped = emptyState();
  capEntries(Object.entries(state.lastShown), (timestamp) => timestamp).forEach(([popupId, timestamp]) => {
    capped.lastShown[popupId] = timestamp;
  });
  capEntries(Object.entries(state.progress), (entry) => entry.timestamp).forEach(([surveyId, entry]) => {
    capped.progress[surveyId] = entry;
  });
  try {
    storage.setItem(POPUP_STATE_STORAGE_KEY, JSON.stringify(capped));
  } catch {
  }
}
function clearPopupState(storage) {
  try {
    storage.removeItem(POPUP_STATE_STORAGE_KEY);
  } catch {
  }
}

// src/analytics/messaging.ts
var MESSAGE_CHANNELS = ["push", "in_app"];
function buildMessageParams(stage, o) {
  const p = {
    stage,
    message_id: o.id,
    message_title: o.title,
    channel: o.channel
  };
  if (o.campaign) p.campaign = o.campaign;
  if (o.value !== void 0) p.value = o.value;
  if (o.currency) p.currency = o.currency;
  return { ...p, ...o.params ?? {} };
}
var MAX_TRACKED_MESSAGES = 500;
var MessageGuard = class {
  constructor(maxTrackedMessages = MAX_TRACKED_MESSAGES) {
    this.maxTrackedMessages = maxTrackedMessages;
    /** message_id → canal fijado + stages ya emitidos. El orden de inserción marca la eviction. */
    this.seen = /* @__PURE__ */ new Map();
  }
  evaluate(stage, options) {
    const channel = options.channel;
    if (!MESSAGE_CHANNELS.includes(channel)) {
      return {
        emit: false,
        reason: "invalid_channel",
        detail: `invalid channel "${channel}" (expected ${MESSAGE_CHANNELS.join(" | ")})`
      };
    }
    const entry = this.seen.get(options.id);
    if (!entry) {
      this.remember(options.id, channel, stage);
      return { emit: true };
    }
    if (entry.channel !== channel) {
      return {
        emit: false,
        reason: "channel_conflict",
        detail: `message_id "${options.id}" was already reported on channel "${entry.channel}"; discarding "${channel}"`
      };
    }
    if (entry.stages.has(stage)) {
      return {
        emit: false,
        reason: "duplicate_stage",
        detail: `stage "${stage}" was already sent for message_id "${options.id}"`
      };
    }
    entry.stages.add(stage);
    return { emit: true };
  }
  /** Olvida todo lo vigilado (nueva sesión). */
  reset() {
    this.seen.clear();
  }
  remember(id, channel, stage) {
    this.seen.set(id, { channel, stages: /* @__PURE__ */ new Set([stage]) });
    while (this.seen.size > this.maxTrackedMessages) {
      const oldest = this.seen.keys().next();
      if (oldest.done) break;
      this.seen.delete(oldest.value);
    }
  }
};

// src/core/deepdots-popups.ts
var EXIT_QUEUE_STORAGE_KEY = "__deepdots_exit_popup_queue__";
var DAY_IN_MS = 24 * 60 * 60 * 1e3;
var ANALYTICS_MAX_BATCH_SIZE = 20;
var ANALYTICS_FLUSH_INTERVAL_MS = 3e4;
var ANALYTICS_HEARTBEAT_MS = 5 * 6e4;
var ANALYTICS_SESSION_TIMEOUT_MS = 30 * 6e4;
var ANALYTICS_SERVER_IDLE_MS = 60 * 6e4;
var ANALYTICS_SESSION_DISCARD_MS = ANALYTICS_SERVER_IDLE_MS - 10 * 6e4;
var ANALYTICS_RESUME_WINDOW_MS = 6e4;
var RESERVED_EVENT_PREFIX = "deepdots_";
var CUSTOM_EVENT_PREFIX = "deepdots_event_";
var MAX_PENDING_TRIGGERS = 20;
var DeepdotsPopups = class {
  constructor() {
    this.config = null;
    this.listeners = /* @__PURE__ */ new Map();
    this.triggers = [];
    this.initialized = false;
    this.renderer = createDefaultRenderer();
    /** Logger para el output de debug. Default `console`; el host puede inyectar el suyo en init(). */
    this.logger = console;
    this.popupDefinitions = [];
    this.popupsLoaded = false;
    /**
     * `true` mientras el `GET /sdk/{apiKey}/popups` de `init()` está en vuelo. En esa ventana los
     * disparos del host (`triggerEvent`, `triggerSurvey`) no tienen contra qué evaluarse, así que
     * se guardan en `pendingTriggers` y se reproducen al cargar. Click, scroll, time y exit no
     * hacen falta: son listeners que `autoLaunch` instala ya con las definiciones cargadas.
     */
    this.awaitingPopups = false;
    this.pendingTriggers = [];
    this.pendingAutoLaunch = false;
    // Estado que alimenta las reglas de redisplay. Copia de trabajo en memoria; la fuente
    // duradera es el storage (`popup-state-store`), rehidratada en `init()` — sin eso, una
    // recarga reiniciaba el cooldown y el popup volvía a salir. `answeredSurveys` se deriva
    // de las entradas COMPLETED de `surveyProgress` (los dos los escribe `markSurveyAnswered`).
    this.answeredSurveys = /* @__PURE__ */ new Set();
    this.surveyProgress = /* @__PURE__ */ new Map();
    this.lastShown = /* @__PURE__ */ new Map();
    // popupId -> timestamp mostrado
    this.surveyToPopupId = /* @__PURE__ */ new Map();
    // surveyId -> popupId
    this.deferredExitTimers = [];
    this.baseUrl = "";
    this.env = "production";
    /** Si el SDK pinta el "modal" del popup (RN). Default true; false = el host lo envuelve. */
    this.renderChrome = true;
    /** Barra de progreso. undefined = la decide la plataforma (style.showProgressBar). */
    this.showProgressBar = void 0;
    /** CSS del host inyectado al final de los estilos del popup. */
    this.surveyCss = void 0;
    this.cspNonce = void 0;
    /** Identidad + sesión (Fase 1 tracking). Null hasta init(). */
    this.tracking = null;
    /** Capa de analytics (canal separado del feedback). Null hasta init(). */
    this.analytics = null;
    /** feedbackSessionId cacheado del canal de analytics (devuelto por POST /sdk/feedback). */
    this.analyticsFeedbackSessionId = void 0;
    /** `init({ onFeedbackSession })`: avisa al host al abrir y cerrar cada registro. */
    this.onFeedbackSession = void 0;
    /** Timer del flush periódico de analytics (cada ANALYTICS_FLUSH_INTERVAL_MS). */
    this.analyticsFlushTimer = void 0;
    /** Crash & error reporting (#14–17). Null hasta init(). */
    this.crashReporter = null;
    /** ErrorUtils de RN recibido del host (o del Provider); se engancha en cuanto haya consentimiento. */
    this.rnErrorUtils = null;
    /** Protecciones del funnel de Messaging (#18–22). Vigencia de sesión: se reinicia en init(). */
    this.messageGuard = new MessageGuard();
    /** Observador de navegación (Fase 2): emite page_view por el canal de analytics. */
    this.navObserver = null;
    /** Tiempo activo (engagement time, #8). */
    this.engagement = null;
    /** Atributos internos del usuario identificado → POST /sdk/popups/contact. Null si no hay userId. */
    this.contact = null;
    /** Storage resuelto en init() (inyectado por el host o localStorage). Reusado al cambiar de usuario. */
    this.storage = null;
    /** Marca si ya se inició la navegación manual (setScreen) — para RN sin History API. */
    this.navStarted = false;
    /**
     * `true` entre `session_start` y `session_end`. Hace idempotente tanto la apertura como
     * el cierre (p. ej. `visibilitychange` + `pagehide` seguidos) y permite abrir una sesión
     * nueva al volver a foreground o al conceder el consentimiento más tarde.
     */
    this.sessionOpen = false;
    /** Último `user_engagement` emitido (ms epoch): marca el latido. */
    this.lastEngagementAt = 0;
    /** Cuándo se ocultó la pestaña por última vez (ms epoch); null si está visible. */
    this.hiddenAt = null;
    /**
     * Sesión suspendida por un `pagehide` (ms epoch y `deepdots_user_id`); null si no hay.
     * `openSession` la reanuda si sigue a tiempo (ver ANALYTICS_RESUME_WINDOW_MS).
     */
    this.suspended = null;
    /** Integración de analytics del init: la sesión suspendida solo la hereda la misma. */
    this.analyticsIntegration = void 0;
    /**
     * Idioma resuelto en init() (explícito > navigator.language > Intl). Única fuente de
     * verdad para el context de analytics Y para la segmentación por idioma de los popups.
     */
    this.language = void 0;
    /** `geolocation` del init: si es false no se usa ni la caché ni el lookup. */
    this.geoEnabled = true;
    /** Solo se consulta a terceros si el país/ciudad se va a enviar (analytics configurado). */
    this.geoWanted = false;
    /** Evita más de un lookup por instancia (el consentimiento puede ir y venir). */
    this.geoLookupStarted = false;
  }
  /** Initialize the SDK with configuration */
  init(config) {
    this.logger = config.logger ?? console;
    setLogger(this.logger);
    if (this.initialized) {
      const nextUserId = config.userId || void 0;
      if (nextUserId !== this.config?.userId) {
        this.setUserId(nextUserId);
        return;
      }
      this.log("SDK already initialized");
      return;
    }
    const env = resolveEnvironment(config.nodeEnv);
    this.baseUrl = env.apiBaseUrl;
    this.env = config.nodeEnv || "production";
    this.renderChrome = config.renderChrome ?? true;
    this.showProgressBar = config.showProgressBar;
    this.surveyCss = config.surveyCss;
    this.cspNonce = config.cspNonce;
    this.onFeedbackSession = config.onFeedbackSession;
    this.config = {
      apiKey: config.apiKey || void 0,
      debug: config.debug || false,
      userId: config.userId || void 0
    };
    const storage = config.storage ?? createDefaultStorage();
    this.storage = storage;
    this.loadPopupState(storage);
    this.tracking = new TrackingManager({
      storage,
      clientUserId: this.config.userId,
      enabled: config.trackingEnabled ?? true
    });
    if (this.config.userId) {
      const userId = this.config.userId;
      const publicKey = this.config.apiKey ?? "";
      this.contact = new ContactManager({
        storage,
        publicKey,
        userId,
        post: (body) => this.postContact(body)
      });
      if (config.contactAttributes) {
        void this.setContactAttributes(config.contactAttributes);
      }
    }
    this.log("tracking \xB7 user_id:", this.tracking.getUserId(), "\xB7 new_user:", this.tracking.isNewUser(), "\xB7 enabled:", this.tracking.isTrackingEnabled());
    this.analyticsIntegration = config.analytics?.integration;
    const resumable = this.readResumableSession();
    if (resumable) {
      this.analyticsFeedbackSessionId = resumable.sessionId;
      this.suspended = { at: resumable.at, userId: resumable.userId };
    }
    const analyticsSink = config.analytics ? createFeedbackSink({
      baseUrl: this.baseUrl,
      keys: config.analytics,
      log: (...a) => this.log(...a),
      initialSessionId: resumable?.sessionId,
      // En móvil (RN) la app puede morir con el lote de cierre sin entregar: se
      // persiste y se reenvía en el arranque siguiente. En web el cierre sale con
      // `keepalive` y varias pestañas compartirían el mismo storage.
      storage: (config.platform ?? "web") !== "web" ? storage : void 0,
      onSessionId: (id) => {
        this.analyticsFeedbackSessionId = id;
        this.notifyFeedbackSession(id, "open");
      },
      onSessionClosed: (id) => this.notifyFeedbackSession(id, "closed"),
      onSessionReset: () => {
        this.analyticsFeedbackSessionId = void 0;
      }
    }) : createDryRunSink((...a) => {
      if (this.config?.debug) this.logger.log(...a);
    });
    const device = config.device ?? collectDeviceInfo(config.appVersion);
    this.language = resolveLanguage({
      explicit: config.language,
      navigator: typeof navigator !== "undefined" ? navigator : void 0,
      intl: typeof Intl !== "undefined" ? Intl : void 0
    });
    this.messageGuard.reset();
    this.analytics = new AnalyticsManager({
      sink: analyticsSink,
      publicKey: config.analytics?.publicKey ?? this.config.apiKey,
      language: this.language,
      platform: config.platform ?? "web",
      device,
      maxBatchSize: ANALYTICS_MAX_BATCH_SIZE,
      onFlushNeeded: () => this.flushAnalytics()
    });
    this.crashReporter = new CrashReporter({
      storage,
      emit: (params) => this.track("deepdots_app_crash", params),
      device: () => ({ appVersion: device.app_version, osVersion: device.os_version, deviceModel: device.device_model }),
      sessionId: () => this.tracking?.getSessionId() ?? null,
      now: () => Date.now(),
      enabled: () => this.tracking?.isTrackingEnabled() ?? false
    });
    this.installCrashHandlers();
    this.geoEnabled = config.geolocation ?? true;
    this.geoWanted = this.geoEnabled && !!config.analytics;
    this.resolveGeo();
    this.navObserver = new NavigationObserver();
    this.navObserver.onVisit(
      (v) => this.track("deepdots_page_view", { screen: v.screen, path: v.path, duration_seconds: v.durationSeconds })
    );
    this.navObserver.install();
    this.engagement = new EngagementTracker();
    this.setupAnalyticsFlush();
    this.openSession("cold_start");
    if (resumable && this.analyticsFeedbackSessionId === resumable.sessionId) {
      this.notifyFeedbackSession(resumable.sessionId, "open");
    }
    const pendingCrashes = this.crashReporter.drainPendingCrashes();
    if (this.tracking?.isTrackingEnabled()) {
      for (const rec of pendingCrashes) {
        this.track("deepdots_app_crash", crashRecordToParams(rec));
      }
    }
    this.initialized = true;
    this.log("SDK initialized", this.config);
    if (this.renderer.init) this.renderer.init();
    this.awaitingPopups = Boolean(this.config.apiKey && this.baseUrl);
    this.fetchPopupsFromServer().then((defs) => {
      if (!defs) this.dropPendingTriggers();
      this.popupDefinitions = this.validatePopupDefinitions(defs ?? []);
      this.popupsLoaded = true;
      this.log("Popups loaded from API", this.popupDefinitions);
      if (this.popupDefinitions.length) this.renderer.preload?.();
      this.configureTriggersFromDefinitions();
      this.processDeferredExitQueue();
      if (this.pendingAutoLaunch) {
        this.startTriggers();
      }
      this.replayPendingTriggers();
    });
  }
  /** User id actual (generado por el SDK o provisto por el cliente). Null si tracking off. */
  getUserId() {
    return this.tracking?.getUserId() ?? null;
  }
  /** Session id de navegación actual. Null si tracking off. */
  getSessionId() {
    return this.tracking?.getSessionId() ?? null;
  }
  /**
   * Id del registro de analytics abierto: el `sessionId` que devolvió `POST /sdk/feedback`,
   * que la API guarda como `sdkSessionId` en el Feedback en que se convierte la sesión. No es
   * `getSessionId()`. Null hasta que el backend acepta el primer lote y de nuevo al cerrar la
   * sesión: para saber también qué registro se cerró, usa `init({ onFeedbackSession })`.
   */
  getFeedbackSessionId() {
    return this.analyticsFeedbackSessionId ?? null;
  }
  /** Avisa al host del registro abierto o cerrado; un fallo del host no corta el envío. */
  notifyFeedbackSession(sessionId, status) {
    try {
      this.onFeedbackSession?.({ sessionId, status });
    } catch (error) {
      this.log("analytics \xB7 onFeedbackSession threw:", error);
    }
  }
  /** Activa/desactiva el tracking (identidad + sesión + analytics). Kill-switch del contrato §7bis. */
  setTrackingEnabled(enabled) {
    if (!enabled) this.closeSession("tracking_disabled");
    this.tracking?.setTrackingEnabled(enabled);
    if (enabled) this.openSession("tracking_enabled");
    if (enabled) this.installCrashHandlers();
    if (enabled) this.resolveGeo();
    this.log("tracking \xB7 setTrackingEnabled:", enabled, "\xB7 session_id:", this.tracking?.getSessionId() ?? null);
  }
  // ───────── Analytics (canal separado del feedback, vinculado por user_id) ─────────
  /** Registra un evento de analítica (modelo GA: nombre + params). No-op si tracking off. */
  track(name, params) {
    if (!this.tracking?.isTrackingEnabled()) return;
    const eventName = name.startsWith(RESERVED_EVENT_PREFIX) ? name : `${CUSTOM_EVENT_PREFIX}${name}`;
    this.analytics?.track(eventName, params);
    this.log("analytics \xB7 track:", eventName, params ?? {});
  }
  /** User attributes para breakdowns (registration_status, pass_type, sector, pass_status…). */
  setUserAttributes(attributes) {
    if (!this.tracking?.isTrackingEnabled()) return;
    this.analytics?.setUserAttributes(attributes);
  }
  /**
   * Registra/actualiza una métrica (valor medible) → `feedback.metrics` del body.
   * Persistente y sobrescribe por key. No-op si tracking off.
   */
  setMetric(key, value) {
    if (!this.tracking?.isTrackingEnabled()) return;
    this.analytics?.setMetric(key, value);
    this.log("analytics \xB7 setMetric:", key, value);
  }
  /** Reporta un error del host (manejado o no) → evento `deepdots_app_crash`. No-op si tracking off. */
  reportError(error, options) {
    if (!this.tracking?.isTrackingEnabled()) return;
    this.crashReporter?.reportError(error, options);
  }
  /**
   * Engancha `global.ErrorUtils` de RN para capturar errores JS no manejados. Con tracking off
   * se recuerda y se engancha cuando se conceda el consentimiento (`setTrackingEnabled(true)`).
   */
  installReactNativeCrashHandler(errorUtils) {
    this.rnErrorUtils = errorUtils;
    this.installCrashHandlers();
  }
  /**
   * Pone los handlers de errores no capturados: `window` en web y `ErrorUtils` en RN (el que
   * pasó el host o, si no pasó ninguno, `globalThis.ErrorUtils`, para que un `init()` sin
   * `setupReactNative` también capture). Solo con consentimiento; idempotente, así que se
   * llama en `init()` y cada vez que se activa el tracking.
   */
  installCrashHandlers() {
    if (!this.crashReporter || !this.tracking?.isTrackingEnabled()) return;
    this.crashReporter.install();
    const errorUtils = this.rnErrorUtils ?? globalThis.ErrorUtils;
    if (errorUtils && typeof errorUtils.setGlobalHandler === "function") {
      this.crashReporter.installReactNative(errorUtils);
    }
  }
  /**
   * Info interna del usuario que solo conoce el host (idioma, edad, plan…), persistida en el
   * Contact del backend para segmentación/targeting de popups. Identificada por el `userId` del
   * init. Solo envía si los atributos cambiaron (diff en storage). No-op si tracking off o sin userId.
   * @returns `true` si se envió al backend, `false` si no hubo cambios o está deshabilitado.
   */
  async setContactAttributes(attributes) {
    if (!this.tracking?.isTrackingEnabled()) return false;
    if (!this.contact) return false;
    return this.contact.setAttributes(attributes);
  }
  /** Marca el inicio de un mini-service; etiqueta los eventos siguientes. No-op si tracking off. */
  enterMiniService(name, entryPointType) {
    if (!this.tracking?.isTrackingEnabled()) return;
    this.analytics?.enterMiniService(name, entryPointType);
    this.log("analytics \xB7 enterMiniService:", name, entryPointType ?? "");
  }
  /** Cierra el mini-service `name` (emite `mini_service_exit` con duración, #27). No-op si tracking off o si ese no está activo. */
  exitMiniService(name) {
    if (!this.tracking?.isTrackingEnabled()) return;
    this.analytics?.exitMiniService(name);
    this.log("analytics \xB7 exitMiniService:", name);
  }
  /** Findability (#31/#35): registra una búsqueda. `has_results` se deriva de `resultsCount`. */
  trackSearch(query, resultsCount, params) {
    this.track("deepdots_search", { query, results_count: resultsCount, has_results: resultsCount > 0, ...params ?? {} });
  }
  /** Findability friction (#34/#35): señal de fricción con su `friction_topic`. */
  trackFindabilityFriction(frictionTopic, params) {
    this.track("deepdots_findability_friction", { friction_topic: frictionTopic, ...params ?? {} });
  }
  /** Funnel: un paso del embudo, correlacionado por `taskId`. El backend reconstruye conversión/drop-off/tiempo. */
  trackFunnelStep(funnel, step, taskId, params) {
    this.track("deepdots_funnel_step", { funnel, step, task_id: taskId, ...params ?? {} });
  }
  /**
   * Product Effectiveness: una interacción significativa del usuario (`interaction_type` es la
   * dimensión de agrupación, p. ej. `get_help`, `homepage`, `contact_support`).
   *
   * Existe como evento RESERVADO para que la convención no la invente cada host: un `track()`
   * custom acaba como `deepdots_event_…` y no lo cuenta la analítica de effectiveness.
   * Un `interactionType` vacío se descarta con warning (no aporta dato agrupable).
   */
  trackMeaningfulInteraction(interactionType, params) {
    const type = typeof interactionType === "string" ? interactionType.trim() : "";
    if (!type) {
      console.warn("[DeepdotsPopups] trackMeaningfulInteraction discarded: empty interaction_type");
      return;
    }
    this.track("deepdots_meaningful_interaction", { interaction_type: type, ...params ?? {} });
  }
  /**
   * Messaging (#18–22): registra una etapa del funnel de una notificación (push/in-app).
   * No-op si tracking off. El evento se descarta (con warning) si el `channel` no es válido,
   * si ese `(message_id, stage)` ya se emitió en la sesión, o si el `message_id` ya se reportó
   * en otro canal — ver `MessageGuard`.
   */
  trackMessage(stage, options) {
    const verdict = this.messageGuard.evaluate(stage, options);
    if (!verdict.emit) {
      console.warn(`[DeepdotsPopups] trackMessage discarded (${verdict.reason}): ${verdict.detail}`);
      return;
    }
    this.track("deepdots_message", buildMessageParams(stage, options));
  }
  /**
   * Navegación MANUAL (entornos sin History API, p. ej. React Native con React Navigation).
   * El host la llama en cada cambio de pantalla; emite `page_view` al salir de la anterior.
   */
  setScreen(name) {
    if (!this.navObserver) return;
    if (!this.navStarted) {
      this.navObserver.begin(name);
      this.navStarted = true;
    } else {
      this.navObserver.visit(name);
    }
  }
  /** App a foreground (RN: AppState 'active'): reanuda el engagement time y abre sesión nueva. */
  onForeground() {
    this.engagement?.resume();
    this.openSession("foreground");
  }
  /**
   * App a background (RN: AppState 'background'): FIN DE SESIÓN. Cierra pantalla actual
   * (page_view), mini-services (mini_service_exit), emite engagement + `session_end` y
   * envía el último lote con `completed:true`.
   *
   * Es la única señal disponible en móvil: el kill de la app (swipe) NO da callback.
   */
  onBackground() {
    this.closeSession("background");
    this.engagement?.pause();
  }
  /**
   * Cierre EXPLÍCITO de la sesión por parte del host (logout, fin de flujo…): emite
   * `session_end` y envía el último lote con `completed:true`.
   */
  endSession() {
    this.closeSession("manual");
  }
  /**
   * Cambio de usuario (login / logout / cambio de cuenta). Cierra la sesión del usuario
   * anterior (`session_end` con `reason: 'user_change'` + `completed:true`), cambia la
   * identidad y abre una sesión nueva. Sin `userId` vuelve al id anónimo del SDK.
   *
   * Equivale a llamar a `init()` otra vez con otro `userId`.
   */
  setUserId(userId) {
    const next = userId || void 0;
    if (!this.initialized || !this.config || next === this.config.userId) return;
    this.closeSession("user_change");
    const enabled = this.tracking?.isTrackingEnabled() ?? true;
    const storage = this.storage ?? createDefaultStorage();
    this.config.userId = next;
    this.tracking = new TrackingManager({ storage, clientUserId: next, enabled });
    this.contact = next ? new ContactManager({
      storage,
      publicKey: this.config.apiKey ?? "",
      userId: next,
      post: (body) => this.postContact(body)
    }) : null;
    this.analytics?.resetUserScope();
    this.messageGuard.reset();
    this.lastShown.clear();
    this.surveyProgress.clear();
    this.answeredSurveys.clear();
    clearPopupState(storage);
    this.log("tracking \xB7 user_change \xB7 user_id:", this.tracking.getUserId());
    this.openSession("user_change");
  }
  /**
   * Cierra la sesión actual: vuelca todo lo que quedaba abierto y envía el último lote
   * marcado con `completed:true`, para que el backend cierre el registro. El `sessionId`
   * cacheado se olvida → el lote siguiente abre un registro nuevo.
   *
   * Idempotente: dos cierres seguidos (p. ej. `visibilitychange` + `pagehide`) no duplican
   * el `session_end`.
   */
  closeSession(reason) {
    if (!this.sessionOpen) return;
    if (!this.tracking?.isTrackingEnabled()) return;
    this.sessionOpen = false;
    this.navObserver?.stop();
    this.navStarted = false;
    this.analytics?.exitAllMiniServices();
    this.flushEngagement();
    this.engagement?.pause();
    this.track("deepdots_session_end", { reason });
    this.flushAnalytics({ final: reason === "page_hide", sessionEnd: true });
    this.analyticsFeedbackSessionId = void 0;
    this.tracking?.setSessionId(null);
    this.log("tracking \xB7 session_end:", reason);
  }
  /**
   * Abre sesión (`session_start`) si no hay una abierta y el tracking está activo. Idempotente.
   * El `reason` dice por qué empieza (ver `SessionStartReason`):
   *  - `cold_start`: init() (carga de la página / arranque de la app RN).
   *  - `foreground`: onForeground() tras un cierre (RN).
   *  - `tracking_enabled`: setTrackingEnabled(true).
   *  - `user_change`: setUserId() o init() con otro userId.
   *  - `idle_timeout`: la pestaña vuelve a verse tras más de 30 min oculta.
   *  - `bfcache_restore`: vuelta desde la bfcache fuera de la ventana de reanudación.
   * Si hay una sesión suspendida a tiempo emite `deepdots_session_resume` en su lugar, sin reason.
   */
  openSession(reason) {
    if (this.sessionOpen) return;
    if (!this.tracking?.isTrackingEnabled()) return;
    const suspendedMs = this.takeSuspendedSession();
    this.sessionOpen = true;
    this.lastEngagementAt = Date.now();
    if (suspendedMs === null) {
      this.track("deepdots_session_start", { reason });
    } else {
      this.track("deepdots_session_resume", { suspended_ms: suspendedMs });
      this.log("tracking \xB7 session resumed after", suspendedMs, "ms:", this.analyticsFeedbackSessionId);
    }
    this.navObserver?.restart();
    if (this.isDocumentVisible()) this.engagement?.resume();
  }
  /** Web: si la pestaña se ve. Sin `document` (RN) manda AppState vía onForeground/onBackground. */
  isDocumentVisible() {
    return typeof document === "undefined" || document.visibilityState !== "hidden";
  }
  /** Payload que se ENVIARÍA al endpoint de analytics (no envía ni vacía el buffer). */
  previewAnalytics() {
    return this.analytics?.buildPayload(this.analyticsIdentity()) ?? {
      userId: null,
      sessionId: null,
      context: { platform: "web", attributes: {} },
      events: []
    };
  }
  /**
   * Envía el lote acumulado de analytics y vacía el buffer.
   * `final: true` (cierre de página/app): el lote no espera al primer POST en vuelo, porque
   * el documento se muere; un lote que falle por red o 5xx se re-encola para el siguiente flush.
   */
  flushAnalytics(options) {
    if (!this.tracking?.isTrackingEnabled()) return;
    this.analytics?.flush(this.analyticsIdentity(), options);
  }
  /**
   * Emite un evento `user_engagement` con el tiempo activo acumulado (#8) y la pantalla en
   * curso: `screen` y `path` (los mismos que llevará su `page_view`) y `screen_seconds` (lo
   * que lleva en ella, medido como el `duration_seconds` del `page_view`).
   *
   * El `page_view` sale al SALIR de la pantalla; si el cierre no llega nunca (pestaña dormida
   * y descartada al volver, pestaña o app matada en segundo plano), la última pantalla de la
   * sesión se perdía y una visita de una sola pantalla se quedaba sin ninguna. Con la pantalla
   * en el latido y en el engagement de ocultar la pestaña, el backend la reconstruye.
   *
   * En los cierres (`closeSession`, `suspendSession`) el observador ya emitió el `page_view`
   * y no tiene pantalla, así que ese engagement va sin `screen`: nunca se cuenta dos veces.
   * Tampoco se emite un `page_view` aquí, por lo mismo.
   */
  flushEngagement() {
    if (!this.tracking?.isTrackingEnabled()) return;
    const ms = this.engagement?.consume() ?? 0;
    if (ms > 0) {
      const current = this.navObserver?.current();
      this.track("deepdots_user_engagement", {
        engagement_time_msec: ms,
        ...current ? { screen: current.screen, path: current.path, screen_seconds: current.seconds } : {}
      });
      this.lastEngagementAt = Date.now();
    }
  }
  /** Tick del flush periódico: latido de engagement si toca, y envío de lo acumulado. */
  onAnalyticsFlushTick() {
    if (this.sessionOpen && this.isDocumentVisible() && Date.now() - this.lastEngagementAt >= ANALYTICS_HEARTBEAT_MS) {
      this.flushEngagement();
    }
    this.flushAnalytics();
  }
  /**
   * La pestaña vuelve a verse. Tras más de ANALYTICS_SESSION_TIMEOUT_MS oculta, la sesión
   * anterior termina y empieza otra: seguir con el mismo sessionId mezclaba dos visitas y,
   * si el backend ya la había cerrado por inactividad, la partía en dos feedbacks.
   *  - Oculta menos de ANALYTICS_SESSION_DISCARD_MS: el backend aún la tiene abierta → se
   *    cierra con normalidad (page_view de la pantalla, session_end `idle_timeout`, completed).
   *  - Más: ya la cerró el backend → se descarta sin enviar nada.
   */
  onDocumentVisible() {
    const hiddenFor = this.hiddenAt === null ? 0 : Date.now() - this.hiddenAt;
    this.hiddenAt = null;
    if (!this.sessionOpen) return;
    if (hiddenFor < ANALYTICS_SESSION_TIMEOUT_MS) {
      this.engagement?.resume();
      return;
    }
    if (hiddenFor < ANALYTICS_SESSION_DISCARD_MS) {
      this.closeSession("idle_timeout");
    } else {
      this.discardSession();
    }
    this.openSession("idle_timeout");
  }
  /**
   * `pagehide` en web: SUSPENDE la sesión en vez de cerrarla, porque el navegador lo lanza
   * igual al recargar que al cerrar la pestaña. Vuelca lo pendiente (page_view de la
   * pantalla, mini-services, engagement) con un `deepdots_session_suspend` y SIN
   * `completed`, y deja el registro en `sessionStorage` (ver `suspended-session.ts`):
   *  - si la página vuelve a cargar en esta pestaña, `init()` sigue en el mismo registro;
   *  - si la pestaña se cerró, el backend lo cierra a los pocos minutos sin otro lote.
   *
   * Devuelve false cuando no se puede suspender — aún no se conoce el registro (el primer
   * POST sigue en vuelo) o no hay `sessionStorage` — y entonces el caller cierra como antes.
   */
  suspendSession() {
    if (!this.sessionOpen || !this.tracking?.isTrackingEnabled()) return false;
    const sessionId = this.analyticsFeedbackSessionId;
    const integration = this.analyticsIntegration;
    const storage = getSessionStorage();
    if (!sessionId || !integration || !storage) return false;
    const at = Date.now();
    const userId = this.tracking.getUserId();
    if (!writeSuspendedSession(storage, { sessionId, integration, userId, at })) return false;
    this.sessionOpen = false;
    this.suspended = { at, userId };
    this.navObserver?.stop();
    this.navStarted = false;
    this.analytics?.exitAllMiniServices();
    this.flushEngagement();
    this.engagement?.pause();
    this.track("deepdots_session_suspend", { reason: "page_hide" });
    this.flushAnalytics({ final: true });
    this.log("tracking \xB7 session suspended:", sessionId);
    return true;
  }
  /**
   * Recoge la sesión que dejó suspendida la carga anterior de esta pestaña (ver
   * `suspendSession`). Solo con analytics configurado y el tracking activo: sin ellos no hay
   * registro en el que seguir.
   */
  readResumableSession() {
    const integration = this.analyticsIntegration;
    const storage = getSessionStorage();
    if (!integration || !storage || !this.tracking?.isTrackingEnabled()) return null;
    return takeSuspendedSession(
      storage,
      { integration, userId: this.tracking.getUserId() },
      Date.now(),
      ANALYTICS_RESUME_WINDOW_MS
    );
  }
  /**
   * Consume la sesión suspendida al abrir: los ms que estuvo suspendida si se puede seguir en
   * ella (mismo usuario, dentro de ANALYTICS_RESUME_WINDOW_MS); null si no había o ya no toca.
   * En ese caso se olvida su registro sin enviar nada: lo cierra el backend, y la sesión que
   * se abre ahora va a uno nuevo.
   */
  takeSuspendedSession() {
    const suspended = this.suspended;
    if (!suspended) return null;
    this.suspended = null;
    const storage = getSessionStorage();
    if (storage) clearSuspendedSession(storage);
    const suspendedMs = Math.max(0, Date.now() - suspended.at);
    if (this.analyticsFeedbackSessionId && suspendedMs <= ANALYTICS_RESUME_WINDOW_MS && suspended.userId === (this.tracking?.getUserId() ?? null)) {
      return suspendedMs;
    }
    this.analytics?.discardSession(this.analyticsIdentity());
    this.analyticsFeedbackSessionId = void 0;
    this.tracking?.setSessionId(null);
    return null;
  }
  /** Olvida la sesión abierta sin enviar nada (ver onDocumentVisible). */
  discardSession() {
    this.sessionOpen = false;
    this.navObserver?.discard();
    this.analytics?.discardSession(this.analyticsIdentity());
    this.engagement?.consume();
    this.engagement?.pause();
    this.analyticsFeedbackSessionId = void 0;
    this.tracking?.setSessionId(null);
    this.log("tracking \xB7 session discarded after", ANALYTICS_SESSION_DISCARD_MS / 6e4, "min hidden");
  }
  /**
   * Geolocalización por IP (país/ciudad para analytics). La caché persistente es local y se
   * aplica siempre que `geolocation` no esté desactivado. El lookup a terceros (ipapi.co →
   * ipwho.is → ipinfo.io, fallback con timeout) solo se hace si el dato se va a ENVIAR:
   * analytics configurado + tracking activo + caché ausente o caducada. Una vez por instancia.
   */
  resolveGeo() {
    const storage = this.storage;
    if (!this.geoEnabled || !storage || !this.analytics) return;
    const cachedGeo = readCachedGeo(storage, Date.now());
    if (cachedGeo) {
      this.analytics.updateDevice(cachedGeo);
      return;
    }
    if (!this.geoWanted || this.geoLookupStarted) return;
    if (!this.tracking?.isTrackingEnabled()) return;
    this.geoLookupStarted = true;
    fetchGeo().then((geo) => {
      if (geo) {
        this.analytics?.updateDevice(geo);
        writeCachedGeo(storage, geo, Date.now());
      }
    }).catch(() => {
    });
  }
  analyticsIdentity() {
    return {
      userId: this.tracking?.getUserId() ?? null,
      sessionId: this.tracking?.getSessionId() ?? null
    };
  }
  /** Flush automático al ocultar/cerrar la página (no perder el lote pendiente). */
  setupAnalyticsFlush() {
    this.startAnalyticsFlushTimer();
    if (typeof document === "undefined" || typeof window === "undefined") return;
    window.addEventListener("pagehide", () => {
      clearInterval(this.analyticsFlushTimer);
      if (!this.suspendSession()) this.closeSession("page_hide");
    });
    window.addEventListener("pageshow", (event) => {
      if (!event.persisted) return;
      this.startAnalyticsFlushTimer();
      this.openSession("bfcache_restore");
    });
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "hidden") {
        this.flushEngagement();
        this.engagement?.pause();
        this.flushAnalytics();
        this.hiddenAt = Date.now();
      } else if (document.visibilityState === "visible") {
        this.onDocumentVisible();
      }
    });
  }
  startAnalyticsFlushTimer() {
    clearInterval(this.analyticsFlushTimer);
    this.analyticsFlushTimer = setInterval(() => this.onAnalyticsFlushTick(), ANALYTICS_FLUSH_INTERVAL_MS);
  }
  /** Enable auto-launch functionality with configured triggers */
  autoLaunch() {
    if (!this.initialized) {
      throw new Error("SDK not initialized. Call init() first.");
    }
    if (!this.popupsLoaded) {
      this.pendingAutoLaunch = true;
      this.log("Auto-launch deferred until popups are loaded");
      return;
    }
    this.startTriggers();
  }
  /** Inicia los triggers configurados */
  startTriggers() {
    this.log("Auto-launch enabled");
    this.triggers.forEach((trigger) => setupTrigger(this, trigger));
  }
  /** Configure triggers for auto-launching popups (manual) */
  configureTriggers(triggers) {
    if (!this.initialized) {
      throw new Error("SDK not initialized. Call init() first.");
    }
    this.triggers = triggers;
    this.log("Triggers configured", triggers);
  }
  /** Deriva triggers desde las definiciones de popup */
  configureTriggersFromDefinitions() {
    const derived = [];
    this.debug("Validated popup definitions", this.popupDefinitions);
    this.popupDefinitions.forEach((def) => {
      def.triggers.forEach((trigger) => {
        const type = this.mapPopupTriggerType(trigger.type);
        if (!type) {
          this.debug("Unsupported trigger type", trigger.type);
          return;
        }
        const value = type === "time" && typeof trigger.value === "number" ? trigger.value * 1e3 : trigger.value;
        derived.push({ type, value, surveyId: def.surveyId, popupId: def.id });
      });
    });
    if (derived.length) {
      this.configureTriggers(derived);
    }
  }
  /** Lógica para evaluar condiciones antes de mostrar una encuesta */
  triggerSurvey(surveyId, popupId) {
    if (this.bufferIfAwaitingPopups({ kind: "survey", surveyId, popupId })) return;
    const def = this.findPopupDefinition(surveyId, popupId);
    if (!def) {
      this.debug("No popup definition for trigger", { surveyId, popupId });
      return;
    }
    if (!this.shouldShow(def)) {
      this.debug("Conditions prevented showing popup", def.id);
      return;
    }
    this.showDefinition(def);
  }
  /** Trigger popups configured with trigger.type = 'event' and matching trigger.value */
  triggerEvent(eventName) {
    if (!this.initialized) {
      throw new Error("SDK not initialized. Call init() first.");
    }
    const normalized = String(eventName || "").trim();
    if (!normalized) {
      this.debug("Ignoring empty event trigger name");
      return;
    }
    if (this.bufferIfAwaitingPopups({ kind: "event", name: normalized })) return;
    this.evaluateEvent(normalized);
  }
  evaluateEvent(normalized) {
    const candidates = this.popupDefinitions.filter((def) => {
      return def.triggers.some((trigger) => {
        const triggerValue = String(trigger.value ?? "").trim();
        return trigger.type === "event" && triggerValue === normalized;
      });
    });
    if (!candidates.length) {
      this.debug("No event popup definitions found", { eventName: normalized });
      return;
    }
    const matched = candidates.find((def) => this.shouldShow(def));
    if (!matched) {
      this.debug("Event popup blocked by conditions/segments", { eventName: normalized });
      return;
    }
    this.showDefinition(matched);
  }
  /**
   * Guarda `trigger` si las definiciones aún no han llegado. Devuelve `true` si lo guardó (el
   * llamador no debe evaluarlo ahora) y `false` si no hay carga en vuelo (se evalúa ya, como
   * siempre: tras cargar, tras un fallo o sin apiKey).
   */
  bufferIfAwaitingPopups(trigger) {
    if (!this.awaitingPopups) return false;
    if (this.pendingTriggers.length >= MAX_PENDING_TRIGGERS) {
      const dropped = this.pendingTriggers.shift();
      this.debug("Pending trigger buffer full; dropped oldest", dropped);
    }
    this.pendingTriggers.push(trigger);
    this.debug("Popups not loaded yet; trigger buffered", trigger);
    return true;
  }
  /** La carga falló: sin definiciones no hay nada que reproducir, se descarta todo. */
  dropPendingTriggers() {
    const dropped = this.pendingTriggers.length;
    this.awaitingPopups = false;
    this.pendingTriggers = [];
    if (dropped > 0) this.debug("Popups failed to load; dropped pending triggers", dropped);
  }
  /** Reproduce en orden por la evaluación normal (segmentos, cooldowns y condiciones de AHORA). */
  replayPendingTriggers() {
    this.awaitingPopups = false;
    const replay = this.pendingTriggers;
    this.pendingTriggers = [];
    if (!replay.length) return;
    this.debug("Replaying triggers received before popups loaded", replay.length);
    replay.forEach((trigger) => {
      if (trigger.kind === "event") this.evaluateEvent(trigger.name);
      else this.triggerSurvey(trigger.surveyId, trigger.popupId);
    });
  }
  showDefinition(def) {
    if (this.renderer.isShowing?.()) {
      this.debug("Popup skipped: another popup is already open", def.id);
      return;
    }
    this.log("Showing popup (definition)", def);
    this.surveyToPopupId.set(def.surveyId, def.id);
    this.lastShown.set(def.id, Date.now());
    this.persistPopupState();
    this.renderPopup(def.surveyId, def.productId, def.actions, def.style, def.title);
    this.emitEvent("popup_shown", def.surveyId, { popupId: def.id });
  }
  shouldShow(def, pathUrl, skipPathCheck = false) {
    if (this.storage) this.loadPopupState(this.storage);
    if (this.isPathExcluded(def, pathUrl)) {
      return false;
    }
    if (!skipPathCheck && !this.matchesSegmentsPath(def, pathUrl)) {
      return false;
    }
    if (!this.matchesSegmentsLang(def)) {
      return false;
    }
    const cooldowns = def.cooldown || [];
    if (cooldowns.length && !cooldowns.every((cooldown) => this.evaluateCooldown(def, cooldown))) {
      return false;
    }
    const legacyConditions = def.legacyConditions || [];
    if (!legacyConditions.length) return true;
    return legacyConditions.every((condition) => this.evaluateLegacyCondition(def, condition));
  }
  matchesSegmentsLang(def) {
    const langs = def.segments?.lang;
    if (!langs || langs.length === 0) return true;
    const currentLang = (this.language ?? "").toLowerCase();
    if (!currentLang) {
      this.debug("No language available for lang comparison", { popupId: def.id, langs });
      return true;
    }
    const matches = langs.some(
      (lang) => typeof lang === "string" && currentLang.startsWith(lang.toLowerCase())
    );
    if (!matches) {
      this.debug("Lang mismatch for popup", { popupId: def.id, langs, currentLang });
    }
    return matches;
  }
  /** `segments.path`: rutas donde el popup PUEDE mostrarse. Sin lista, en todas. */
  matchesSegmentsPath(def, pathUrl) {
    const paths = def.segments?.path;
    if (!Array.isArray(paths) || paths.length === 0) return true;
    const location = this.resolveCurrentLocation(pathUrl);
    if (!location) {
      this.debug("No window.location available for path comparison", { popupId: def.id, paths });
      return true;
    }
    const matches = paths.some((rawCandidate) => {
      const match = this.matchesPathCandidate(rawCandidate, location);
      this.debug("Path comparison", {
        popupId: def.id,
        candidate: rawCandidate,
        currentPath: location.path,
        currentHref: location.href,
        match
      });
      return match;
    });
    if (!matches) {
      this.debug("No path match for popup", { popupId: def.id, paths, currentPath: location.path });
    }
    return matches;
  }
  /**
   * `segments.excludedPaths`: rutas donde el popup NO debe mostrarse. Gana sobre
   * `segments.path` (`path: ['/']` + `excludedPaths: ['/cart']` = en todas menos el
   * carrito) y se aplica también cuando no hay `path` (= en todas menos las excluidas).
   */
  isPathExcluded(def, pathUrl) {
    const excluded = def.segments?.excludedPaths;
    if (!Array.isArray(excluded) || excluded.length === 0) return false;
    const location = this.resolveCurrentLocation(pathUrl);
    if (!location) {
      this.debug("No window.location available for excluded path comparison", { popupId: def.id, excluded });
      return false;
    }
    const hit = excluded.find((rawCandidate) => this.matchesPathCandidate(rawCandidate, location));
    if (hit !== void 0) {
      this.debug("Popup excluded by path", {
        popupId: def.id,
        candidate: hit,
        currentPath: location.path,
        currentHref: location.href
      });
      return true;
    }
    return false;
  }
  /**
   * Compara UN candidato de `segments.path`/`segments.excludedPaths` con la ruta
   * actual. Mismas reglas para incluir y para excluir:
   *  - URL absoluta  → href completo exacto
   *  - empieza por / → subcadena del href (así entran las rutas con hash: `/#/home`)
   *  - resto         → pathname exacto
   * Ignora entradas que no sean string: el backend puede colar un `null` en la lista
   * y no puede tumbar la evaluación del trigger entero (mismo fallo que hubo con
   * `segments.lang`).
   */
  matchesPathCandidate(rawCandidate, location) {
    if (typeof rawCandidate !== "string") return false;
    const candidate = this.normalizeUrl(rawCandidate);
    if (!candidate) return false;
    if (candidate.startsWith("http://") || candidate.startsWith("https://")) {
      return location.href === candidate;
    }
    if (candidate.startsWith("/")) {
      return location.href.includes(candidate);
    }
    return location.path === candidate;
  }
  /** href + pathname normalizados de la ruta a evaluar, o null si no hay `window.location`. */
  resolveCurrentLocation(pathUrl) {
    if (typeof window === "undefined" || !window.location) return null;
    const href = this.normalizeUrl(pathUrl || window.location.href || "");
    const parsed = this.safeParseUrl(href);
    return { href, path: this.normalizeUrl(parsed?.pathname || window.location.pathname || "") };
  }
  evaluateCooldown(def, condition) {
    switch (condition.answered) {
      case "SHOWED":
        return this.hasCooldownElapsed(this.lastShown.get(def.id), condition.cooldownDays);
      case "PARTIAL":
      case "COMPLETED": {
        const progress = this.surveyProgress.get(def.surveyId);
        if (!progress || progress.status !== condition.answered) {
          return true;
        }
        return this.hasCooldownElapsed(progress.timestamp, condition.cooldownDays);
      }
      default:
        return true;
    }
  }
  evaluateLegacyCondition(def, condition) {
    if (!condition.answered && this.answeredSurveys.has(def.surveyId)) {
      return false;
    }
    return this.hasCooldownElapsed(this.lastShown.get(def.id), condition.cooldownDays);
  }
  hasCooldownElapsed(timestamp, cooldownDays) {
    if (!timestamp || !cooldownDays) {
      return true;
    }
    return Date.now() - timestamp >= cooldownDays * DAY_IN_MS;
  }
  /** Marcar encuesta como contestada externamente */
  markSurveyAnswered(surveyId) {
    this.answeredSurveys.add(surveyId);
    this.markSurveyProgress(surveyId, "COMPLETED");
  }
  /** Queue an exit popup so it can render after navigation */
  queueExitPopup(surveyId, delaySeconds, sourceUrl, popupId) {
    const def = this.findPopupDefinition(surveyId, popupId);
    if (!def) {
      this.debug("No popup definition for exit trigger", { surveyId, popupId });
      return;
    }
    const originUrl = sourceUrl || (typeof window !== "undefined" ? window.location.href : "");
    if (!originUrl) {
      this.debug("Exit popup skipped: missing source URL", { surveyId });
      return;
    }
    if (!this.shouldShow(def, originUrl)) {
      this.debug("Exit popup skipped by conditions/path", { popupId: def.id, sourceUrl: originUrl });
      return;
    }
    const safeDelayMs = Number.isFinite(delaySeconds) ? Math.max(0, delaySeconds * 1e3) : 0;
    const deferred = {
      id: def.id,
      surveyId: def.surveyId,
      sourceUrl: this.normalizeUrl(originUrl),
      dueAt: Date.now() + safeDelayMs
    };
    const queue = this.getDeferredExitQueue().filter((item) => !(item.id === deferred.id && item.sourceUrl === deferred.sourceUrl));
    queue.push(deferred);
    this.setDeferredExitQueue(queue);
    this.scheduleDeferredExitPopup(deferred);
    this.debug("Exit popup queued", deferred);
  }
  processDeferredExitQueue() {
    const queue = this.getDeferredExitQueue();
    if (!queue.length) return;
    const pending2 = [];
    const now = Date.now();
    queue.forEach((item) => {
      const def = this.popupDefinitions.find((popup) => popup.id === item.id && popup.surveyId === item.surveyId);
      if (!def) {
        return;
      }
      if (item.dueAt <= now) {
        this.tryShowDeferredExitPopup(item);
        return;
      }
      pending2.push(item);
      this.scheduleDeferredExitPopup(item);
    });
    this.setDeferredExitQueue(pending2);
  }
  scheduleDeferredExitPopup(item) {
    if (typeof window === "undefined") return;
    const delay = Math.max(0, item.dueAt - Date.now());
    const timer = window.setTimeout(() => this.tryShowDeferredExitPopup(item), delay);
    this.deferredExitTimers.push(timer);
  }
  tryShowDeferredExitPopup(item) {
    const def = this.popupDefinitions.find((popup) => popup.id === item.id && popup.surveyId === item.surveyId);
    if (!def) {
      this.removeDeferredExitPopup(item);
      return;
    }
    const currentUrl = typeof window !== "undefined" ? this.normalizeUrl(window.location.href || "") : "";
    if (!currentUrl || currentUrl === this.normalizeUrl(item.sourceUrl)) {
      this.removeDeferredExitPopup(item);
      this.debug("Exit popup dropped because route did not change", item);
      return;
    }
    if (!this.shouldShow(def, void 0, true)) {
      this.removeDeferredExitPopup(item);
      this.debug("Exit popup skipped at render-time conditions", item);
      return;
    }
    this.showDefinition(def);
    this.removeDeferredExitPopup(item);
  }
  findPopupDefinition(surveyId, popupId) {
    if (popupId) {
      const byId = this.popupDefinitions.find((popup) => popup.id === popupId);
      if (byId) return byId;
    }
    return this.popupDefinitions.find((popup) => popup.surveyId === surveyId);
  }
  removeDeferredExitPopup(item) {
    const queue = this.getDeferredExitQueue().filter((entry) => !(entry.id === item.id && entry.sourceUrl === item.sourceUrl));
    this.setDeferredExitQueue(queue);
  }
  getDeferredExitQueue() {
    if (typeof window === "undefined") return [];
    try {
      const raw = window.sessionStorage.getItem(EXIT_QUEUE_STORAGE_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];
      return parsed.filter((entry) => {
        if (typeof entry !== "object" || entry === null) return false;
        const item = entry;
        return typeof item.id === "string" && typeof item.surveyId === "string" && typeof item.sourceUrl === "string" && typeof item.dueAt === "number" && Number.isFinite(item.dueAt);
      }).map((item) => ({
        ...item,
        sourceUrl: this.normalizeUrl(item.sourceUrl)
      }));
    } catch {
      return [];
    }
  }
  setDeferredExitQueue(queue) {
    if (typeof window === "undefined") return;
    try {
      if (!queue.length) {
        window.sessionStorage.removeItem(EXIT_QUEUE_STORAGE_KEY);
        return;
      }
      window.sessionStorage.setItem(EXIT_QUEUE_STORAGE_KEY, JSON.stringify(queue));
    } catch {
    }
  }
  /** Fetch al servidor para obtener popups. `null` si la carga falló (red, no-2xx, payload inválido). */
  async fetchPopupsFromServer() {
    const apiKey = this.config?.apiKey;
    const baseUrl = this.baseUrl;
    const userId = this.tracking?.getUserId() ?? this.config?.userId;
    if (!apiKey || !baseUrl) {
      this.log("Missing apiKey or baseUrl. Skipping popups fetch.");
      return [];
    }
    const filter = userId ? { where: { userId } } : null;
    const query = filter ? `?filter=${encodeURIComponent(JSON.stringify(filter))}` : "";
    const endpoint = `${baseUrl}/sdk/${encodeURIComponent(apiKey)}/popups${query}`;
    try {
      const response = await fetch(endpoint);
      if (!response.ok) {
        this.log("Failed to fetch popups", response.status, response.statusText);
        return null;
      }
      const raw = await response.text();
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) {
        this.log("Unexpected popups payload", parsed);
        return null;
      }
      this.debug("Fetched popups payload", parsed);
      return parsed;
    } catch (error) {
      this.log("Error fetching popups", error);
      return null;
    }
  }
  /**
   * Envía los atributos de contact a la API (`POST /sdk/popups/contact`). Rechaza si no se
   * pudo enviar (sin red o respuesta no-2xx), para que `ContactManager` no guarde la caché
   * y la llamada siguiente reintente.
   */
  async postContact(body) {
    const baseUrl = this.baseUrl;
    if (!baseUrl) throw new Error("no base URL");
    const endpoint = `${baseUrl}/sdk/popups/contact`;
    let response;
    try {
      response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
    } catch (error) {
      this.log("Error posting contact", error);
      throw error;
    }
    if (!response.ok) {
      this.log("Failed to post contact", response.status, response.statusText);
      throw new Error(`HTTP ${response.status}`);
    }
    this.log("contact \xB7 sent attributes for user:", body.userId);
  }
  /** Notifica eventos de popup a la API */
  async postPopupEvent(status, popupId, userId) {
    const apiKey = this.config?.apiKey;
    const baseUrl = this.baseUrl;
    if (!apiKey || !baseUrl) {
      return;
    }
    const endpoint = `${baseUrl}/sdk/popups`;
    try {
      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          publicKey: apiKey,
          status,
          popupId,
          userId: userId || void 0
        })
      });
      if (!response.ok) {
        this.log("Failed to post popup event", response.status, response.statusText);
        return;
      }
      try {
        const data = await response.json();
        if (data && typeof data.sessionId === "string") {
          this.tracking?.setSessionId(data.sessionId);
          this.log("tracking \xB7 session_id from backend:", data.sessionId);
        }
      } catch {
      }
    } catch (error) {
      this.log("Error posting popup event", error);
    }
  }
  /** Add an event listener */
  on(eventType, listener) {
    if (!this.listeners.has(eventType)) {
      this.listeners.set(eventType, /* @__PURE__ */ new Set());
    }
    this.listeners.get(eventType).add(listener);
  }
  /** Remove an event listener */
  off(eventType, listener) {
    const listeners = this.listeners.get(eventType);
    if (listeners) {
      listeners.delete(listener);
    }
  }
  /** Render the popup UI */
  renderPopup(surveyId, productId, actions, style, title) {
    const userId = this.tracking?.getUserId() ?? this.config?.userId;
    const sessionId = this.tracking?.getSessionId() ?? void 0;
    const miniService = this.analytics?.getMiniService() ?? void 0;
    const analyticsFeedbackSessionId = this.analyticsFeedbackSessionId;
    this.log("tracking \xB7 survey identity \u2192", { userId: userId ?? null, sessionId: sessionId ?? null, miniService: miniService ?? null, analyticsFeedbackSessionId: analyticsFeedbackSessionId ?? null });
    this.renderer.show(
      surveyId,
      productId,
      actions,
      (type, id, payload) => this.emitEvent(type, id, payload),
      () => this.hidePopup(),
      this.env,
      userId,
      style,
      sessionId,
      miniService,
      analyticsFeedbackSessionId,
      this.renderChrome,
      { title, showProgressBar: this.showProgressBar, surveyCss: this.surveyCss, language: this.language, cspNonce: this.cspNonce }
    );
  }
  /** Hide the popup */
  hidePopup() {
    this.renderer.hide();
  }
  /** Emit an event */
  emitEvent(type, surveyId, data) {
    const event = { type, surveyId, timestamp: Date.now(), data };
    this.log("Event emitted", event);
    if (type === "survey_error") {
      const popupId = data?.popupId || this.surveyToPopupId.get(surveyId);
      this.track("deepdots_survey_error", {
        survey_id: surveyId,
        ...popupId ? { popup_id: popupId } : {},
        reason: data?.reason,
        message: data?.message
      });
    }
    const isPartialClick = type === "popup_clicked" && data?.action === "partial";
    if (isPartialClick) {
      this.markSurveyProgress(surveyId, "PARTIAL");
    }
    if (type === "survey_completed") {
      this.markSurveyAnswered(surveyId);
    }
    if (type === "popup_shown" || type === "survey_completed" || isPartialClick) {
      const popupIdFromData = data?.popupId;
      const popupId = popupIdFromData || this.surveyToPopupId.get(surveyId);
      if (popupId) {
        const userIdFromData = data?.userId;
        const status = type === "popup_shown" ? "SHOWED" /* SHOWED */ : type === "survey_completed" ? "COMPLETED" /* COMPLETED */ : "PARTIAL" /* PARTIAL */;
        void this.postPopupEvent(status, popupId, userIdFromData || this.tracking?.getUserId() || this.config?.userId);
      } else {
        this.debug("No popupId available to post event", { type, surveyId });
      }
    }
    const listeners = this.listeners.get(type);
    if (listeners) {
      listeners.forEach((listener) => {
        try {
          listener(event);
        } catch (error) {
          if (this.logger.error) this.logger.error("Error in event listener:", error);
          else this.logger.log("Error in event listener:", error);
        }
      });
    }
  }
  /** Log debug messages */
  log(...args) {
    if (this.config?.debug) {
      this.logger.log("[DeepdotsPopups]", ...args);
    }
  }
  /** External debug method for triggers */
  debug(...args) {
    this.log(...args);
  }
  /** Set a custom renderer */
  setRenderer(renderer) {
    this.renderer = renderer;
    if (this.initialized && this.renderer.init) {
      this.renderer.init();
    }
  }
  normalizeUrl(value) {
    if (!value) return "";
    const withoutIndex = value.replace(/\/index\.html(?=($|[?#]))/i, "");
    return withoutIndex.length > 1 && withoutIndex.endsWith("/") ? withoutIndex.slice(0, -1) : withoutIndex;
  }
  safeParseUrl(url) {
    if (!url) return null;
    try {
      return new URL(url, typeof window !== "undefined" ? window.location.href : void 0);
    } catch {
      return null;
    }
  }
  mapPopupTriggerType(type) {
    switch (type) {
      case "time_on_page":
        return "time";
      case "scroll":
        return "scroll";
      case "exit":
        return "exit";
      case "click":
        return "click";
      case "event":
        return "event";
      default:
        return null;
    }
  }
  markSurveyProgress(surveyId, status) {
    const current = this.surveyProgress.get(surveyId);
    if (current?.status === "COMPLETED" && status !== "COMPLETED") {
      return;
    }
    this.surveyProgress.set(surveyId, { status, timestamp: Date.now() });
    this.persistPopupState();
  }
  /**
   * Fusiona el estado de redisplay del storage con el de memoria: por cada popup/survey gana
   * la entrada MÁS RECIENTE. Fusionar y no sustituir es lo que hace convivir a varias
   * pestañas sobre el mismo `localStorage`: se llama en el `init()`, antes de cada decisión
   * de mostrar y antes de cada escritura. `answeredSurveys` se reconstruye desde las
   * entradas COMPLETED: es exactamente lo que persiste `markSurveyAnswered`.
   */
  loadPopupState(storage) {
    const state = readPopupState(storage);
    Object.entries(state.lastShown).forEach(([popupId, timestamp]) => {
      if (timestamp > (this.lastShown.get(popupId) ?? -Infinity)) this.lastShown.set(popupId, timestamp);
    });
    Object.entries(state.progress).forEach(([surveyId, entry]) => {
      const current = this.surveyProgress.get(surveyId);
      if (current && current.timestamp >= entry.timestamp) return;
      this.surveyProgress.set(surveyId, { status: entry.status, timestamp: entry.timestamp });
      if (entry.status === "COMPLETED") this.answeredSurveys.add(surveyId);
    });
  }
  /**
   * Vuelca el estado de redisplay al storage. Sin storage (o bloqueado) degrada a memoria.
   * Fusiona antes de escribir: escribir solo la foto en memoria borraba lo que otra pestaña
   * hubiese guardado desde nuestro `init()`.
   */
  persistPopupState() {
    if (!this.storage) return;
    this.loadPopupState(this.storage);
    writePopupState(this.storage, {
      lastShown: Object.fromEntries(this.lastShown),
      progress: Object.fromEntries(this.surveyProgress)
    });
  }
  isPopupDefinition(value) {
    if (typeof value !== "object" || value === null) return false;
    const popup = value;
    return typeof popup.id === "string" && typeof popup.title === "string" && typeof popup.message === "string" && typeof popup.surveyId === "string" && typeof popup.productId === "string" && Array.isArray(popup.triggers) && popup.triggers.length > 0 && popup.triggers.every((trigger) => this.isPopupTrigger(trigger)) && (!popup.cooldown || popup.cooldown.every((condition) => this.isPopupTriggerCondition(condition)));
  }
  isPopupTrigger(value) {
    if (typeof value !== "object" || value === null) return false;
    const trigger = value;
    return this.isPopupTriggerType(trigger.type) && (typeof trigger.value === "number" || typeof trigger.value === "string");
  }
  isPopupTriggerType(value) {
    return value === "time_on_page" || value === "scroll" || value === "exit" || value === "click" || value === "event";
  }
  isPopupTriggerCondition(value) {
    if (typeof value !== "object" || value === null) return false;
    const condition = value;
    return POPUP_TRIGGER_CONDITION_STATUSES.includes(condition.answered) && typeof condition.cooldownDays === "number" && Number.isFinite(condition.cooldownDays) && condition.cooldownDays >= 0;
  }
  isLegacyPopupTriggerCondition(value) {
    if (typeof value !== "object" || value === null) return false;
    const condition = value;
    if (condition.answered !== void 0 && typeof condition.answered !== "boolean") {
      return false;
    }
    if (condition.cooldownDays !== void 0) {
      return typeof condition.cooldownDays === "number" && Number.isFinite(condition.cooldownDays) && condition.cooldownDays >= 0;
    }
    return true;
  }
  normalizeTriggers(value) {
    const items = Array.isArray(value) ? value : value ? [value] : [];
    return items.filter((trigger) => this.isPopupTrigger(trigger)).map((trigger) => ({
      type: trigger.type,
      value: trigger.value
    }));
  }
  normalizeCooldown(value) {
    if (!Array.isArray(value)) return [];
    return value.filter((condition) => this.isPopupTriggerCondition(condition));
  }
  normalizeLegacyConditions(value) {
    if (!Array.isArray(value)) return [];
    return value.filter((condition) => this.isLegacyPopupTriggerCondition(condition));
  }
  normalizePopupDefinition(def) {
    if (typeof def !== "object" || def === null) return null;
    const raw = def;
    const rawTriggers = raw.triggers ?? raw.trigger;
    const triggers = this.normalizeTriggers(rawTriggers);
    if (!triggers.length) return null;
    const rawTriggerList = Array.isArray(rawTriggers) ? rawTriggers : rawTriggers ? [rawTriggers] : [];
    const legacyConditions = [
      ...this.normalizeLegacyConditions(raw.conditions),
      ...rawTriggerList.flatMap((trigger) => this.normalizeLegacyConditions(trigger.condition))
    ];
    const cooldown = this.normalizeCooldown(raw.cooldown);
    return {
      ...raw,
      triggers,
      cooldown,
      legacyConditions
    };
  }
  validatePopupDefinitions(defs) {
    return defs.map((def) => this.normalizePopupDefinition(def)).filter((def) => !!def && this.isPopupDefinition(def));
  }
};

// src/react-native/setup.ts
function mmkvStorage(mmkv) {
  return {
    getItem: (k) => mmkv.getString(k) ?? null,
    setItem: (k, v) => mmkv.set(k, v),
    removeItem: (k) => mmkv.delete(k)
  };
}
function collectRnDevice(d) {
  return {
    device_type: d.isTablet?.() ? "tablet" : "mobile",
    os_version: d.getSystemVersion?.(),
    device_model: d.getDeviceId?.(),
    app_version: d.getVersion?.()
  };
}
function setupReactNative(sdk, config, deps = {}) {
  if (deps.renderer) sdk.setRenderer(deps.renderer);
  const storage = deps.mmkv ? mmkvStorage(deps.mmkv) : config.storage;
  const device = deps.deviceInfo ? collectRnDevice(deps.deviceInfo) : config.device;
  const platform = deps.platform ?? config.platform;
  sdk.init({ ...config, storage, device, platform });
  const errorUtils = deps.errorUtils ?? globalThis.ErrorUtils;
  if (errorUtils && typeof errorUtils.setGlobalHandler === "function") {
    sdk.installReactNativeCrashHandler(errorUtils);
  }
  let subscription;
  if (deps.appState?.addEventListener) {
    subscription = deps.appState.addEventListener("change", (state) => {
      if (state === "active") sdk.onForeground();
      else if (state === "background") sdk.onBackground();
      else sdk.flushAnalytics();
    });
  }
  return () => {
    if (subscription && typeof subscription.remove === "function") subscription.remove();
  };
}
export {
  BrowserPopupRenderer,
  ContactManager,
  CrashReporter,
  DeepdotsPopups,
  InMemoryStorage,
  LABELS,
  MAX_TRACKED_MESSAGES,
  MESSAGE_CHANNELS,
  MessageGuard,
  NATIVE_READY_GRACE_MS,
  NoopPopupRenderer,
  POPUP_TRIGGER_CONDITION_STATUSES,
  REVEAL_TIMEOUT_MS,
  RTL_LOCALES,
  ReactNativePopupRenderer,
  SUPPORTED_LANGUAGES,
  buildAnalyticsFeedbackBody,
  buildMessageParams,
  buildSurveyHtml,
  collectRnDevice,
  crashRecordToParams,
  createDefaultRenderer,
  createFeedbackSink,
  directionFor,
  getLabels,
  isRtlLanguage,
  mmkvStorage,
  resolveActionLabels,
  resolveLocale,
  setupReactNative
};
//# sourceMappingURL=index.mjs.map