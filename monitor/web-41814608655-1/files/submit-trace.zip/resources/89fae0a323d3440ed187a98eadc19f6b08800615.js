var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// src/tracking/tracking-manager.ts
var InMemoryStorage = class {
  constructor() {
    this.map = /* @__PURE__ */ new Map();
  }
  getItem(key) {
    return this.map.has(key) ? this.map.get(key) : null;
  }
  setItem(key, value) {
    this.map.set(key, value);
  }
  removeItem(key) {
    this.map.delete(key);
  }
};
function createDefaultStorage() {
  try {
    if (typeof window !== "undefined" && window.localStorage) {
      const ls = window.localStorage;
      const probe = "__deepdots_probe__";
      ls.setItem(probe, "1");
      ls.removeItem(probe);
      return {
        getItem: (k) => ls.getItem(k),
        setItem: (k, v) => ls.setItem(k, v),
        removeItem: (k) => ls.removeItem(k)
      };
    }
  } catch {
  }
  return new InMemoryStorage();
}
var STORAGE_KEYS = {
  userId: "deepdots.user_id",
  firstSeen: "deepdots.user.first_seen",
  contactAttributes: "deepdots.contact.attributes"
};
function buildSurveyIdentity(userId, sessionId, miniService = null, analyticsFeedbackSessionId = null) {
  const profile = userId ? [{ key: "external-user-id", value: [userId] }] : [];
  const metadata = [];
  if (sessionId) metadata.push({ key: "session_id", value: [sessionId] });
  if (userId) metadata.push({ key: "user_id", value: [userId] });
  if (miniService) metadata.push({ key: "mini_service", value: [miniService] });
  if (analyticsFeedbackSessionId) metadata.push({ key: "deepdots_analytics_feedback_session_id", value: [analyticsFeedbackSessionId] });
  return { profile, metadata };
}
function defaultUuid() {
  const g = typeof globalThis !== "undefined" ? globalThis : {};
  if (g.crypto?.randomUUID) return g.crypto.randomUUID();
  const bytes = new Uint8Array(16);
  if (g.crypto?.getRandomValues) {
    g.crypto.getRandomValues(bytes);
  } else {
    for (let i = 0; i < 16; i++) bytes[i] = Math.floor(Math.random() * 256);
  }
  bytes[6] = bytes[6] & 15 | 64;
  bytes[8] = bytes[8] & 63 | 128;
  const hex = Array.from(bytes, (b) => b.toString(16).padStart(2, "0"));
  return `${hex.slice(0, 4).join("")}-${hex.slice(4, 6).join("")}-${hex.slice(6, 8).join("")}-${hex.slice(8, 10).join("")}-${hex.slice(10, 16).join("")}`;
}
var TrackingManager = class {
  constructor(options) {
    /** session_id cacheado, provisto por el backend (no se genera ni se persiste). */
    this.sessionId = null;
    this.userWasJustCreated = false;
    this.storage = options.storage;
    this.clientUserId = options.clientUserId;
    this.now = options.now ?? (() => Date.now());
    this.uuid = options.uuid ?? defaultUuid;
    this.enabled = options.enabled ?? true;
  }
  isTrackingEnabled() {
    return this.enabled;
  }
  setTrackingEnabled(enabled) {
    this.enabled = enabled;
  }
  /** Resuelve el user_id según la regla: cliente > persistido > generar+persistir. */
  getUserId() {
    if (!this.enabled) return null;
    if (this.clientUserId) return this.clientUserId;
    const persisted = this.storage.getItem(STORAGE_KEYS.userId);
    if (persisted) return persisted;
    const id = this.uuid();
    this.storage.setItem(STORAGE_KEYS.userId, id);
    this.storage.setItem(STORAGE_KEYS.firstSeen, String(this.now()));
    this.userWasJustCreated = true;
    return id;
  }
  /** `true` solo en la primera sesión tras crear el user_id propio del SDK. */
  isNewUser() {
    return this.userWasJustCreated;
  }
  /** session_id actual provisto por el backend, o null si aún no llegó. */
  getSessionId() {
    if (!this.enabled) return null;
    return this.sessionId;
  }
  /** Cachea el session_id devuelto por el backend (respuesta de POST /sdk/popups). */
  setSessionId(sessionId) {
    if (!this.enabled) return;
    this.sessionId = sessionId;
  }
};

// src/ui/font.ts
var FORMAT_BY_EXT = {
  woff2: "woff2",
  woff: "woff",
  ttf: "truetype",
  otf: "opentype"
};
function fontFormatFromUrl(url) {
  const clean = url.split("?")[0].split("#")[0];
  const ext = clean.slice(clean.lastIndexOf(".") + 1).toLowerCase();
  return FORMAT_BY_EXT[ext];
}
function sanitizeFamily(family) {
  return family.replace(/[^A-Za-z0-9 ._-]/g, "").trim();
}
function isSafeFontUrl(url) {
  if (!/^(https?:|data:)/i.test(url)) return false;
  return !/[\x00-\x20"<>\\]/.test(url);
}
function buildFontFamilyValue(family) {
  const safe = sanitizeFamily(family);
  return `"${safe}", -apple-system, system-ui, sans-serif`;
}
function buildFontFaceCss(family, url) {
  if (!url || !isSafeFontUrl(url)) return "";
  const safe = sanitizeFamily(family);
  const fmt = fontFormatFromUrl(url);
  const src = fmt ? `url("${url}") format("${fmt}")` : `url("${url}")`;
  return `@font-face{font-family:"${safe}";src:${src};font-display:swap;}`;
}

// src/i18n/labels.ts
var EN = {
  accept: "Send",
  decline: "Cancel",
  start: "Start survey",
  complete: "Complete survey",
  back: "Back",
  question: "Question",
  of: "of",
  followUp: "Follow-up",
  closeAria: "Close popup",
  loadingAria: "Loading survey",
  errorRequired: "Please answer the required question to continue.",
  errorSubmit: "An error occurred while submitting. Please try again or close the popup.",
  errorLoad: "We couldn't load this survey."
};
var ES = {
  accept: "Enviar",
  decline: "Cancelar",
  start: "Empezar encuesta",
  complete: "Completar encuesta",
  back: "Atr\xE1s",
  question: "Pregunta",
  of: "de",
  followUp: "Seguimiento",
  closeAria: "Cerrar ventana emergente",
  loadingAria: "Cargando encuesta",
  errorRequired: "Responde la pregunta obligatoria para continuar.",
  errorSubmit: "Se produjo un error al enviar. Int\xE9ntalo de nuevo o cierra la ventana.",
  errorLoad: "No se ha podido cargar la encuesta."
};
var DA = {
  accept: "Send",
  decline: "Annuller",
  start: "Start unders\xF8gelse",
  complete: "Afslut unders\xF8gelse",
  back: "Tilbage",
  question: "Sp\xF8rgsm\xE5l",
  of: "af",
  followUp: "Opf\xF8lgning",
  closeAria: "Luk pop op",
  loadingAria: "Indl\xE6ser unders\xF8gelse",
  errorRequired: "Besvar venligst det obligatoriske sp\xF8rgsm\xE5l for at forts\xE6tte.",
  errorSubmit: "Der opstod en fejl under afsendelsen. Pr\xF8v igen, eller luk pop op-vinduet.",
  errorLoad: "Unders\xF8gelsen kunne ikke indl\xE6ses."
};
var NO = {
  accept: "Send",
  decline: "Avbryt",
  start: "Start unders\xF8kelse",
  complete: "Fullf\xF8r unders\xF8kelse",
  back: "Tilbake",
  question: "Sp\xF8rsm\xE5l",
  of: "av",
  followUp: "Oppf\xF8lging",
  closeAria: "Lukk popup",
  loadingAria: "Laster unders\xF8kelse",
  errorRequired: "Svar p\xE5 det obligatoriske sp\xF8rsm\xE5let for \xE5 fortsette.",
  errorSubmit: "Det oppstod en feil under innsendingen. Pr\xF8v igjen, eller lukk popupen.",
  errorLoad: "Unders\xF8kelsen kunne ikke lastes inn."
};
var SV = {
  accept: "Skicka",
  decline: "Avbryt",
  start: "Starta unders\xF6kning",
  complete: "Slutf\xF6r unders\xF6kning",
  back: "Tillbaka",
  question: "Fr\xE5ga",
  of: "av",
  followUp: "Uppf\xF6ljning",
  closeAria: "St\xE4ng popup",
  loadingAria: "Laddar unders\xF6kning",
  errorRequired: "Svara p\xE5 den obligatoriska fr\xE5gan f\xF6r att forts\xE4tta.",
  errorSubmit: "Ett fel uppstod vid inskickningen. F\xF6rs\xF6k igen eller st\xE4ng popupen.",
  errorLoad: "Enk\xE4ten kunde inte laddas."
};
var FI = {
  accept: "L\xE4het\xE4",
  decline: "Peruuta",
  start: "Aloita kysely",
  complete: "Viimeistele kysely",
  back: "Takaisin",
  question: "Kysymys",
  of: "/",
  followUp: "Jatkokysymys",
  closeAria: "Sulje ponnahdusikkuna",
  loadingAria: "Ladataan kysely\xE4",
  errorRequired: "Vastaa pakolliseen kysymykseen jatkaaksesi.",
  errorSubmit: "L\xE4hetyksess\xE4 tapahtui virhe. Yrit\xE4 uudelleen tai sulje ponnahdusikkuna.",
  errorLoad: "Kysely\xE4 ei voitu ladata."
};
var DE = {
  accept: "Senden",
  decline: "Abbrechen",
  start: "Umfrage starten",
  complete: "Umfrage abschlie\xDFen",
  back: "Zur\xFCck",
  question: "Frage",
  of: "von",
  followUp: "Folgefrage",
  closeAria: "Popup schlie\xDFen",
  loadingAria: "Umfrage wird geladen",
  errorRequired: "Bitte beantworte die Pflichtfrage, um fortzufahren.",
  errorSubmit: "Beim Senden ist ein Fehler aufgetreten. Versuche es erneut oder schlie\xDFe das Popup.",
  errorLoad: "Die Umfrage konnte nicht geladen werden."
};
var FR = {
  accept: "Envoyer",
  decline: "Annuler",
  start: "Commencer l'enqu\xEAte",
  complete: "Terminer l'enqu\xEAte",
  back: "Retour",
  question: "Question",
  of: "sur",
  followUp: "Question compl\xE9mentaire",
  closeAria: "Fermer la fen\xEAtre",
  loadingAria: "Chargement de l'enqu\xEAte",
  errorRequired: "Veuillez r\xE9pondre \xE0 la question obligatoire pour continuer.",
  errorSubmit: "Une erreur s'est produite lors de l'envoi. R\xE9essayez ou fermez la fen\xEAtre.",
  errorLoad: "Impossible de charger l'enqu\xEAte."
};
var PT = {
  accept: "Enviar",
  decline: "Cancelar",
  start: "Iniciar question\xE1rio",
  complete: "Concluir question\xE1rio",
  back: "Voltar",
  question: "Pergunta",
  of: "de",
  followUp: "Seguimento",
  closeAria: "Fechar janela",
  loadingAria: "A carregar question\xE1rio",
  errorRequired: "Responda \xE0 pergunta obrigat\xF3ria para continuar.",
  errorSubmit: "Ocorreu um erro ao enviar. Tente novamente ou feche a janela.",
  errorLoad: "N\xE3o foi poss\xEDvel carregar o inqu\xE9rito."
};
var AR = {
  accept: "\u0625\u0631\u0633\u0627\u0644",
  decline: "\u0625\u0644\u063A\u0627\u0621",
  start: "\u0627\u0628\u062F\u0623 \u0627\u0644\u0627\u0633\u062A\u0628\u064A\u0627\u0646",
  complete: "\u0625\u0646\u0647\u0627\u0621 \u0627\u0644\u0627\u0633\u062A\u0628\u064A\u0627\u0646",
  back: "\u0631\u062C\u0648\u0639",
  question: "\u0633\u0624\u0627\u0644",
  of: "\u0645\u0646",
  followUp: "\u0633\u0624\u0627\u0644 \u0645\u062A\u0627\u0628\u0639\u0629",
  closeAria: "\u0625\u063A\u0644\u0627\u0642 \u0627\u0644\u0646\u0627\u0641\u0630\u0629 \u0627\u0644\u0645\u0646\u0628\u062B\u0642\u0629",
  loadingAria: "\u062C\u0627\u0631\u064D \u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0627\u0633\u062A\u0628\u064A\u0627\u0646",
  errorRequired: "\u064A\u0631\u062C\u0649 \u0627\u0644\u0625\u062C\u0627\u0628\u0629 \u0639\u0644\u0649 \u0627\u0644\u0633\u0624\u0627\u0644 \u0627\u0644\u0645\u0637\u0644\u0648\u0628 \u0644\u0644\u0645\u062A\u0627\u0628\u0639\u0629.",
  errorSubmit: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0627\u0644\u0625\u0631\u0633\u0627\u0644. \u064A\u0631\u062C\u0649 \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629 \u0645\u0631\u0629 \u0623\u062E\u0631\u0649 \u0623\u0648 \u0625\u063A\u0644\u0627\u0642 \u0627\u0644\u0646\u0627\u0641\u0630\u0629.",
  errorLoad: "\u062A\u0639\u0630\u0651\u0631 \u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0627\u0633\u062A\u0628\u064A\u0627\u0646."
};
var BN = {
  accept: "\u09AA\u09BE\u09A0\u09BE\u09A8",
  decline: "\u09AC\u09BE\u09A4\u09BF\u09B2",
  start: "\u099C\u09B0\u09BF\u09AA \u09B6\u09C1\u09B0\u09C1 \u0995\u09B0\u09C1\u09A8",
  complete: "\u099C\u09B0\u09BF\u09AA \u09B8\u09AE\u09CD\u09AA\u09C2\u09B0\u09CD\u09A3 \u0995\u09B0\u09C1\u09A8",
  back: "\u09AA\u09BF\u099B\u09A8\u09C7",
  question: "\u09AA\u09CD\u09B0\u09B6\u09CD\u09A8",
  of: "/",
  followUp: "\u09AB\u09B2\u09CB-\u0986\u09AA",
  closeAria: "\u09AA\u09AA\u0986\u09AA \u09AC\u09A8\u09CD\u09A7 \u0995\u09B0\u09C1\u09A8",
  loadingAria: "\u099C\u09B0\u09BF\u09AA \u09B2\u09CB\u09A1 \u09B9\u099A\u09CD\u099B\u09C7",
  errorRequired: "\u099A\u09BE\u09B2\u09BF\u09AF\u09BC\u09C7 \u09AF\u09C7\u09A4\u09C7 \u0986\u09AC\u09B6\u09CD\u09AF\u0995 \u09AA\u09CD\u09B0\u09B6\u09CD\u09A8\u09C7\u09B0 \u0989\u09A4\u09CD\u09A4\u09B0 \u09A6\u09BF\u09A8\u0964",
  errorSubmit: "\u099C\u09AE\u09BE \u09A6\u09C7\u0993\u09AF\u09BC\u09BE\u09B0 \u09B8\u09AE\u09AF\u09BC \u098F\u0995\u099F\u09BF \u09A4\u09CD\u09B0\u09C1\u099F\u09BF \u0998\u099F\u09C7\u099B\u09C7\u0964 \u0986\u09AC\u09BE\u09B0 \u099A\u09C7\u09B7\u09CD\u099F\u09BE \u0995\u09B0\u09C1\u09A8 \u09AC\u09BE \u09AA\u09AA\u0986\u09AA \u09AC\u09A8\u09CD\u09A7 \u0995\u09B0\u09C1\u09A8\u0964",
  errorLoad: "\u09B8\u09AE\u09C0\u0995\u09CD\u09B7\u09BE\u099F\u09BF \u09B2\u09CB\u09A1 \u0995\u09B0\u09BE \u09AF\u09BE\u09AF\u09BC\u09A8\u09BF\u0964"
};
var ZH_CN = {
  accept: "\u53D1\u9001",
  decline: "\u53D6\u6D88",
  start: "\u5F00\u59CB\u95EE\u5377",
  complete: "\u5B8C\u6210\u95EE\u5377",
  back: "\u8FD4\u56DE",
  question: "\u95EE\u9898",
  of: "/",
  followUp: "\u8FFD\u95EE",
  closeAria: "\u5173\u95ED\u5F39\u7A97",
  loadingAria: "\u6B63\u5728\u52A0\u8F7D\u95EE\u5377",
  errorRequired: "\u8BF7\u56DE\u7B54\u5FC5\u7B54\u9898\u540E\u7EE7\u7EED\u3002",
  errorSubmit: "\u63D0\u4EA4\u65F6\u51FA\u9519\u3002\u8BF7\u91CD\u8BD5\u6216\u5173\u95ED\u5F39\u7A97\u3002",
  errorLoad: "\u65E0\u6CD5\u52A0\u8F7D\u95EE\u5377\u3002"
};
var LABELS = {
  en: EN,
  es: ES,
  da: DA,
  no: NO,
  sv: SV,
  fi: FI,
  de: DE,
  fr: FR,
  pt: PT,
  ar: AR,
  bn: BN,
  "zh-CN": ZH_CN
};
var SUPPORTED_LANGUAGES = [
  // Los 11 idiomas que la plataforma ofrece para un survey, más zh-CN (que el SDK nativo ya
  // traía). Si la plataforma añade uno nuevo, hay que añadirlo aquí o el chrome saldrá en
  // inglés bajo un survey traducido.
  "en",
  "es",
  "da",
  "no",
  "sv",
  "fi",
  "de",
  "fr",
  "pt",
  "ar",
  "bn",
  "zh-CN"
];
function resolveLocale(lang) {
  if (typeof lang !== "string") return "en";
  const normalized = lang.trim().toLowerCase().replace(/_/g, "-");
  if (!normalized) return "en";
  if (normalized === "zh" || normalized.startsWith("zh-")) return "zh-CN";
  const primary = normalized.split("-")[0];
  switch (primary) {
    case "en":
      return "en";
    case "es":
      return "es";
    case "da":
      return "da";
    case "no":
    case "nb":
    case "nn":
      return "no";
    case "sv":
      return "sv";
    case "fi":
      return "fi";
    case "de":
      return "de";
    case "fr":
      return "fr";
    case "pt":
      return "pt";
    case "ar":
      return "ar";
    case "bn":
      return "bn";
    default:
      return "en";
  }
}
var RTL_LOCALES = ["ar"];
function isRtlLanguage(lang) {
  return RTL_LOCALES.includes(resolveLocale(lang));
}
function directionFor(lang) {
  return isRtlLanguage(lang) ? "rtl" : "ltr";
}
function getLabels(lang) {
  return LABELS[resolveLocale(lang)];
}
function resolveActionLabels(actions, lang) {
  const labels = getLabels(lang);
  const pick = (value, fallback) => {
    const trimmed = typeof value === "string" ? value.trim() : "";
    return trimmed ? value : fallback;
  };
  return {
    accept: pick(actions?.accept?.label, labels.accept),
    decline: pick(actions?.decline?.label, labels.decline),
    start: pick(actions?.start?.label, labels.start),
    complete: pick(actions?.complete?.label, labels.complete),
    back: pick(actions?.back?.label, labels.back)
  };
}
var RESOLVE_LOCALE_JS = `function ddResolveLocale(lang){
  if(typeof lang!=='string') return 'en';
  var n=lang.trim().toLowerCase().replace(/_/g,'-');
  if(!n) return 'en';
  if(n==='zh'||n.indexOf('zh-')===0) return 'zh-CN';
  var p=n.split('-')[0];
  if(p==='en') return 'en';
  if(p==='es') return 'es';
  if(p==='da') return 'da';
  if(p==='no'||p==='nb'||p==='nn') return 'no';
  if(p==='sv') return 'sv';
  if(p==='fi') return 'fi';
  if(p==='de') return 'de';
  if(p==='fr') return 'fr';
  if(p==='pt') return 'pt';
  if(p==='ar') return 'ar';
  if(p==='bn') return 'bn';
  return 'en';
}`;

// src/ui/reveal.ts
var REVEAL_TIMEOUT_MS = 1200;
function revealWhenPainted(root, reveal) {
  const pending = Array.from(root.querySelectorAll("img")).filter((img) => !img.complete);
  if (!pending.length) {
    reveal();
    return;
  }
  let left = pending.length;
  const onSettled = () => {
    left -= 1;
    if (left <= 0) reveal();
  };
  pending.forEach((img) => {
    img.addEventListener("load", onSettled, { once: true });
    img.addEventListener("error", onSettled, { once: true });
  });
}

// src/ui/surveyPalette.ts
var HEX_COLOR = /^#(?:[0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/;
function resolveSurveyPrimaryColor(style) {
  for (const candidate of [style?.primaryColor, style?.buttonPrimaryColor]) {
    const value = (candidate ?? "").trim();
    if (HEX_COLOR.test(value)) return value;
  }
  return null;
}
function surveyPrimaryVars(color) {
  return [
    ["--mf-primary", color],
    ["--mf-primary-hover", `color-mix(in srgb, ${color} 85%, black)`],
    ["--mf-primary-light", `color-mix(in srgb, ${color} 15%, white)`],
    ["--mf-primary-border", `color-mix(in srgb, ${color} 35%, transparent)`],
    ["--mf-border-focus", color]
  ];
}
function applySurveyPrimaryColor(el, style) {
  const color = resolveSurveyPrimaryColor(style);
  if (!color) return;
  for (const [name, value] of surveyPrimaryVars(color)) {
    el.style.setProperty(name, value);
  }
}
var PRIMARY_COLOR_JS = `
function ddResolveSurveyPrimaryColor(style){
  var hex=/^#(?:[0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/;
  var candidates=[style&&style.primaryColor, style&&style.buttonPrimaryColor];
  for(var i=0;i<candidates.length;i++){
    var value=(candidates[i]||'').trim();
    if(hex.test(value)){ return value; }
  }
  return null;
}
function ddApplySurveyPrimaryColor(el, style){
  var color=ddResolveSurveyPrimaryColor(style);
  if(!color||!el){ return; }
  el.style.setProperty('--mf-primary', color);
  el.style.setProperty('--mf-primary-hover', 'color-mix(in srgb, '+color+' 85%, black)');
  el.style.setProperty('--mf-primary-light', 'color-mix(in srgb, '+color+' 15%, white)');
  el.style.setProperty('--mf-primary-border', 'color-mix(in srgb, '+color+' 35%, transparent)');
  el.style.setProperty('--mf-border-focus', color);
}`;

// src/ui/busy.ts
function setSurveyBusy(el, busy) {
  if (!el) return;
  el.style.pointerEvents = busy ? "none" : "";
  el.setAttribute("aria-busy", busy ? "true" : "false");
  if ("inert" in el) {
    el.inert = busy;
  }
}
var BUSY_JS = `
function ddSetSurveyBusy(el, busy){
  if(!el){ return; }
  el.style.pointerEvents = busy ? 'none' : '';
  el.setAttribute('aria-busy', busy ? 'true' : 'false');
  if('inert' in el){ el.inert = busy; }
}`;

// src/ui/submitError.ts
var SURVEY_ERROR_MESSAGE_MAX = 300;
var REASON_BY_CODE = {
  REQUIRED: "required",
  SEND_FAILED: "send_failed",
  NO_PAGE: "no_page"
};
function submitErrorText(error) {
  if (!error) return "";
  if (typeof error === "string") return error;
  const message = error.message;
  return typeof message === "string" ? message : String(error);
}
function classifySubmitError(error) {
  const message = submitErrorText(error).slice(0, SURVEY_ERROR_MESSAGE_MAX);
  const code = error && typeof error === "object" ? error.code : void 0;
  if (typeof code === "string" && REASON_BY_CODE[code]) return { reason: REASON_BY_CODE[code], message };
  if (message.toLowerCase().includes("no response")) return { reason: "required", message };
  return { reason: "unknown", message };
}
var SUBMIT_ERROR_JS = `
function ddClassifySubmitError(error){
  var message='';
  if(error){
    if(typeof error==='string'){ message=error; }
    else if(typeof error.message==='string'){ message=error.message; }
    else { message=String(error); }
  }
  message=message.slice(0, ${SURVEY_ERROR_MESSAGE_MAX});
  var byCode={ REQUIRED:'required', SEND_FAILED:'send_failed', NO_PAGE:'no_page' };
  var code=error && typeof error==='object' ? error.code : undefined;
  if(typeof code==='string' && byCode.hasOwnProperty(code)){ return { reason: byCode[code], message: message }; }
  if(message.toLowerCase().indexOf('no response')!==-1){ return { reason: 'required', message: message }; }
  return { reason: 'unknown', message: message };
}`;

// src/assets/style.css
var style_default = `/**
 * NO EDITAR A MANO \u2014 generado por scripts/vendor-survey-css.mjs
 *
 * Copia de @magicfeedback/native@2.2.37 \u2192 dist/styles/magicfeedback-default.css
 * (la hoja can\xF3nica del paquete, la que apunta su campo "style"), con estos cambios locales:
 *
 *  1. Sin el @import de Google Fonts (Nunito): no queremos una petici\xF3n externa desde la
 *     p\xE1gina del host, y la tipograf\xEDa la decide el popup.
 *  2. .magicfeedback-container hereda la fuente del popup (var(--deepdots-font, inherit)).
 *  3. Los selectores desnudos (h2, p, input, textarea, select, ::placeholder, .error) van
 *     acotados a .deepdots-popup: este CSS se inyecta en el <head> del host y sin acotar
 *     repintar\xEDa su web.
 *  4. El grupo .magicfeedback-radio se cualifica como div.magicfeedback-radio (la clase acaba
 *     tambi\xE9n en el <input> del boolean).
 *  5. Todo :hover va dentro de @media (hover: hover): en t\xE1ctil WebKit deja el hover pegado
 *     en el \xFAltimo punto tocado y la opci\xF3n de la p\xE1gina siguiente parec\xEDa seleccionada.
 *  6. Al final, un bloque de reglas propias del popup (fuente en los controles y padding del
 *     radio nativo).
 *
 * Las variables --mf-* se dejan en :root a prop\xF3sito: el modal del priority-list se portea a
 * <body>, fuera de .deepdots-popup, y ah\xED las necesita.
 *
 * Para subir de versi\xF3n: npm i @magicfeedback/native@<v> && node scripts/vendor-survey-css.mjs
 */

/**
 * @magicfeedback/native - Default Styles
 * Clean, minimal, and elegant survey rendering
 */

/* @import de Google Fonts (Nunito) eliminado al vendorizar: la fuente la pone el popup. */

/* ========================================
   CSS VARIABLES - Design SYSTEM
   ======================================== */
:root {
    /* Colors - Minimal Pastel */
    /* --mf-primary is the one source of truth for brand/accent color \u2014
       every token below derives from it via color-mix() (or references
       it directly) so changing this single value, here or via a
       per-integration override, keeps hover/light/border states in
       sync automatically instead of going stale independently. Scoped
       to genuinely interactive/accent surfaces (buttons, selected
       chips, focus rings) \u2014 general body text stays on its own neutral
       scale below, not tied to the brand color. */
    --mf-primary: #5d7bad;
    --mf-primary-hover: color-mix(in srgb, var(--mf-primary) 85%, black);
    --mf-primary-light: color-mix(in srgb, var(--mf-primary) 15%, white);
    /* a translucent tint \u2014 mixed with transparent (opacity), not white,
       so it reads as a soft shadow of the brand color rather than a
       pastel of it. */
    --mf-primary-border: color-mix(in srgb, var(--mf-primary) 35%, transparent);

    --mf-text-primary: #1E293B;
    --mf-text-secondary: #475569;
    --mf-text-muted: #94A3B8;

    --mf-bg-primary: #F8FAFC;
    --mf-bg-secondary: #FFFFFF;
    --mf-bg-hover: #EEF2F6;

    --mf-border: #E2E8F0;
    --mf-border-focus: var(--mf-primary);

    --mf-success: #16A34A;
    --mf-error: #EF4444;
    --mf-warning: #F59E0B;

    --mf-surface: #FFFFFF;
    --mf-surface-alt: #F1F5F9;
    --mf-accent: #38BDF8;

    /* Spacing */
    --mf-space-xs: 0.25rem;
    --mf-space-sm: 0.5rem;
    --mf-space-md: 0.75rem;
    --mf-space-lg: 1rem;
    --mf-space-xl: 1.5rem;

    /* Border Radius */
    --mf-radius-sm: 0.5rem;
    --mf-radius-md: 0.75rem;
    --mf-radius-lg: 1.25rem;
    --mf-radius-full: 9999px;

    /* Shadows */
    --mf-shadow-sm: 0 1px 2px 0 rgba(15, 23, 42, 0.06);
    --mf-shadow-md: 0 8px 20px rgba(15, 23, 42, 0.08);
    --mf-shadow-lg: 0 16px 30px rgba(15, 23, 42, 0.12);
    --mf-shadow-focus: 0 0 0 3px rgba(30, 41, 59, 0.15);
    --mf-shadow-card: 0 18px 40px rgba(15, 23, 42, 0.08);

    /* Typography */
    --mf-font-sans: "Nunito", "Quicksand", "Avenir Next", "Trebuchet MS", sans-serif;
    --mf-font-size-sm: 0.875rem;
    --mf-font-size-base: 1rem;
    --mf-font-size-lg: 1.125rem;
    --mf-font-size-xl: 1.25rem;
    --mf-line-height: 1.6;

    /* Font Weights */
    --mf-font-weight-normal: 400;
    --mf-font-weight-medium: 500;
    --mf-font-weight-semibold: 600;
    --mf-font-weight-bold: 700;
    --mf-font-weight-extrabold: 800;

    /* Transitions */
    --mf-transition: all 0.2s ease;
    --mf-transition-fast: all 0.15s ease;
}

/* ========================================
   ANIMATIONS
   ======================================== */
@keyframes mf-fade-in {
    from {
        opacity: 0;
        transform: translateY(8px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes mf-slide-in {
    from {
        opacity: 0;
        transform: translateX(-16px);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}

@keyframes mf-scale-in {
    from {
        opacity: 0;
        transform: scale(0.95);
    }
    to {
        opacity: 1;
        transform: scale(1);
    }
}

@keyframes mf-pulse {
    0%,
    100% {
        opacity: 1;
    }
    50% {
        opacity: 0.8;
    }
}

/* ========================================
   BASE CONTAINER
   ======================================== */
.magicfeedback-container {
    /* Local: hereda la fuente del popup; --deepdots-font viene de PopupStyle.font. */
    font-family: var(--deepdots-font, inherit);
    color: var(--mf-text-primary);
    line-height: var(--mf-line-height);
    animation: mf-fade-in 0.4s ease-out;
    border-radius: var(--mf-radius-lg);
}

/* ========================================
   MESSAGES
   ======================================== */
.magicfeedback-success-message,
.magicfeedback-info-message,
.magicfeedback-start-message {
    padding: var(--mf-space-lg);
    margin: var(--mf-space-lg) 0;
    animation: mf-scale-in 0.3s ease-out;
}

/* .magicfeedback-info-message/-start-message are set via innerHTML (see
   renderInfoPage.ts / questions.service.ts's renderStartMessage) \u2014 whatever
   rich text a survey author writes lands here as real HTML, not just the
   <p>/<img> pair this used to style. Covering the rest of what a rich-text
   editor commonly outputs (headings, lists, links, emphasis, quotes, code,
   rules) keeps that content on the same type scale and palette as the rest
   of the widget instead of falling back to unstyled browser defaults. */
.magicfeedback-success-message > :first-child,
.magicfeedback-info-message > :first-child,
.magicfeedback-start-message > :first-child {
    margin-top: 0;
}

.magicfeedback-success-message > :last-child,
.magicfeedback-info-message > :last-child,
.magicfeedback-start-message > :last-child {
    margin-bottom: 0;
}

.magicfeedback-success-message p,
.magicfeedback-info-message p,
.magicfeedback-start-message p {
    font-size: var(--mf-font-size-base);
    color: var(--mf-text-secondary);
    margin: 0 0 var(--mf-space-md);
    line-height: var(--mf-line-height);
}

.magicfeedback-info-message h1,
.magicfeedback-info-message h2,
.magicfeedback-info-message h3,
.magicfeedback-info-message h4,
.magicfeedback-info-message h5,
.magicfeedback-info-message h6,
.magicfeedback-start-message h1,
.magicfeedback-start-message h2,
.magicfeedback-start-message h3,
.magicfeedback-start-message h4,
.magicfeedback-start-message h5,
.magicfeedback-start-message h6 {
    color: var(--mf-text-primary);
    font-weight: var(--mf-font-weight-bold);
    line-height: 1.3;
    margin: var(--mf-space-lg) 0 var(--mf-space-sm);
    text-align: start;
}

.magicfeedback-info-message h1, .magicfeedback-start-message h1 { font-size: var(--mf-font-size-xl); }
.magicfeedback-info-message h2, .magicfeedback-start-message h2 { font-size: var(--mf-font-size-lg); }
.magicfeedback-info-message h3,
.magicfeedback-info-message h4,
.magicfeedback-info-message h5,
.magicfeedback-info-message h6,
.magicfeedback-start-message h3,
.magicfeedback-start-message h4,
.magicfeedback-start-message h5,
.magicfeedback-start-message h6 { font-size: var(--mf-font-size-base); }

.magicfeedback-info-message strong,
.magicfeedback-info-message b,
.magicfeedback-start-message strong,
.magicfeedback-start-message b {
    font-weight: var(--mf-font-weight-bold);
    color: var(--mf-text-primary);
}

.magicfeedback-info-message a,
.magicfeedback-start-message a {
    color: var(--mf-primary);
    text-decoration: underline;
    text-underline-offset: 2px;
}

@media (hover: hover) {
    .magicfeedback-info-message a:hover,
    .magicfeedback-start-message a:hover {
        color: var(--mf-primary-hover);
    }
}

.magicfeedback-info-message ul,
.magicfeedback-info-message ol,
.magicfeedback-start-message ul,
.magicfeedback-start-message ol {
    margin: 0 0 var(--mf-space-md);
    padding-inline-start: var(--mf-space-xl);
    color: var(--mf-text-secondary);
    line-height: var(--mf-line-height);
}

.magicfeedback-info-message li + li,
.magicfeedback-start-message li + li {
    margin-top: var(--mf-space-xs);
}

.magicfeedback-info-message blockquote,
.magicfeedback-start-message blockquote {
    margin: 0 0 var(--mf-space-md);
    padding: var(--mf-space-sm) var(--mf-space-md);
    border-inline-start: 3px solid var(--mf-primary-border);
    color: var(--mf-text-secondary);
    font-style: italic;
}

.magicfeedback-info-message code,
.magicfeedback-start-message code {
    font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
    font-size: 0.9em;
    background: var(--mf-bg-hover);
    padding: 0.15em 0.4em;
    border-radius: var(--mf-radius-sm);
}

.magicfeedback-info-message pre,
.magicfeedback-start-message pre {
    margin: 0 0 var(--mf-space-md);
    padding: var(--mf-space-md);
    background: var(--mf-bg-hover);
    border-radius: var(--mf-radius-md);
    overflow-x: auto;
}

.magicfeedback-info-message pre code,
.magicfeedback-start-message pre code {
    background: none;
    padding: 0;
}

.magicfeedback-info-message hr,
.magicfeedback-start-message hr {
    border: none;
    border-top: 1px solid var(--mf-border);
    margin: var(--mf-space-lg) 0;
}

.magicfeedback-success-message img,
.magicfeedback-info-message img,
.magicfeedback-start-message img {
    max-width: 100%;
    height: auto;
    margin: var(--mf-space-lg) auto;
    display: block;
    border-radius: var(--mf-radius-md);
}

.magicfeedback-image {
    max-height: 400px;
    height: auto;
    max-width: 100%;
    margin: var(--mf-space-lg) auto;
    display: block;
    border-radius: var(--mf-radius-md);
}

/* ========================================
   FORM STRUCTURE
   ======================================== */
.magicfeedback-form {
    display: flex;
    flex-direction: column;
    gap: var(--mf-space-lg);
    padding: clamp(16px, 2.5vw, 28px);
}

.magicfeedback-questions {
    display: flex;
    flex-direction: column;
    gap: var(--mf-space-xl);
    width: 100%;
}

.magicfeedback-div {
    display: flex;
    flex-direction: column;
    gap: var(--mf-space-sm);
    animation: mf-slide-in 0.3s ease-out;
    background: var(--mf-bg-secondary);
    border-radius: var(--mf-radius-md);
}

/* ========================================
   LABELS & TYPOGRAPHY
   ======================================== */
.magicfeedback-label {
    font-size: var(--mf-font-size-lg);
    font-weight: var(--mf-font-weight-bold);
    color: var(--mf-text-primary);
    line-height: var(--mf-line-height);
    text-align: start;
    letter-spacing: -0.01em;
}

.magicfeedback-sublabel {
    font-size: var(--mf-font-size-base);
    font-weight: var(--mf-font-weight-normal);
    color: var(--mf-text-secondary);
    margin-bottom: var(--mf-space-sm);
}

.deepdots-popup h2 {
    font-size: var(--mf-font-size-xl);
    font-weight: 600;
    color: var(--mf-text-primary);
    margin: 0 0 var(--mf-space-xl) 0;
    text-align: center;
    letter-spacing: -0.01em;
}

.deepdots-popup p {
    margin: 0;
    font-size: var(--mf-font-size-sm);
    color: var(--mf-text-secondary);
}

/* ========================================
   FORM INPUTS
   ======================================== */
.deepdots-popup input[type="date"],
.deepdots-popup input[type="text"],
.deepdots-popup input[type="number"],
.deepdots-popup input[type="email"],
.deepdots-popup input[type="password"],
.deepdots-popup textarea,
.deepdots-popup select {
    padding: 0.75rem 0.9rem;
    font-size: var(--mf-font-size-base);
    font-family: inherit;
    color: var(--mf-text-primary);
    background-color: var(--mf-surface);
    border: 2px solid var(--mf-border);
    border-radius: var(--mf-radius-md);
    outline: none;
    transition: var(--mf-transition);
    -webkit-appearance: none;
    appearance: none;
    box-shadow: var(--mf-shadow-sm);
}

.deepdots-popup textarea {
    min-height: 100px;
    resize: vertical;
}

.deepdots-popup input::placeholder,
.deepdots-popup textarea::placeholder {
    color: var(--mf-text-muted);
}

/* Remove number input spinners */
.deepdots-popup input::-webkit-outer-spin-button,
.deepdots-popup input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

.deepdots-popup input[type="number"] {
    /* -moz-appearance: textfield; removed for lint compatibility */
}

/* Custom Select Arrow */
.deepdots-popup select {
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%2364748b' d='M6 9L1 4h10z'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right var(--mf-space-md) center;
    padding-inline-end: var(--mf-space-xl);
}

/* Error State */
.deepdots-popup input.error,
.deepdots-popup select.error,
.deepdots-popup textarea.error {
    border-color: var(--mf-error);
}

.magicfeedback-error {
    margin-top: var(--mf-space-xs);
    font-size: var(--mf-font-size-sm);
    color: var(--mf-error);
}

/* ========================================
   CHECKBOX & RADIO OPTIONS
   ======================================== */
.magicfeedback-checkbox,
div.magicfeedback-radio {
    display: flex;
    flex-direction: column;
    gap: var(--mf-space-sm);
    width: 100%;
}

/* Single choice in a row (assets.direction "row"): one equal box per
   option. The "other" text field wraps to its own line below. Stacked
   (phone, or too narrow) it is the usual vertical list again. */
.magicfeedback-radio--row {
    flex-direction: row;
    flex-wrap: wrap;
}

.magicfeedback-radio--row > .magicfeedback-radio-container {
    flex: 1 1 0;
    min-width: 0;
}

.magicfeedback-radio--row > .magicfeedback-extra-option {
    flex-basis: 100%;
}

.magicfeedback-radio--row.magicfeedback-radio--stacked {
    flex-direction: column;
    flex-wrap: nowrap;
}

.magicfeedback-radio--row.magicfeedback-radio--stacked > .magicfeedback-radio-container {
    flex: none;
}

.magicfeedback-radio--row .magicfeedback-radio-container label {
    overflow-wrap: anywhere;
}

.magicfeedback-checkbox-container,
.magicfeedback-radio-container {
    display: flex;
    align-items: center;
    gap: var(--mf-space-sm);
    padding: var(--mf-space-md);
    border: 1.5px solid var(--mf-border);
    border-radius: var(--mf-radius-md);
    cursor: pointer;
    transition: var(--mf-transition-fast);
}

@media (hover: hover) {
    .magicfeedback-checkbox-container:hover,
    .magicfeedback-radio-container:hover {
        background-color: var(--mf-bg-hover);
        border-color: var(--mf-primary);
    }
}

.magicfeedback-checkbox-container:has(input:checked),
.magicfeedback-radio-container:has(input:checked) {
    background-color: var(--mf-primary-light);
    border-color: var(--mf-primary);
}

.magicfeedback-checkbox input[type="checkbox"],
.magicfeedback-radio-container input[type="radio"] {
    width: 18px;
    height: 18px;
    margin: 0;
    cursor: pointer;
    flex-shrink: 0;
    accent-color: var(--mf-primary);
}

.magicfeedback-checkbox label,
.magicfeedback-radio-container label {
    font-size: var(--mf-font-size-base);
    text-align: start;
    color: var(--mf-text-primary);
    cursor: pointer;
    margin: 0;
    flex: 1;
}

/* ========================================
   BOOLEAN OPTIONS
   ======================================== */
.magicfeedback-boolean-container {
    display: flex;
    gap: var(--mf-space-md);
    width: 100%;
}

.magicfeedback-boolean-option {
    flex: 1;
    position: relative;
}

.magicfeedback-boolean-option input[type="radio"] {
    position: absolute;
    opacity: 0;
    width: 0;
    height: 0;
}

.magicfeedback-boolean-option label {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: var(--mf-space-md);
    font-size: var(--mf-font-size-base);
    font-weight: 500;
    color: var(--mf-text-secondary);
    border: 1.5px solid var(--mf-border);
    border-radius: var(--mf-radius-md);
    cursor: pointer;
    transition: var(--mf-transition-fast);
    margin: 0;
    width: -webkit-fill-available;
    height: inherit;
}

@media (hover: hover) {
    .magicfeedback-boolean-option label:hover {
        background-color: var(--mf-bg-hover);
        border-color: var(--mf-primary);
    }
}

.magicfeedback-boolean-option input[type="radio"]:checked + label {
    color: var(--mf-primary);
    background-color: var(--mf-primary-light);
    border-color: var(--mf-primary);
    font-weight: 600;
}

/* ========================================
   RATING SYSTEMS
   ======================================== */
.magicfeedback-rating,
.magicfeedback-rating-number,
.magicfeedback-rating-star {
    width: 100%;
}

.magicfeedback-rating-container,
.magicfeedback-rating-number-container,
.magicfeedback-rating-star-container {
    display: flex;
    flex-wrap: wrap;
    gap: var(--mf-space-sm);
    justify-content: center;
    align-items: center;
    padding: var(--mf-space-md) 0;
    list-style: none;
    margin: 0;
}

/* Caption line below the row \u2014 min on one side, max on the other (swapped
   for order: "rtl") \u2014 same simple, non-responsive pattern as the
   rating-number row caption. Used by rating-star and rating-emoji. */
.magicfeedback-rating-placeholder {
    display: flex;
    justify-content: space-between;
    gap: var(--mf-space-md);
    width: 100%;
    margin-top: var(--mf-space-sm);
    font-size: var(--mf-font-size-sm);
    font-weight: var(--mf-font-weight-semibold);
    color: var(--mf-text-secondary);
}

.magicfeedback-rating-placeholder-value {
    overflow-wrap: anywhere;
}

.magicfeedback-rating-placeholder-value:last-child {
    text-align: end;
}

/* Rating with Images */
.magicfeedback-rating-option-label-container input[type="radio"] {
    position: absolute;
    opacity: 0;
    width: 0;
    height: 0;
}

.magicfeedback-rating-option-label-container img {
    width: 56px;
    height: 56px;
    cursor: pointer;
    transition: var(--mf-transition-fast);
    border-radius: var(--mf-radius-full);
    border: 2px solid transparent;
}

@media (hover: hover) {
    .magicfeedback-rating-option-label-container img:hover {
        transform: scale(1.1);
        border-color: var(--mf-primary);
    }
}

.magicfeedback-rating-option-label-container input[type="radio"]:checked + img {
    border-color: var(--mf-primary);
    box-shadow: 0 0 0 3px var(--mf-primary-light);
}

.magicfeedback-rating-option-label-container label {
    display: block;
    text-align: center;
    font-size: var(--mf-font-size-sm);
    color: var(--mf-text-secondary);
    margin-top: var(--mf-space-xs);
    cursor: pointer;
}

/* Rating Numbers \u2014 each option is its own outlined chip in the survey's
   primary color, with a gap between them. Row and column use the same
   chip; column additionally has room to show each option's own text
   plainly next to its number. */

/* Every size here is width:100%/flex:1 combined with the chip's own
   padding and border. Without border-box, the browser's default
   content-box adds that padding/border on TOP of the declared size, so
   the chip quietly overflows past its flex slot \u2014 reading as "not quite
   full width" or, worse, pushing into the next chip. */
.magicfeedback-rating-number-container,
.magicfeedback-rating-number-option,
.magicfeedback-rating-number-option-label-container,
.magicfeedback-rating-number-value {
    box-sizing: border-box;
}

/* The shared rating-container rule (above, reused by star rating) sets
   align-items:center for its row-of-chips layout \u2014 in a stacked column
   that still nudges a 100%-wide chip inward instead of a true 0 offset.
   Force stretch so every chip fills the exact same width, flush on
   both sides. */
.magicfeedback-rating-number-container-column,
.magicfeedback-rating-number-container-column-reverse {
    align-items: stretch;
}

/* Caption line below the row \u2014 the single place min/max labels live
   for row mode, shared by mobile and desktop. */
.magicfeedback-rating-number-scale-labels {
    display: flex;
    justify-content: space-between;
    gap: var(--mf-space-md);
    margin-top: var(--mf-space-sm);
    font-size: var(--mf-font-size-sm);
    font-weight: var(--mf-font-weight-semibold);
    color: var(--mf-text-secondary);
}

.magicfeedback-rating-number-scale-label {
    overflow-wrap: anywhere;
}

/* assets.minMaxPlaceholderPosition: the caption above or below the row. */
.magicfeedback-rating-number-scale-labels--top {
    margin-top: 0;
    margin-bottom: var(--mf-space-sm);
}

.magicfeedback-rating-number-scale-labels--bottom {
    margin-top: var(--mf-space-sm);
    margin-bottom: 0;
}

/* Row with a text per number: the text sits above each chip (below with
   numberPlaceholdersPosition "bottom"). The option is a column laid out
   inline; this only spaces and styles the text. */
.magicfeedback-rating-number-option--captioned {
    gap: var(--mf-space-xs);
}

.magicfeedback-rating-number-option-caption {
    font-size: var(--mf-font-size-sm);
    font-weight: var(--mf-font-weight-semibold);
    color: var(--mf-text-secondary);
    text-align: center;
    line-height: 1.25;
    overflow-wrap: anywhere;
    cursor: pointer;
}

.magicfeedback-rating-number-scale-label:last-child {
    text-align: end;
}

/* Column, no per-option text: each row is its own separated chip, so
   the min/max labels bookend the stack from outside it \u2014 one line
   above the first chip, one below the last. Margin goes on whichever
   side actually faces the list \u2014 the "before" label (always the first
   child) gets space below it, the "after" one (always right after the
   container, extra option row or not) gets space above it \u2014 so both
   sit the same distance from the chips regardless of which one it is. */
.magicfeedback-rating-number-scale-label-block {
    font-size: var(--mf-font-size-sm);
    font-weight: var(--mf-font-weight-semibold);
    color: var(--mf-text-secondary);
    text-align: center;
}

.magicfeedback-rating-number-scale-label-block:first-child {
    margin-bottom: var(--mf-space-sm);
}

.magicfeedback-rating-number-container + .magicfeedback-rating-number-scale-label-block {
    margin-top: var(--mf-space-sm);
}

.magicfeedback-rating-number-option {
    display: flex;
}

.magicfeedback-rating-number-option-label-container {
    position: relative;
    width: 100%;
    display: flex;
    cursor: pointer;
}

.magicfeedback-rating-number-option-label-container input[type="radio"] {
    position: absolute;
    opacity: 0;
    width: 0;
    height: 0;
}

.magicfeedback-rating-number-value {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    transition: var(--mf-transition-fast);
    color: var(--mf-text-secondary);
    font-weight: var(--mf-font-weight-semibold);
}

/* Row: individual outlined chips in the survey's own primary color \u2014
   var(--mf-primary) so whatever brand color a given survey sets carries
   through automatically, no color hardcoded here. */
.magicfeedback-rating-number-container-row,
.magicfeedback-rating-number-container-row-reverse {
    flex-wrap: nowrap;
    gap: var(--mf-space-sm);
}

.magicfeedback-rating-number-option-row,
.magicfeedback-rating-number-option-row-reverse {
    flex: 1 1 0;
    min-width: 0;
}

.magicfeedback-rating-number-option-row .magicfeedback-rating-number-value,
.magicfeedback-rating-number-option-row-reverse .magicfeedback-rating-number-value {
    min-height: 56px;
    padding: var(--mf-space-sm);
    border: 2px solid var(--mf-primary-border);
    border-radius: var(--mf-radius-md);
    background: var(--mf-bg-secondary);
    color: var(--mf-primary);
    font-size: var(--mf-font-size-lg);
    font-weight: var(--mf-font-weight-bold);
}

/* More than 6 options (e.g. a 0-10 NPS scale): still one row, never
   wraps \u2014 but scaled down on purpose, so it reads as a compact chip
   rather than the same 56px button stretched thin. */
.magicfeedback-rating-number-container-row--dense .magicfeedback-rating-number-option-row .magicfeedback-rating-number-value,
.magicfeedback-rating-number-container-row--dense .magicfeedback-rating-number-option-row-reverse .magicfeedback-rating-number-value {
    min-height: 36px;
    padding: var(--mf-space-xs);
    border-radius: var(--mf-radius-sm);
    font-size: 0.8rem;
}

@media (hover: hover) {
    .magicfeedback-rating-number-option-row .magicfeedback-rating-number-option-label-container:hover .magicfeedback-rating-number-value,
    .magicfeedback-rating-number-option-row-reverse .magicfeedback-rating-number-option-label-container:hover .magicfeedback-rating-number-value {
        background: var(--mf-primary-light);
    }
}

.magicfeedback-rating-number-option-row .magicfeedback-rating-number-option-label-container input[type="radio"]:checked + .magicfeedback-rating-number-value,
.magicfeedback-rating-number-option-row-reverse .magicfeedback-rating-number-option-label-container input[type="radio"]:checked + .magicfeedback-rating-number-value {
    color: #fff;
    background-color: var(--mf-primary);
    box-shadow: var(--mf-shadow-md);
}

/* Extra option: always its own row below the scale, and styled like every
   other chip now \u2014 "doesn't apply" is still not a point on the 1..N
   continuum, but it no longer needs a different border style to say so. */
.magicfeedback-rating-number-extra-row {
    display: flex;
    justify-content: center;
    margin-top: var(--mf-space-sm);
}

.magicfeedback-rating-number-option--extra {
    flex: 0 1 auto;
}

.magicfeedback-rating-number-option--extra .magicfeedback-rating-number-option-label-container {
    width: auto;
}

.magicfeedback-rating-number-option--extra .magicfeedback-rating-number-value {
    min-height: 36px;
    padding: 0 var(--mf-space-md);
    border: 2px solid var(--mf-primary-border);
    border-radius: var(--mf-radius-md);
    background: var(--mf-bg-secondary);
    color: var(--mf-primary);
    font-size: var(--mf-font-size-sm);
}

@media (hover: hover) {
    .magicfeedback-rating-number-option--extra .magicfeedback-rating-number-option-label-container:hover .magicfeedback-rating-number-value {
        background: var(--mf-primary-light);
    }
}

.magicfeedback-rating-number-option--extra .magicfeedback-rating-number-option-label-container input[type="radio"]:checked + .magicfeedback-rating-number-value {
    color: #fff;
    background-color: var(--mf-primary);
    box-shadow: var(--mf-shadow-md);
}

/* Column: the same separated chips as row, just stacked \u2014 each option is
   its own outlined chip with a gap between them, not one shared box. */
.magicfeedback-rating-number-container-column,
.magicfeedback-rating-number-container-column-reverse {
    gap: var(--mf-space-sm);
}

.magicfeedback-rating-number-option-column,
.magicfeedback-rating-number-option-column-reverse {
    width: 100%;
}

.magicfeedback-rating-number-option-column .magicfeedback-rating-number-value,
.magicfeedback-rating-number-option-column-reverse .magicfeedback-rating-number-value {
    justify-content: flex-start;
    gap: var(--mf-space-sm);
    min-height: 48px;
    padding: var(--mf-space-sm) var(--mf-space-md);
    border: 2px solid var(--mf-primary-border);
    border-radius: var(--mf-radius-md);
    background: var(--mf-bg-secondary);
    color: var(--mf-primary);
}

@media (hover: hover) {
    .magicfeedback-rating-number-option-column .magicfeedback-rating-number-option-label-container:hover .magicfeedback-rating-number-value,
    .magicfeedback-rating-number-option-column-reverse .magicfeedback-rating-number-option-label-container:hover .magicfeedback-rating-number-value {
        background: var(--mf-primary-light);
    }
}

.magicfeedback-rating-number-option-column .magicfeedback-rating-number-option-label-container input[type="radio"]:checked + .magicfeedback-rating-number-value,
.magicfeedback-rating-number-option-column-reverse .magicfeedback-rating-number-option-label-container input[type="radio"]:checked + .magicfeedback-rating-number-value {
    color: #fff;
    background-color: var(--mf-primary);
    box-shadow: var(--mf-shadow-md);
}

.magicfeedback-rating-number-value-num {
    font-weight: var(--mf-font-weight-bold);
}

/* Column with per-option text: a min-width so "1".."9" and "10" line up,
   with the label text starting at the same x. Skipped entirely when the
   column has no per-option text at all (--bare below) \u2014 with nothing to
   align against, the same left-shift bug from row mode would resurface. */
.magicfeedback-rating-number-container-column:not(.magicfeedback-rating-number-container-column--bare) .magicfeedback-rating-number-value-num,
.magicfeedback-rating-number-container-column-reverse:not(.magicfeedback-rating-number-container-column--bare) .magicfeedback-rating-number-value-num {
    flex: none;
    min-width: 1.4em;
}

/* Column, no per-option text at all (only min/max, or nothing): a bare
   numbered list has nothing to left-align against, so center each
   number instead of stranding it on the left with blank space beside it. */
.magicfeedback-rating-number-container-column--bare .magicfeedback-rating-number-value {
    justify-content: center;
}

.magicfeedback-rating-number-value-label {
    font-weight: var(--mf-font-weight-medium);
}

.magicfeedback-rating-number-option-column .magicfeedback-rating-number-option-label-container input[type="radio"]:checked + .magicfeedback-rating-number-value,
.magicfeedback-rating-number-option-column-reverse .magicfeedback-rating-number-option-label-container input[type="radio"]:checked + .magicfeedback-rating-number-value {
    color: #fff;
    background-color: var(--mf-primary);
}

/* Star Rating */
.magicfeedback-rating-star-container {
    justify-content: center;
}

.magicfeedback-rating-star-option:not(:checked) > .rating__star {
    font-size: 40px;
    color: var(--mf-border);
    cursor: pointer;
    margin: 0 var(--mf-space-xs);
    transition: var(--mf-transition-fast);
}

@media (hover: hover) {
    .magicfeedback-rating-star-option:not(:checked) > .rating__star:hover,
    .magicfeedback-rating-star-option:not(:checked) > .rating__star:hover ~ span {
        color: #fbbf24;
        transform: scale(1.1);
    }
}

.magicfeedback-rating-star-selected {
    color: #fbbf24 !important;
}

/* ========================================
   MULTIPLE CHOICE WITH IMAGES
   ======================================== */
.magicfeedback-multiple-choice-image-option {
    display: flex;
    border-radius: var(--mf-radius-md);
    overflow: hidden;
    transition: var(--mf-transition-fast);
}

.magicfeedback-image-option-label-container {
    cursor: pointer;
    border-radius: var(--mf-radius-md);
    overflow: hidden;
    transition: var(--mf-transition-fast);
}

.magicfeedback-image-option-label-container input[type="radio"],
.magicfeedback-image-option-label-container input[type="checkbox"] {
    position: absolute;
    opacity: 0;
    width: 0;
    height: 0;
}

.magicfeedback-image-option-label-container img {
    width: 100%;
    height: auto;
    display: block;
    border: 2px solid var(--mf-border);
    border-radius: var(--mf-radius-md);
    transition: var(--mf-transition-fast);
}

@media (hover: hover) {
    .magicfeedback-image-option-label-container:hover img {
        border-color: var(--mf-primary);
        box-shadow: var(--mf-shadow-md);
    }
}

.magicfeedback-image-option-label-container input:checked + img {
    border-color: var(--mf-primary);
    box-shadow: 0 0 0 3px var(--mf-primary-light);
}

/* ========================================
   MATRIX QUESTIONS
   ======================================== */
.magicfeedback-multi-question-matrix-container {
    width: 100%;
    overflow-x: auto;
    border-radius: var(--mf-radius-md);
    /* the layout follows the space the survey gets (a pop-in, a sidebar),
       not the size of the window */
    container-type: inline-size;
}

.magicfeedback-multi-question-matrix-table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0 var(--mf-space-xs);
}

.magicfeedback-multi-question-matrix-table th {
    padding: var(--mf-space-md);
    text-align: center;
    font-size: var(--mf-font-size-sm);
    font-weight: 500;
    color: var(--mf-text-secondary);
}

.magicfeedback-multi-question-matrix-row-tr {
    background-color: var(--mf-bg-primary);
    border-radius: var(--mf-radius-md);
    transition: var(--mf-transition-fast);
}

.magicfeedback-multi-question-matrix-row-tr:nth-child(even) {
    background-color: var(--mf-bg-secondary);
}

@media (hover: hover) {
    .magicfeedback-multi-question-matrix-row-tr:hover {
        background-color: var(--mf-bg-hover);
        box-shadow: var(--mf-shadow-sm);
    }
}

.magicfeedback-multi-question-matrix-table td {
    padding: var(--mf-space-md);
    text-align: center;
}

.magicfeedback-multi-question-matrix-label {
    text-align: start;
    font-size: var(--mf-font-size-base);
    color: var(--mf-text-primary);
}

.magicfeedback-multi-question-matrix-table input[type="radio"] {
    width: 20px;
    height: 20px;
    cursor: pointer;
    accent-color: var(--mf-primary);
}

.magicfeedback-multi-question-matrix-question {
    min-width: 200px;
    padding: 10px;
}

/* the column header names the option in a table; the per-cell label is for
   screen readers until the rows stack */
.magicfeedback-multi-question-matrix-option-label {
    position: absolute;
    width: 1px;
    height: 1px;
    overflow: hidden;
    clip: rect(0, 0, 0, 0);
    white-space: nowrap;
}

/* narrow container: every row becomes its own question with the options
   stacked underneath, instead of a table cut off at the side */
@container (max-width: 599px) {
    .magicfeedback-multi-question-matrix-table,
    .magicfeedback-multi-question-matrix-table tbody,
    .magicfeedback-multi-question-matrix-table tr,
    .magicfeedback-multi-question-matrix-table td {
        display: block;
        width: 100%;
    }

    .magicfeedback-multi-question-matrix-table thead {
        display: none;
    }

    .magicfeedback-multi-question-matrix-row-tr,
    .magicfeedback-multi-question-matrix-row-tr:nth-child(even) {
        margin-bottom: var(--mf-space-lg);
        background: transparent;
        box-shadow: none;
    }

    @media (hover: hover) {
        .magicfeedback-multi-question-matrix-row-tr:hover {
            margin-bottom: var(--mf-space-lg);
            background: transparent;
            box-shadow: none;
        }
    }

    .magicfeedback-multi-question-matrix-table td.magicfeedback-multi-question-matrix-question {
        min-width: 0;
        padding: 0 0 var(--mf-space-sm);
        text-align: start;
    }

    .magicfeedback-multi-question-matrix-question .magicfeedback-multi-question-matrix-label {
        font-weight: 600;
    }

    .magicfeedback-multi-question-matrix-table td.magicfeedback-multi-question-matrix-option {
        display: flex;
        align-items: center;
        gap: var(--mf-space-sm);
        margin-bottom: var(--mf-space-sm);
        padding: 0 var(--mf-space-md);
        text-align: start;
        background: var(--mf-bg-secondary);
        border: 2px solid var(--mf-border);
        border-radius: var(--mf-radius-md);
        cursor: pointer;
        transition: var(--mf-transition-fast);
    }

    @media (hover: hover) {
        .magicfeedback-multi-question-matrix-option:hover {
            border-color: var(--mf-primary-border);
        }
    }

    .magicfeedback-multi-question-matrix-option:has(input:checked) {
        border-color: var(--mf-primary);
        background: var(--mf-primary-light);
    }

    .magicfeedback-multi-question-matrix-table .magicfeedback-multi-question-matrix-option input[type="radio"] {
        flex-shrink: 0;
    }

    /* the whole card is the click target */
    .magicfeedback-multi-question-matrix-option-label {
        position: static;
        flex: 1;
        width: auto;
        height: auto;
        padding: var(--mf-space-md) 0;
        overflow: visible;
        clip: auto;
        white-space: normal;
        font-size: var(--mf-font-size-base);
        color: var(--mf-text-primary);
        cursor: pointer;
    }
}

/* ========================================
   MAXDIFF (BEST\u2013WORST)
   ======================================== */
.magicfeedback-max-diff {
    /* "least" gets its own hue, apart from the brand color "most" uses; dark
       enough to read as header text and to hold the white center dot */
    --mf-max-diff-worst: #b45309;
    width: 100%;
}

.magicfeedback-max-diff-container {
    width: 100%;
    /* the layout follows the space the survey gets (a pop-in, a sidebar),
       not the size of the window */
    container-type: inline-size;
}

.magicfeedback-max-diff-progress {
    display: flex;
    align-items: center;
    gap: var(--mf-space-md);
    margin-bottom: var(--mf-space-lg);
}

.magicfeedback-max-diff-progress-label {
    font-size: 0.8125rem;
    font-weight: var(--mf-font-weight-bold);
    letter-spacing: 0.04em;
    text-transform: uppercase;
    white-space: nowrap;
    color: var(--mf-text-secondary);
}

.magicfeedback-max-diff-progress-track {
    flex: 1;
    height: 6px;
    overflow: hidden;
    border-radius: var(--mf-radius-full);
    background: var(--mf-border);
}

.magicfeedback-max-diff-progress-fill {
    display: block;
    height: 100%;
    border-radius: var(--mf-radius-full);
    background: var(--mf-primary);
}

.magicfeedback-max-diff-table {
    width: 100%;
    border-collapse: collapse;
}

.magicfeedback-max-diff-head,
.magicfeedback-max-diff-head-spacer {
    border-bottom: 1px solid var(--mf-border);
}

.magicfeedback-max-diff-head {
    width: 11rem;
    padding: 0 var(--mf-space-sm) var(--mf-space-sm);
    font-size: 0.8125rem;
    font-weight: var(--mf-font-weight-extrabold);
    letter-spacing: 0.04em;
    text-transform: uppercase;
    text-align: center;
    vertical-align: bottom;
}

.magicfeedback-max-diff-head-best {
    color: var(--mf-primary);
}

.magicfeedback-max-diff-head-worst {
    color: var(--mf-max-diff-worst);
}

.magicfeedback-max-diff-head-label {
    display: inline-flex;
    align-items: center;
    gap: 6px;
}

.magicfeedback-max-diff-row {
    transition: background-color 0.15s ease;
}

.magicfeedback-max-diff-row > * {
    border-bottom: 1px solid var(--mf-border);
}

.magicfeedback-max-diff-row:has(.magicfeedback-max-diff-best:checked) {
    background-color: color-mix(in srgb, var(--mf-primary) 8%, transparent);
}

.magicfeedback-max-diff-row:has(.magicfeedback-max-diff-worst:checked) {
    background-color: color-mix(in srgb, var(--mf-max-diff-worst) 8%, transparent);
}

.magicfeedback-max-diff-item {
    padding: var(--mf-space-md) var(--mf-space-sm);
    font-size: 1.0625rem;
    font-weight: var(--mf-font-weight-semibold);
    line-height: 1.4;
    text-align: center;
    color: var(--mf-text-primary);
}

.magicfeedback-max-diff-row:has(input:checked) .magicfeedback-max-diff-item {
    font-weight: var(--mf-font-weight-extrabold);
}

.magicfeedback-max-diff-cell {
    padding: 0;
}

/* the whole cell is the click target */
.magicfeedback-max-diff-pick {
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 64px;
    cursor: pointer;
}

.magicfeedback-max-diff-input {
    appearance: none;
    -webkit-appearance: none;
    flex-shrink: 0;
    width: 26px;
    height: 26px;
    margin: 0;
    border: 2px solid color-mix(in srgb, var(--mf-text-secondary) 80%, white);
    border-radius: var(--mf-radius-full);
    background: var(--mf-bg-secondary);
    cursor: pointer;
    transition: var(--mf-transition-fast);
}

@media (hover: hover) {
    .magicfeedback-max-diff-pick:hover .magicfeedback-max-diff-input {
        transform: scale(1.08);
    }
}

.magicfeedback-max-diff-best:checked {
    border-color: var(--mf-primary);
    background: radial-gradient(circle, #FFFFFF 0 4px, var(--mf-primary) 4.5px);
}

.magicfeedback-max-diff-worst:checked {
    border-color: var(--mf-max-diff-worst);
    background: radial-gradient(circle, #FFFFFF 0 4px, var(--mf-max-diff-worst) 4.5px);
}

.magicfeedback-max-diff-input:focus-visible {
    outline: 3px solid var(--mf-primary-border);
    outline-offset: 3px;
}

/* narrow container: same table, slimmer pick columns and the header icon
   stacked over its label */
@container (max-width: 599px) {
    .magicfeedback-max-diff-head {
        width: 4.75rem;
        padding-inline: 2px;
        font-size: 0.6875rem;
    }

    .magicfeedback-max-diff-head-label {
        flex-direction: column;
        gap: 2px;
    }

    .magicfeedback-max-diff-item {
        padding-inline: 4px;
        font-size: var(--mf-font-size-base);
    }

    .magicfeedback-max-diff-pick {
        min-height: 68px;
    }

    .magicfeedback-max-diff-input {
        width: 28px;
        height: 28px;
    }
}

/* ========================================
   PRIORITY LIST
   ======================================== */
.magicfeedback-priority-list-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: var(--mf-space-md);
    margin: var(--mf-space-sm) 0;
    background-color: var(--mf-bg-primary);
    border: 1.5px solid var(--mf-border);
    border-radius: var(--mf-radius-md);
    transition: var(--mf-transition-fast);
}

@media (hover: hover) {
    .magicfeedback-priority-list-item:hover {
        box-shadow: var(--mf-shadow-sm);
        border-color: var(--mf-primary);
    }
}

.magicfeedback-priority-list-item-label {
    flex: 1;
    font-size: var(--mf-font-size-base);
    text-align: start;
    color: var(--mf-text-primary);
    margin: 0;
}

.magicfeedback-priority-list-arrow-up,
.magicfeedback-priority-list-arrow-down {
    padding: var(--mf-space-xs);
    font-size: var(--mf-font-size-lg);
    color: var(--mf-text-secondary);
    cursor: pointer;
    transition: var(--mf-transition-fast);
    user-select: none;
}

@media (hover: hover) {
    .magicfeedback-priority-list-arrow-up:hover,
    .magicfeedback-priority-list-arrow-down:hover {
        color: var(--mf-primary);
        transform: scale(1.2);
    }
}

/* ========================================
   POINT SYSTEM
   ======================================== */
.magicfeedback-point-system-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: var(--mf-space-md);
    margin: var(--mf-space-sm) 0;
    background-color: var(--mf-bg-primary);
    border: 1.5px solid var(--mf-border);
    border-radius: var(--mf-radius-md);
    min-height: 45px;
}

.magicfeedback-point-system-item label {
    flex: 1;
    font-size: var(--mf-font-size-base);
    color: var(--mf-text-primary);
    margin: 0;
}

.magicfeedback-point-system-input-container {
    display: flex;
    align-items: center;
    gap: var(--mf-space-sm);
}

.magicfeedback-point-system-item input {
    width: 80px;
    min-width: 80px;
    padding: var(--mf-space-sm);
    text-align: center;
    font-size: var(--mf-font-size-base);
    border: 1.5px solid var(--mf-border);
    border-radius: var(--mf-radius-md);
    margin: 0;
}

.magicfeedback-point-system-total {
    display: flex;
    justify-content: flex-end;
    margin-top: var(--mf-space-md);
    font-size: var(--mf-font-size-base);
    font-weight: 600;
    color: var(--mf-text-primary);
}

/* ========================================
   CONSENT
   ======================================== */
.magicfeedback-consent-container {
    display: flex;
    flex-direction: row;
    align-items: center;
    gap: var(--mf-space-sm);
    padding: var(--mf-space-md);
    background-color: var(--mf-bg-secondary);
    border-radius: var(--mf-radius-md);
    margin: var(--mf-space-md) 0;
}

.magicfeedback-consent-container input[type="checkbox"] {
    margin-top: 2px;
    flex-shrink: 0;
    accent-color: var(--mf-primary);
}

.magicfeedback-consent-container label {
    flex: 1;
    font-size: var(--mf-font-size-sm);
    text-align: start;
    color: var(--mf-text-secondary);
    line-height: var(--mf-line-height);
    cursor: pointer;
    margin-bottom: 0;
}

/* ========================================
   ACTION BUTTONS
   ======================================== */
.magicfeedback-action-container {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--mf-space-md);
    margin-top: var(--mf-space-xl);
    padding-top: var(--mf-space-lg);
    border-top: 1px solid var(--mf-border);
}

.magicfeedback-submit {
    padding: 0.8rem 1.6rem;
    font-size: var(--mf-font-size-base);
    font-weight: 800;
    color: #FFFFFF;
    background-color: var(--mf-primary);
    border: 2px solid var(--mf-primary);
    border-radius: var(--mf-radius-full);
    cursor: pointer;
    transition: var(--mf-transition-fast);
    box-shadow: var(--mf-shadow-md);
}

@media (hover: hover) {
    .magicfeedback-submit:hover {
        background-color: var(--mf-primary-hover);
        box-shadow: var(--mf-shadow-lg);
        transform: translateY(-2px);
    }
}

.magicfeedback-submit:active {
    transform: translateY(0);
    box-shadow: var(--mf-shadow-sm);
}

.magicfeedback-submit:disabled {
    opacity: 0.5;
    cursor: not-allowed;
    transform: none;
}

.magicfeedback-back {
    padding: 0.65rem 1rem;
    font-size: var(--mf-font-size-base);
    font-weight: 700;
    color: var(--mf-primary);
    background-color: var(--mf-bg-secondary);
    border: 2px solid var(--mf-border);
    border-radius: var(--mf-radius-full);
    cursor: pointer;
    transition: var(--mf-transition-fast);
}

@media (hover: hover) {
    .magicfeedback-back:hover {
        border-color: var(--mf-primary);
        background-color: var(--mf-bg-hover);
    }
}

/* hidden on the first page; keep the submit button on the right */
.magicfeedback-back[hidden] {
    display: none;
}

.magicfeedback-action-container .magicfeedback-submit {
    margin-left: auto;
}

/* ========================================
   SKIP & COUNTER
   ======================================== */
.magicfeedback-skip-container {
    display: flex;
    align-items: center;
    gap: var(--mf-space-xs);
    padding: 0;
    margin: 0;
    font-size: var(--mf-font-size-sm);
    color: var(--mf-text-muted);
    background: transparent;
    border: none;
    cursor: pointer;
    transition: var(--mf-transition-fast);
}

@media (hover: hover) {
    .magicfeedback-skip-container:hover {
        color: var(--mf-primary);
    }
}

.magicfeedback-skip-container input[type="checkbox"] {
    margin: 0;
    cursor: pointer;
    accent-color: var(--mf-primary);
}

.magicfeedback-counter {
    display: flex;
    justify-content: flex-end;
    margin-top: var(--mf-space-md);
    font-size: var(--mf-font-size-sm);
    color: var(--mf-text-muted);
}

/* ========================================
   MODAL STYLES
   ======================================== */
/* Modal backdrop */
.magicfeedback-modal-backdrop {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0,0,0,0.4);
    display: none; /* toggled to flex when open */
    align-items: center;
    justify-content: center;
    z-index: 9999;
}

/* Modal container */
.magicfeedback-modal {
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 8px 24px rgba(0,0,0,0.2);
    max-width: 520px;
    width: 90%;
    max-height: 80vh;
    /* Flex column so the options list scrolls while the actions footer
       (counter + confirm button) stays pinned and always visible. */
    display: flex;
    flex-direction: column;
    overflow: hidden;
    padding: 16px;
    position: relative;
    /* Portalled to document.body (see renderPriorityList.ts) to escape the
       host page's overflow/z-index \u2014 so it never inherits
       .magicfeedback-container's neutral text color and instead inherits
       whatever color the host page's own <body> happens to set. Needs its
       own explicit baseline rather than relying on that inheritance. */
    color: var(--mf-text-primary);
}

/* Modal actions */
.magicfeedback-modal-actions {
    display: flex;
    justify-content: flex-end;
    gap: 8px;
    margin-top: 12px;
    flex-shrink: 0;
}

.magicfeedback-modal-counter {
    margin-inline-end: auto;
    display: flex;
    align-items: center;
    font-size: 14px;
    color: var(--mf-text-secondary);
}

/* Modal list */
.magicfeedback-modal-list {
    display: flex;
    flex-direction: column;
    gap: 8px;
    /* Scrollable area; footer stays fixed below it. */
    flex: 1 1 auto;
    overflow-y: auto;
    min-height: 0;
}

.magicfeedback-modal-row {
    display: flex;
    align-items: center;
    gap: 10px;
    cursor: pointer;
}

/* Priority list header */
.magicfeedback-priority-list-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    margin-bottom: 8px;
}

.magicfeedback-priority-list-reorder {
    margin-top: 8px;
}

.magicfeedback-priority-list-list {
    padding: 0;
    list-style: none;
}

.magicfeedback-priority-list-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin: 5px 0;
}

.magicfeedback-priority-list-item-label {
    font-size: 15px;
}

.magicfeedback-priority-list-arrows {
    display: flex;
    align-items: center;
    gap: 6px;
}

/* Buttons */
.magicfeedback-button {
    appearance: none;
    border: 2px solid var(--mf-border);
    border-radius: var(--mf-radius-full);
    background: var(--mf-bg-secondary);
    color: var(--mf-text-primary);
    padding: 0.6rem 1rem;
    font-size: 14px;
    font-weight: 700;
    cursor: pointer;
    box-shadow: var(--mf-shadow-sm);
}

@media (hover: hover) {
    .magicfeedback-button:hover {
        background: var(--mf-bg-hover);
        border-color: var(--mf-primary);
    }
}

.magicfeedback-button:active {
    transform: translateY(1px);
}

.magicfeedback-button-primary {
    border-color: var(--mf-primary);
    background: var(--mf-primary);
    color: #fff;
    box-shadow: var(--mf-shadow-md);
}

@media (hover: hover) {
    .magicfeedback-button-primary:hover {
        background: var(--mf-primary-hover);
    }
}

.magicfeedback-button-primary:active {
    background: var(--mf-primary-hover);
}

/* Warning flash */
.magicfeedback-warning {
    color: #C70039;
}

/* Start message button */
.magicfeedback-start-message-button {
    appearance: none;
    border: 2px solid var(--mf-primary);
    border-radius: var(--mf-radius-full);
    background: var(--mf-primary);
    color: #fff;
    padding: 0.8rem 1.4rem;
    font-size: 15px;
    font-weight: 800;
    cursor: pointer;
    box-shadow: var(--mf-shadow-md);
}

@media (hover: hover) {
    .magicfeedback-start-message-button:hover {
        background: var(--mf-primary-hover);
    }
}

/* ========================================
   RESPONSIVE DESIGN
   ======================================== */
@media (max-width: 768px) {
    :root {
        --mf-space-lg: 1.25rem;
        --mf-space-xl: 1.5rem;
    }

    .magicfeedback-container {
        padding: 12px;
        border-radius: var(--mf-radius-md);
    }

    .magicfeedback-form {
        padding: 14px;
        border-radius: var(--mf-radius-md);
    }

    .magicfeedback-div {
        padding: 12px;
        gap: var(--mf-space-lg)
    }

    .magicfeedback-label {
        font-size: var(--mf-font-size-base);
    }

    .deepdots-popup input[type="date"],
    .deepdots-popup input[type="text"],
    .deepdots-popup input[type="number"],
    .deepdots-popup input[type="email"],
    .deepdots-popup input[type="password"],
    .deepdots-popup textarea,
    .deepdots-popup select {
        padding: 0.85rem 0.95rem;
        font-size: 1rem;
        min-height: 46px;
    }

    /*
    .magicfeedback-radio-container,
    .magicfeedback-checkbox-container,
    .magicfeedback-boolean-container,
    .magicfeedback-consent-container {
        width: 100%;
    }
    */

    .magicfeedback-radio-container,
    .magicfeedback-checkbox-container {
        padding: 10px 12px;
        border-radius: var(--mf-radius-md);
        border: 1px solid var(--mf-border);
        gap: 10px;
    }

    .magicfeedback-rating-container,
    .magicfeedback-rating-number-container,
    .magicfeedback-rating-star-container {
        gap: 10px;
    }

    .magicfeedback-boolean-container {
        flex-direction: column;
        gap: 10px;
    }

    .magicfeedback-rating-number-container-row,
    .magicfeedback-rating-number-container-row-reverse {
        gap: 6px;
    }

    .magicfeedback-rating-number-option-row .magicfeedback-rating-number-value,
    .magicfeedback-rating-number-option-row-reverse .magicfeedback-rating-number-value {
        min-height: 44px;
        padding: var(--mf-space-xs);
        font-size: 0.9rem;
    }

    .magicfeedback-action-container {
        flex-direction: column-reverse;
    }

    .magicfeedback-submit,
    .magicfeedback-back {
        width: 100%;
        text-align: center;
        min-height: 48px;
    }
}

/* ========================================
   ACCESSIBILITY
   ======================================== */
@media (prefers-reduced-motion: reduce) {
    *,
    *::before,
    *::after {
        animation-duration: 0.01ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: 0.01ms !important;
    }
}


/* ========================================
   UTILITY CLASSES
   ======================================== */
.magicfeedback-visually-hidden {
    position: absolute;
    width: 1px;
    height: 1px;
    padding: 0;
    margin: -1px;
    overflow: hidden;
    clip: rect(0, 0, 0, 0);
    white-space: nowrap;
    border-width: 0;
}

.magicfeedback-modal-close {
    position: absolute;
    top: 8px;
    inset-inline-end: 8px;
    background: transparent;
    border: none;
    font-size: 20px;
    line-height: 1;
    cursor: pointer;
    color: #666;
}

.magicfeedback-modal-close:focus {
    color: #000;
    outline: none;
}

@media (hover: hover) {
    .magicfeedback-modal-close:hover {
        color: #000;
        outline: none;
    }
}

/* ========================================
   FILE / IMAGE UPLOAD
   ======================================== */
.magicfeedback-upload {
    display: flex;
    flex-direction: column;
    gap: var(--mf-space-md);
    width: 100%;
    margin: 10px 0;
}

/* The native input is an invisible, focusable overlay covering the dropzone. */
.magicfeedback-upload-native {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    margin: 0;
    padding: 0;
    opacity: 0;
    cursor: pointer;
    z-index: 2;
}

.magicfeedback-upload-dropzone {
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: var(--mf-space-sm);
    box-sizing: border-box;
    width: 100%;
    min-height: 150px;
    padding: var(--mf-space-xl);
    text-align: center;
    border: 2px dashed var(--mf-border);
    border-radius: var(--mf-radius-md);
    background-color: var(--mf-surface-alt);
    cursor: pointer;
    transition: var(--mf-transition);
}

@media (hover: hover) {
    .magicfeedback-upload-dropzone:hover {
        border-color: var(--mf-primary);
        background-color: var(--mf-bg-hover);
    }
}

.magicfeedback-upload-dropzone:focus-within {
    border-color: var(--mf-primary);
    box-shadow: var(--mf-shadow-focus);
}

.magicfeedback-upload-dropzone.is-dragover {
    border-color: var(--mf-primary);
    border-style: solid;
    background-color: var(--mf-primary-light);
    box-shadow: var(--mf-shadow-focus);
}

.magicfeedback-upload-icon {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 46px;
    height: 46px;
    color: var(--mf-primary);
    background-color: var(--mf-surface);
    border-radius: var(--mf-radius-full);
    box-shadow: var(--mf-shadow-sm);
    pointer-events: none;
}

.magicfeedback-upload-icon svg {
    width: 24px;
    height: 24px;
}

.magicfeedback-upload-cta {
    font-family: inherit;
    font-weight: var(--mf-font-weight-semibold);
    font-size: var(--mf-font-size-base);
    color: var(--mf-text-primary);
    pointer-events: none;
}

.magicfeedback-upload-hint {
    font-family: inherit;
    font-size: var(--mf-font-size-sm);
    color: var(--mf-text-muted);
    pointer-events: none;
}

.magicfeedback-upload-list {
    display: flex;
    flex-direction: column;
    gap: var(--mf-space-sm);
    width: 100%;
    margin: 0;
    padding: 0;
    list-style: none;
}

.magicfeedback-upload-list:empty {
    display: none;
}

.magicfeedback-upload-file-item {
    display: flex;
    align-items: center;
    gap: var(--mf-space-md);
    padding: var(--mf-space-sm) var(--mf-space-md);
    background-color: var(--mf-surface);
    border: 1px solid var(--mf-border);
    border-radius: var(--mf-radius-sm);
    box-shadow: var(--mf-shadow-sm);
    animation: mf-scale-in 0.2s ease-out;
}

.magicfeedback-upload-thumb {
    flex: 0 0 auto;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    overflow: hidden;
    color: var(--mf-text-secondary);
    background-color: var(--mf-surface-alt);
    border-radius: var(--mf-radius-sm);
}

.magicfeedback-upload-thumb img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.magicfeedback-upload-thumb svg {
    width: 20px;
    height: 20px;
}

.magicfeedback-upload-file-info {
    display: flex;
    flex-direction: column;
    flex: 1 1 auto;
    min-width: 0;
    text-align: start;
}

.magicfeedback-upload-file-name {
    font-family: inherit;
    font-size: var(--mf-font-size-sm);
    font-weight: var(--mf-font-weight-semibold);
    color: var(--mf-text-primary);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.magicfeedback-upload-file-size {
    font-family: inherit;
    font-size: 0.75rem;
    color: var(--mf-text-muted);
}

.magicfeedback-upload-remove {
    flex: 0 0 auto;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 30px;
    height: 30px;
    padding: 0;
    color: var(--mf-text-muted);
    background-color: transparent;
    border: none;
    border-radius: var(--mf-radius-full);
    cursor: pointer;
    transition: var(--mf-transition-fast);
}

.magicfeedback-upload-remove:focus-visible {
    color: var(--mf-error);
    background-color: var(--mf-primary-light);
    outline: none;
}

@media (hover: hover) {
    .magicfeedback-upload-remove:hover {
        color: var(--mf-error);
        background-color: var(--mf-primary-light);
        outline: none;
    }
}

.magicfeedback-upload-remove svg {
    width: 16px;
    height: 16px;
}

.magicfeedback-upload-error {
    display: none;
    font-family: inherit;
    font-size: var(--mf-font-size-sm);
    color: var(--mf-error);
}

.magicfeedback-upload-error.is-visible {
    display: block;
}

/* ========================================
   RTL (Arabic)
   ========================================
   The SDK stamps dir="rtl" (and .magicfeedback-rtl) on the survey container
   for right-to-left languages. Everything else in this stylesheet uses logical
   properties (text-align: start, padding-inline-*, inset-inline-*), so it
   mirrors on its own; only the handful of rules that cannot be expressed
   logically live here.

   Rules are scoped to [dir="rtl"] inside our own subtree so a host page that is
   itself RTL, or one that embeds an Arabic survey in an LTR page, both render
   correctly. */

/* background-position has no logical form: move the select caret to the
   left edge, opposite the padding that inset-inline-end already mirrored. */
[dir="rtl"] select {
    background-position: left var(--mf-space-md) center;
}

/* Emails, URLs, numbers, dates and phone numbers are latin/numeric content
   even in an Arabic survey: keep their own direction LTR so punctuation
   (@, ., +, /) lands where the user expects, but align them to the start of
   the RTL line so they still read as part of the form. */
[dir="rtl"] input[type="email"],
[dir="rtl"] input[type="url"],
[dir="rtl"] input[type="number"],
[dir="rtl"] input[type="tel"],
[dir="rtl"] input[type="date"],
[dir="rtl"] input[type="time"] {
    direction: ltr;
    text-align: right;
}

/* Mirror of mf-slide-in: questions enter from the reading edge. */
@keyframes mf-slide-in-rtl {
    from {
        opacity: 0;
        transform: translateX(16px);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}

[dir="rtl"] .magicfeedback-div {
    animation-name: mf-slide-in-rtl;
}

/* ========================================
   LOCAL \u2014 reglas del popup, no vienen del paquete
   ======================================== */

/* Los controles de formulario no heredan font-family: cuando el popup trae fuente propia
   (clase deepdots-has-font), se les fuerza la del contenedor. */
.deepdots-popup.deepdots-has-font button,
.deepdots-popup.deepdots-has-font input,
.deepdots-popup.deepdots-has-font textarea,
.deepdots-popup.deepdots-has-font select {
    font-family: var(--deepdots-font, inherit);
}

/* WebKit s\xED aplica el padding al radio nativo: con padding el control se dibuja enorme (se vio
   en iOS, WebView de RN y Safari, no en Chrome). El paquete ya no lo pone, pero la regla es
   barata y evita que vuelva. */
.deepdots-popup input[type="radio"] {
    padding: 0;
}
`;

// src/util/logger.ts
var active = console;
function setLogger(logger) {
  active = logger ?? console;
}
function sdkLog(...args) {
  active.log(...args);
}
function sdkWarn(...args) {
  (active.warn ?? active.log)(...args);
}
function sdkError(...args) {
  (active.error ?? active.log)(...args);
}

export {
  __commonJS,
  __toESM,
  InMemoryStorage,
  createDefaultStorage,
  STORAGE_KEYS,
  buildSurveyIdentity,
  TrackingManager,
  buildFontFamilyValue,
  buildFontFaceCss,
  LABELS,
  SUPPORTED_LANGUAGES,
  resolveLocale,
  RTL_LOCALES,
  isRtlLanguage,
  directionFor,
  getLabels,
  resolveActionLabels,
  RESOLVE_LOCALE_JS,
  REVEAL_TIMEOUT_MS,
  revealWhenPainted,
  applySurveyPrimaryColor,
  PRIMARY_COLOR_JS,
  setSurveyBusy,
  BUSY_JS,
  classifySubmitError,
  SUBMIT_ERROR_JS,
  style_default,
  setLogger,
  sdkLog,
  sdkWarn,
  sdkError
};
//# sourceMappingURL=chunk-DNBFTJCA.mjs.map