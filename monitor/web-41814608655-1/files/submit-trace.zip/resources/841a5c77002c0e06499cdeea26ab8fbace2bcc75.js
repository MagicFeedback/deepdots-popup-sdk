import {
  REVEAL_TIMEOUT_MS,
  __commonJS,
  __toESM,
  applySurveyPrimaryColor,
  buildFontFaceCss,
  buildFontFamilyValue,
  buildSurveyIdentity,
  classifySubmitError,
  directionFor,
  getLabels,
  resolveActionLabels,
  revealWhenPainted,
  sdkError,
  sdkLog,
  sdkWarn,
  setSurveyBusy,
  style_default
} from "./chunk-DNBFTJCA.mjs";

// node_modules/@magicfeedback/native/dist/magicfeedback-sdk.browser.js
var require_magicfeedback_sdk_browser = __commonJS({
  "node_modules/@magicfeedback/native/dist/magicfeedback-sdk.browser.js"(exports, module) {
    "use strict";
    !(function(e, t) {
      "object" == typeof exports && "object" == typeof module ? module.exports = t() : "function" == typeof define && define.amd ? define([], t) : "object" == typeof exports ? exports.magicfeedback = t() : e.magicfeedback = t();
    })(self, (() => {
      return e = { 6539: function(e2, t2) {
        var i = "undefined" != typeof self ? self : this, n = (function() {
          function e3() {
            this.fetch = false, this.DOMException = i.DOMException;
          }
          return e3.prototype = i, new e3();
        })();
        !(function(e3) {
          !(function(t3) {
            var i2 = "URLSearchParams" in e3, n2 = "Symbol" in e3 && "iterator" in Symbol, r2 = "FileReader" in e3 && "Blob" in e3 && (function() {
              try {
                return new Blob(), true;
              } catch (e4) {
                return false;
              }
            })(), o = "FormData" in e3, a = "ArrayBuffer" in e3;
            if (a) var s = ["[object Int8Array]", "[object Uint8Array]", "[object Uint8ClampedArray]", "[object Int16Array]", "[object Uint16Array]", "[object Int32Array]", "[object Uint32Array]", "[object Float32Array]", "[object Float64Array]"], l = ArrayBuffer.isView || function(e4) {
              return e4 && s.indexOf(Object.prototype.toString.call(e4)) > -1;
            };
            function d(e4) {
              if ("string" != typeof e4 && (e4 = String(e4)), /[^a-z0-9\-#$%&'*+.^_`|~]/i.test(e4)) throw new TypeError("Invalid character in header field name");
              return e4.toLowerCase();
            }
            function c(e4) {
              return "string" != typeof e4 && (e4 = String(e4)), e4;
            }
            function u(e4) {
              var t4 = { next: function() {
                var t5 = e4.shift();
                return { done: void 0 === t5, value: t5 };
              } };
              return n2 && (t4[Symbol.iterator] = function() {
                return t4;
              }), t4;
            }
            function p(e4) {
              this.map = {}, e4 instanceof p ? e4.forEach((function(e5, t4) {
                this.append(t4, e5);
              }), this) : Array.isArray(e4) ? e4.forEach((function(e5) {
                this.append(e5[0], e5[1]);
              }), this) : e4 && Object.getOwnPropertyNames(e4).forEach((function(t4) {
                this.append(t4, e4[t4]);
              }), this);
            }
            function m(e4) {
              if (e4.bodyUsed) return Promise.reject(new TypeError("Already read"));
              e4.bodyUsed = true;
            }
            function h(e4) {
              return new Promise((function(t4, i3) {
                e4.onload = function() {
                  t4(e4.result);
                }, e4.onerror = function() {
                  i3(e4.error);
                };
              }));
            }
            function f(e4) {
              var t4 = new FileReader(), i3 = h(t4);
              return t4.readAsArrayBuffer(e4), i3;
            }
            function g(e4) {
              if (e4.slice) return e4.slice(0);
              var t4 = new Uint8Array(e4.byteLength);
              return t4.set(new Uint8Array(e4)), t4.buffer;
            }
            function y() {
              return this.bodyUsed = false, this._initBody = function(e4) {
                var t4;
                this._bodyInit = e4, e4 ? "string" == typeof e4 ? this._bodyText = e4 : r2 && Blob.prototype.isPrototypeOf(e4) ? this._bodyBlob = e4 : o && FormData.prototype.isPrototypeOf(e4) ? this._bodyFormData = e4 : i2 && URLSearchParams.prototype.isPrototypeOf(e4) ? this._bodyText = e4.toString() : a && r2 && (t4 = e4) && DataView.prototype.isPrototypeOf(t4) ? (this._bodyArrayBuffer = g(e4.buffer), this._bodyInit = new Blob([this._bodyArrayBuffer])) : a && (ArrayBuffer.prototype.isPrototypeOf(e4) || l(e4)) ? this._bodyArrayBuffer = g(e4) : this._bodyText = e4 = Object.prototype.toString.call(e4) : this._bodyText = "", this.headers.get("content-type") || ("string" == typeof e4 ? this.headers.set("content-type", "text/plain;charset=UTF-8") : this._bodyBlob && this._bodyBlob.type ? this.headers.set("content-type", this._bodyBlob.type) : i2 && URLSearchParams.prototype.isPrototypeOf(e4) && this.headers.set("content-type", "application/x-www-form-urlencoded;charset=UTF-8"));
              }, r2 && (this.blob = function() {
                var e4 = m(this);
                if (e4) return e4;
                if (this._bodyBlob) return Promise.resolve(this._bodyBlob);
                if (this._bodyArrayBuffer) return Promise.resolve(new Blob([this._bodyArrayBuffer]));
                if (this._bodyFormData) throw new Error("could not read FormData body as blob");
                return Promise.resolve(new Blob([this._bodyText]));
              }, this.arrayBuffer = function() {
                return this._bodyArrayBuffer ? m(this) || Promise.resolve(this._bodyArrayBuffer) : this.blob().then(f);
              }), this.text = function() {
                var e4, t4, i3, n3 = m(this);
                if (n3) return n3;
                if (this._bodyBlob) return e4 = this._bodyBlob, i3 = h(t4 = new FileReader()), t4.readAsText(e4), i3;
                if (this._bodyArrayBuffer) return Promise.resolve((function(e5) {
                  for (var t5 = new Uint8Array(e5), i4 = new Array(t5.length), n4 = 0; n4 < t5.length; n4++) i4[n4] = String.fromCharCode(t5[n4]);
                  return i4.join("");
                })(this._bodyArrayBuffer));
                if (this._bodyFormData) throw new Error("could not read FormData body as text");
                return Promise.resolve(this._bodyText);
              }, o && (this.formData = function() {
                return this.text().then(E);
              }), this.json = function() {
                return this.text().then(JSON.parse);
              }, this;
            }
            p.prototype.append = function(e4, t4) {
              e4 = d(e4), t4 = c(t4);
              var i3 = this.map[e4];
              this.map[e4] = i3 ? i3 + ", " + t4 : t4;
            }, p.prototype.delete = function(e4) {
              delete this.map[d(e4)];
            }, p.prototype.get = function(e4) {
              return e4 = d(e4), this.has(e4) ? this.map[e4] : null;
            }, p.prototype.has = function(e4) {
              return this.map.hasOwnProperty(d(e4));
            }, p.prototype.set = function(e4, t4) {
              this.map[d(e4)] = c(t4);
            }, p.prototype.forEach = function(e4, t4) {
              for (var i3 in this.map) this.map.hasOwnProperty(i3) && e4.call(t4, this.map[i3], i3, this);
            }, p.prototype.keys = function() {
              var e4 = [];
              return this.forEach((function(t4, i3) {
                e4.push(i3);
              })), u(e4);
            }, p.prototype.values = function() {
              var e4 = [];
              return this.forEach((function(t4) {
                e4.push(t4);
              })), u(e4);
            }, p.prototype.entries = function() {
              var e4 = [];
              return this.forEach((function(t4, i3) {
                e4.push([i3, t4]);
              })), u(e4);
            }, n2 && (p.prototype[Symbol.iterator] = p.prototype.entries);
            var v = ["DELETE", "GET", "HEAD", "OPTIONS", "POST", "PUT"];
            function b(e4, t4) {
              var i3, n3, r3 = (t4 = t4 || {}).body;
              if (e4 instanceof b) {
                if (e4.bodyUsed) throw new TypeError("Already read");
                this.url = e4.url, this.credentials = e4.credentials, t4.headers || (this.headers = new p(e4.headers)), this.method = e4.method, this.mode = e4.mode, this.signal = e4.signal, r3 || null == e4._bodyInit || (r3 = e4._bodyInit, e4.bodyUsed = true);
              } else this.url = String(e4);
              if (this.credentials = t4.credentials || this.credentials || "same-origin", !t4.headers && this.headers || (this.headers = new p(t4.headers)), this.method = (n3 = (i3 = t4.method || this.method || "GET").toUpperCase(), v.indexOf(n3) > -1 ? n3 : i3), this.mode = t4.mode || this.mode || null, this.signal = t4.signal || this.signal, this.referrer = null, ("GET" === this.method || "HEAD" === this.method) && r3) throw new TypeError("Body not allowed for GET or HEAD requests");
              this._initBody(r3);
            }
            function E(e4) {
              var t4 = new FormData();
              return e4.trim().split("&").forEach((function(e5) {
                if (e5) {
                  var i3 = e5.split("="), n3 = i3.shift().replace(/\+/g, " "), r3 = i3.join("=").replace(/\+/g, " ");
                  t4.append(decodeURIComponent(n3), decodeURIComponent(r3));
                }
              })), t4;
            }
            function A(e4, t4) {
              t4 || (t4 = {}), this.type = "default", this.status = void 0 === t4.status ? 200 : t4.status, this.ok = this.status >= 200 && this.status < 300, this.statusText = "statusText" in t4 ? t4.statusText : "OK", this.headers = new p(t4.headers), this.url = t4.url || "", this._initBody(e4);
            }
            b.prototype.clone = function() {
              return new b(this, { body: this._bodyInit });
            }, y.call(b.prototype), y.call(A.prototype), A.prototype.clone = function() {
              return new A(this._bodyInit, { status: this.status, statusText: this.statusText, headers: new p(this.headers), url: this.url });
            }, A.error = function() {
              var e4 = new A(null, { status: 0, statusText: "" });
              return e4.type = "error", e4;
            };
            var k = [301, 302, 303, 307, 308];
            A.redirect = function(e4, t4) {
              if (-1 === k.indexOf(t4)) throw new RangeError("Invalid status code");
              return new A(null, { status: t4, headers: { location: e4 } });
            }, t3.DOMException = e3.DOMException;
            try {
              new t3.DOMException();
            } catch (e4) {
              t3.DOMException = function(e5, t4) {
                this.message = e5, this.name = t4;
                var i3 = Error(e5);
                this.stack = i3.stack;
              }, t3.DOMException.prototype = Object.create(Error.prototype), t3.DOMException.prototype.constructor = t3.DOMException;
            }
            function T(e4, i3) {
              return new Promise((function(n3, o2) {
                var a2 = new b(e4, i3);
                if (a2.signal && a2.signal.aborted) return o2(new t3.DOMException("Aborted", "AbortError"));
                var s2 = new XMLHttpRequest();
                function l2() {
                  s2.abort();
                }
                s2.onload = function() {
                  var e5, t4, i4 = { status: s2.status, statusText: s2.statusText, headers: (e5 = s2.getAllResponseHeaders() || "", t4 = new p(), e5.replace(/\r?\n[\t ]+/g, " ").split(/\r?\n/).forEach((function(e6) {
                    var i5 = e6.split(":"), n4 = i5.shift().trim();
                    if (n4) {
                      var r4 = i5.join(":").trim();
                      t4.append(n4, r4);
                    }
                  })), t4) };
                  i4.url = "responseURL" in s2 ? s2.responseURL : i4.headers.get("X-Request-URL");
                  var r3 = "response" in s2 ? s2.response : s2.responseText;
                  n3(new A(r3, i4));
                }, s2.onerror = function() {
                  o2(new TypeError("Network request failed"));
                }, s2.ontimeout = function() {
                  o2(new TypeError("Network request failed"));
                }, s2.onabort = function() {
                  o2(new t3.DOMException("Aborted", "AbortError"));
                }, s2.open(a2.method, a2.url, true), "include" === a2.credentials ? s2.withCredentials = true : "omit" === a2.credentials && (s2.withCredentials = false), "responseType" in s2 && r2 && (s2.responseType = "blob"), a2.headers.forEach((function(e5, t4) {
                  s2.setRequestHeader(t4, e5);
                })), a2.signal && (a2.signal.addEventListener("abort", l2), s2.onreadystatechange = function() {
                  4 === s2.readyState && a2.signal.removeEventListener("abort", l2);
                }), s2.send(void 0 === a2._bodyInit ? null : a2._bodyInit);
              }));
            }
            T.polyfill = true, e3.fetch || (e3.fetch = T, e3.Headers = p, e3.Request = b, e3.Response = A), t3.Headers = p, t3.Request = b, t3.Response = A, t3.fetch = T, Object.defineProperty(t3, "__esModule", { value: true });
          })({});
        })(n), n.fetch.ponyfill = true, delete n.fetch.polyfill;
        var r = n;
        (t2 = r.fetch).default = r.fetch, t2.fetch = r.fetch, t2.Headers = r.Headers, t2.Request = r.Request, t2.Response = r.Response, e2.exports = t2;
      }, 5867: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.HOST_API_URL_DEV = t2.HOST_API_URL = void 0, t2.HOST_API_URL = "https://api.deepdots.com/", t2.HOST_API_URL_DEV = "https://api-dev.deepdots.com/";
      }, 1422: function(e2, t2, i) {
        "use strict";
        var n = this && this.__importDefault || function(e3) {
          return e3 && e3.__esModule ? e3 : { default: e3 };
        };
        Object.defineProperty(t2, "__esModule", { value: true });
        const r = n(i(8453));
        let o = null;
        o || (o = (0, r.default)()), t2.default = o;
      }, 8453: function(e2, t2, i) {
        "use strict";
        var n = this && this.__awaiter || function(e3, t3, i2, n2) {
          return new (i2 || (i2 = Promise))((function(r2, o2) {
            function a2(e4) {
              try {
                l2(n2.next(e4));
              } catch (e5) {
                o2(e5);
              }
            }
            function s2(e4) {
              try {
                l2(n2.throw(e4));
              } catch (e5) {
                o2(e5);
              }
            }
            function l2(e4) {
              var t4;
              e4.done ? r2(e4.value) : (t4 = e4.value, t4 instanceof i2 ? t4 : new i2((function(e5) {
                e5(t4);
              }))).then(a2, s2);
            }
            l2((n2 = n2.apply(e3, t3 || [])).next());
          }));
        };
        Object.defineProperty(t2, "__esModule", { value: true });
        const r = i(1167), o = i(7490), a = i(9303), s = i(4070), l = i(9071), d = i(5867), c = i(3433);
        t2.default = function() {
          const e3 = new a.Config();
          let t3 = new s.Log(e3);
          return { init: function(i2) {
            "boolean" == typeof (null == i2 ? void 0 : i2.debug) && e3.set("debug", i2.debug), "boolean" == typeof (null == i2 ? void 0 : i2.dryRun) && e3.set("dryRun", i2.dryRun), (null == i2 ? void 0 : i2.lang) && e3.set("lang", (0, c.normalizeSurveyLang)(i2.lang)), e3.set("url", (null == i2 ? void 0 : i2.env) && "dev" === (null == i2 ? void 0 : i2.env) ? d.HOST_API_URL_DEV : d.HOST_API_URL), e3.set("env", null == i2 ? void 0 : i2.env), t3.log("Initialized Magicfeedback", e3);
          }, send: function(i2, r2, o2, a2 = true, s2, d2) {
            var u;
            return n(this, void 0, void 0, (function* () {
              i2 || t3.err("No appID provided"), r2 || t3.err("No publicKey provided"), o2 || t3.err("No feedback provided"), o2.answers || o2.profile || o2.metrics || o2.metadata || t3.err("No feedback data provided");
              const n2 = e3.get("url"), p = { integration: i2, publicKey: r2, privateKey: d2, completed: a2, id: s2, feedback: o2, lang: null !== (u = (0, c.detectSurveyLang)(e3.get("lang"))) && void 0 !== u ? u : void 0 };
              try {
                if (e3.get("dryRun")) return t3.log("Dry run enabled: skipping native feedback submit"), `dry-run-${Date.now()}`;
                const i3 = yield (0, l.sendFeedback)(n2, p, t3);
                return t3.log("sent native feedback"), i3;
              } catch (e4) {
                return t3.err("error native feedback", e4), false;
              }
            }));
          }, form: function(i2, n2, o2, a2) {
            return i2 || t3.err("No appID provided"), n2 || t3.err("No publicKey provided"), new r.Form(e3, i2, n2, o2, a2);
          }, agentForm: function(i2, n2, r2) {
            return i2 || t3.err("No integrationId provided"), n2 || t3.err("No publicKey provided"), new o.AgentForm(e3, i2, n2, r2);
          }, session: function(i2) {
            return i2 || t3.err("No sessionId provided"), new r.Form(e3, i2);
          }, previewPage: function(i2, o2, a2) {
            return n(this, void 0, void 0, (function* () {
              i2 || t3.err("No selector provided"), o2 && o2.page || t3.err("No page provided for preview");
              const n2 = (null == o2 ? void 0 : o2.appId) || `preview-${Date.now()}`, s2 = new r.Form(e3, n2);
              return yield s2.previewPage(i2, o2, a2), s2;
            }));
          } };
        };
      }, 9481: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.History = void 0, t2.History = class {
          constructor() {
            this.items = [];
          }
          enqueue(e3) {
            this.items.push(e3);
          }
          dequeue() {
            return this.items.shift();
          }
          rollback() {
            return this.items.pop();
          }
          front() {
            return this.items[0];
          }
          back() {
            return this.items[this.items.length - 1];
          }
          isEmpty() {
            return 0 === this.items.length;
          }
          size() {
            return this.items.length;
          }
          get(e3) {
            return this.items[e3];
          }
        };
      }, 7490: function(e2, t2, i) {
        "use strict";
        var n = this && this.__awaiter || function(e3, t3, i2, n2) {
          return new (i2 || (i2 = Promise))((function(r2, o2) {
            function a2(e4) {
              try {
                l2(n2.next(e4));
              } catch (e5) {
                o2(e5);
              }
            }
            function s2(e4) {
              try {
                l2(n2.throw(e4));
              } catch (e5) {
                o2(e5);
              }
            }
            function l2(e4) {
              var t4;
              e4.done ? r2(e4.value) : (t4 = e4.value, t4 instanceof i2 ? t4 : new i2((function(e5) {
                e5(t4);
              }))).then(a2, s2);
            }
            l2((n2 = n2.apply(e3, t3 || [])).next());
          }));
        };
        Object.defineProperty(t2, "__esModule", { value: true }), t2.AgentForm = void 0;
        const r = i(4070), o = i(3501), a = i(4759), s = i(1351), l = i(5349), d = i(2335), c = i(8129), u = i(7643), p = i(7627), m = i(9089), h = i(9039);
        t2.AgentForm = class {
          constructor(e3, t3, i2, n2) {
            this.config = e3, this.log = new r.Log(e3), this.url = e3.get("url"), this.integrationId = t3, this.publicKey = i2, this.privateKey = n2, this.formOptionsConfig = { addButton: true, addSuccessScreen: true, questionFormat: "standard", answerDelimiter: s.DEFAULT_ANSWER_DELIMITER, resume: true, allowBack: false, emptyAnswerText: "" }, this.selector = "", this.language = "en", this.product = { customIcons: false }, this.integrationData = null, this.started = false, this.sessionId = "", this.conversation = [], this.askedRefs = [], this.currentTurn = 1, this.maxTurns = 0, this.currentQuestion = null, this.questionHistory = [], this.busy = false, this.rateLimitTimer = null, this.progress = 0, this.total = 0, this.completed = false, this.timeToCompleted = 0;
          }
          generate(e3, t3 = {}) {
            var i2, r2;
            return n(this, void 0, void 0, (function* () {
              this.formOptionsConfig = Object.assign(Object.assign({}, this.formOptionsConfig), t3), this.selector = e3, t3.lang && (this.language = t3.lang), t3.primaryColor && (this.primaryColor = t3.primaryColor);
              const n2 = false === this.formOptionsConfig.resume || this.isPreview() ? null : this.restore(), o2 = null === (r2 = null === (i2 = this.integrationData) || void 0 === i2 ? void 0 : i2.style) || void 0 === r2 ? void 0 : r2.startMessage;
              if (n2 || !o2) yield this.open(n2);
              else try {
                this.renderWelcome(o2);
              } catch (e4) {
                this.log.err(`Could not show the introduction of ${this.integrationId}:`, e4), this.formOptionsConfig.onLoadedEvent && (yield this.formOptionsConfig.onLoadedEvent({ loading: false, error: e4 }));
              }
            }));
          }
          startForm() {
            return n(this, void 0, void 0, (function* () {
              this.started || (yield this.open(null));
            }));
          }
          renderWelcome(e3) {
            var t3;
            const i2 = (0, d.generateContainer)(this.selector, this.integrationId);
            this.primaryColor && (0, d.applyPrimaryColor)(i2, this.primaryColor), (0, d.applyDirection)(i2, this.language), i2.appendChild((0, u.renderStartMessage)(e3, this.formOptionsConfig.addButton, this.formOptionsConfig.startButtonText || (0, p.t)(this.language, "action.start"), (() => this.startForm()))), this.formOptionsConfig.onLoadedEvent && this.formOptionsConfig.onLoadedEvent({ loading: false, formData: null !== (t3 = this.integrationData) && void 0 !== t3 ? t3 : void 0, lang: this.language });
          }
          open(e3) {
            var t3, i2, r2;
            return n(this, void 0, void 0, (function* () {
              this.started = true;
              try {
                if (e3) this.log.log(`Resuming agent session ${e3.sessionId} at turn ${e3.currentTurn}`), this.mountForm(), this.renderStep();
                else {
                  const e4 = yield this.startWithRetry();
                  this.sessionId = e4.sessionId, this.maxTurns = e4.maxTurns, this.currentTurn = null !== (t3 = e4.currentTurn) && void 0 !== t3 ? t3 : 1, this.total = Math.max(this.maxTurns - 1, 0);
                  const n2 = (0, s.toAgentStep)(e4, this.adapterContext());
                  if (this.mountForm(), "END" === n2.kind) return yield this.renderEnd(n2), void (this.formOptionsConfig.onLoadedEvent && (yield this.formOptionsConfig.onLoadedEvent({ loading: false, progress: this.progress, total: this.total, sessionId: this.sessionId, formData: null !== (i2 = this.integrationData) && void 0 !== i2 ? i2 : void 0, lang: this.language, completed: true })));
                  this.acceptQuestion(n2), this.renderStep(), this.persist();
                }
                this.timeToCompleted = Date.now(), this.formOptionsConfig.onLoadedEvent && (yield this.formOptionsConfig.onLoadedEvent({ loading: false, progress: this.progress, total: this.total, sessionId: this.sessionId, formData: null !== (r2 = this.integrationData) && void 0 !== r2 ? r2 : void 0, lang: this.language, formOptionsConfig: this.formOptionsConfig }));
              } catch (e4) {
                this.log.err(`Could not start the agent survey ${this.integrationId}:`, e4), this.renderFatal(e4), this.formOptionsConfig.onLoadedEvent && (yield this.formOptionsConfig.onLoadedEvent({ loading: false, error: e4 }));
              }
            }));
          }
          next() {
            return n(this, void 0, void 0, (function* () {
              return this.runTurn();
            }));
          }
          answer() {
            const e3 = document.getElementById(this.formId());
            return e3 ? (0, l.scrapeInputs)(e3) : [];
          }
          getConversation() {
            return [...this.conversation];
          }
          getSessionId() {
            return this.sessionId;
          }
          reset() {
            this.sessionId = "", this.conversation = [], this.askedRefs = [], this.currentTurn = 1, this.maxTurns = 0, this.currentQuestion = null, this.questionHistory = [], this.busy = false, this.completed = false, this.progress = 0, this.clearRateLimitTimer(), this.clearPersisted();
          }
          runTurn() {
            var e3;
            return n(this, void 0, void 0, (function* () {
              if (this.busy || this.completed || !this.currentQuestion) return;
              (0, h.cancelAutoAdvance)(document.getElementById(this.questionsId())), this.busy = true, this.setSubmitDisabled(true), this.clearError();
              const t3 = this.currentQuestion;
              try {
                const i2 = document.getElementById(this.formId()), n2 = document.getElementById(this.questionsId());
                if (!i2) throw new Error("Agent form not found");
                yield (0, c.awaitUploadReady)(n2);
                const r2 = (0, l.scrapeInputs)(i2);
                let o2 = (0, s.encodeAnswer)(r2, t3, this.formOptionsConfig.answerDelimiter);
                if ("" === o2) {
                  if (t3.require) return void this.showError(this.formOptionsConfig.requiredMessage || (0, p.t)(this.language, "message.required"));
                  o2 = this.formOptionsConfig.emptyAnswerText || "";
                }
                this.formOptionsConfig.beforeSubmitEvent && (yield this.formOptionsConfig.beforeSubmitEvent({ loading: true, progress: this.progress, total: this.total }));
                const d2 = { role: "user", content: o2, questionType: t3.type, questionRef: t3.ref }, u2 = this.currentTurn + 1, m2 = yield (0, a.nextAgentTurn)(this.url, Object.assign({ publicKey: this.publicKey, privateKey: this.privateKey, integrationId: this.integrationId, sessionId: this.sessionId, conversation: [...this.conversation], currentTurn: u2, lastAnswer: o2, lastQuestionRef: t3.ref, askedRefs: [...this.askedRefs] }, this.previewFlag()), this.log);
                this.conversation.push(d2), this.currentTurn = null !== (e3 = m2.currentTurn) && void 0 !== e3 ? e3 : u2, m2.maxTurns && (this.maxTurns = m2.maxTurns), this.total = Math.max(this.maxTurns - 1, 0);
                const h2 = (0, s.toAgentStep)(m2, this.adapterContext());
                if ("END" === h2.kind) return void (yield this.renderEnd(h2));
                if (this.maxTurns > 0 && this.currentTurn > this.maxTurns + 1) return void (yield this.renderEnd({ kind: "END", reason: "MAX_TURNS", currentTurn: this.currentTurn, maxTurns: this.maxTurns }));
                this.acceptQuestion(h2), this.renderStep(), this.persist(), this.formOptionsConfig.onAgentTurnEvent && (yield this.formOptionsConfig.onAgentTurnEvent({ turn: this.currentTurn, maxTurns: this.maxTurns, question: h2.question, isFromBase: h2.isFromBase, topic: h2.topic, coverageGaps: h2.coverageGaps, coverageSummary: h2.coverageSummary, conversation: this.getConversation() })), this.formOptionsConfig.afterSubmitEvent && (yield this.formOptionsConfig.afterSubmitEvent({ response: this.sessionId, loading: false, progress: this.progress, total: this.total, completed: false, error: null }));
              } catch (e4) {
                yield this.handleTurnError(e4);
              } finally {
                this.completed || (this.busy = false, this.rateLimitTimer || this.setSubmitDisabled(false));
              }
            }));
          }
          handleTurnError(e3) {
            return n(this, void 0, void 0, (function* () {
              this.log.err(`An error occurred during the agent turn ${this.integrationId}:`, e3), e3 instanceof o.AgentApiError && "RATE_LIMITED" === e3.kind ? this.startRateLimitCountdown(e3.retryAfterMs || 6e4) : this.showError(this.errorMessageFor(e3)), this.formOptionsConfig.afterSubmitEvent && (yield this.formOptionsConfig.afterSubmitEvent({ loading: false, progress: this.progress, total: this.total, completed: false, error: e3 }));
            }));
          }
          acceptQuestion(e3) {
            const t3 = e3.question;
            e3.isFromBase && t3.ref && !this.askedRefs.includes(t3.ref) && this.askedRefs.push(t3.ref), this.conversation.push({ role: "agent", content: t3.title, questionType: t3.type, questionRef: t3.ref }), this.currentQuestion = t3, this.questionHistory.push(t3), this.progress = Math.max(this.currentTurn - 1, 0);
          }
          formId() {
            return "magicfeedback-agent-" + this.integrationId;
          }
          questionsId() {
            return "magicfeedback-agent-questions-" + this.integrationId;
          }
          mountForm() {
            const e3 = (0, d.generateContainer)(this.selector, this.integrationId);
            this.primaryColor && (0, d.applyPrimaryColor)(e3, this.primaryColor), (0, d.applyDirection)(e3, this.language);
            const t3 = document.createElement("form");
            t3.classList.add("magicfeedback-form"), t3.classList.add("magicfeedback-agent-form"), t3.id = this.formId(), t3.addEventListener("submit", ((e4) => {
              e4.preventDefault(), this.runTurn();
            }));
            const i2 = document.createElement("div");
            i2.classList.add("magicfeedback-questions"), i2.id = this.questionsId(), t3.appendChild(i2), this.formOptionsConfig.addButton && t3.appendChild((0, u.renderActions)(this.formOptionsConfig.allowBack ? "MAGICSURVEY" : "MAGICFORM", (() => this.back()), this.formOptionsConfig.sendButtonText || (0, p.t)(this.language, "action.send"), this.formOptionsConfig.backButtonText || (0, p.t)(this.language, "action.back"), this.formOptionsConfig.nextButtonText || (0, p.t)(this.language, "action.next"))), e3.appendChild(t3);
          }
          renderStep() {
            const e3 = document.getElementById(this.questionsId());
            e3 && this.currentQuestion && (e3.innerHTML = "", (0, u.renderQuestions)([this.currentQuestion], this.formOptionsConfig.questionFormat, this.language, this.product, (() => this.runTurn())).forEach(((t3) => e3.appendChild(t3))), (0, m.armGhostTapGuard)(e3));
          }
          renderEnd(e3) {
            return n(this, void 0, void 0, (function* () {
              this.completed = true, this.currentQuestion = null, this.busy = false, this.timeToCompleted = this.timeToCompleted ? Date.now() - this.timeToCompleted : 0, this.clearRateLimitTimer(), this.clearPersisted();
              const t3 = document.getElementById("magicfeedback-container-" + this.integrationId);
              if (t3 && false !== this.formOptionsConfig.addSuccessScreen) {
                t3.innerHTML = "";
                const i2 = "BLOCKED" === e3.reason ? this.formOptionsConfig.blockedMessage || (0, p.t)(this.language, "message.blocked") : this.formOptionsConfig.successMessage || (0, p.t)(this.language, "message.success"), n2 = (0, u.renderSuccess)(i2);
                n2.classList.add("magicfeedback-success-message"), n2.classList.add("magicfeedback-agent-end"), "BLOCKED" === e3.reason && n2.classList.add("magicfeedback-agent-end--blocked"), t3.appendChild(n2);
              }
              this.formOptionsConfig.onFinishEvent && (yield this.formOptionsConfig.onFinishEvent({ sessionId: this.sessionId, reason: e3.reason, turns: this.currentTurn, maxTurns: this.maxTurns, conversation: this.getConversation(), coverageSummary: e3.coverageSummary, timeToCompleted: this.timeToCompleted })), this.formOptionsConfig.afterSubmitEvent && (yield this.formOptionsConfig.afterSubmitEvent({ response: this.sessionId, loading: false, progress: this.progress, total: this.total, completed: true, error: null }));
            }));
          }
          back() {
            return n(this, void 0, void 0, (function* () {
              this.busy || this.completed || this.formOptionsConfig.allowBack && (this.questionHistory.length < 2 || (this.questionHistory.pop(), this.conversation.pop(), this.conversation.pop(), this.currentQuestion = this.questionHistory[this.questionHistory.length - 1], this.currentTurn = Math.max(this.currentTurn - 1, 1), this.progress = Math.max(this.currentTurn - 1, 0), this.clearError(), this.renderStep(), this.persist(), this.formOptionsConfig.onBackEvent && (yield this.formOptionsConfig.onBackEvent({ progress: this.progress, total: this.total }))));
            }));
          }
          renderFatal(e3) {
            try {
              (0, d.generateContainer)(this.selector, this.integrationId).appendChild((0, u.renderError)(this.errorMessageFor(e3)));
            } catch (e4) {
            }
          }
          errorMessageFor(e3) {
            if (!(e3 instanceof o.AgentApiError)) return "Something went wrong. Please try again.";
            switch (e3.kind) {
              case "AUTH":
              case "NOT_FOUND":
              case "BAD_CONFIG":
                return "This survey is not available right now.";
              case "AI_UNAVAILABLE":
                return "We couldn't start the survey. Please try again in a moment.";
              default:
                return "Something went wrong. Please try again.";
            }
          }
          adapterContext() {
            return { integrationId: this.integrationId, sessionId: this.sessionId, language: this.language, log: this.log };
          }
          startWithRetry() {
            return n(this, void 0, void 0, (function* () {
              const e3 = Object.assign({ publicKey: this.publicKey, privateKey: this.privateKey, integrationId: this.integrationId }, this.previewFlag());
              try {
                return yield (0, a.startAgentSurvey)(this.url, e3, this.log);
              } catch (t3) {
                if (t3 instanceof o.AgentApiError && "AI_UNAVAILABLE" === t3.kind) return this.log.log("Retrying /start after a transient AI failure"), yield new Promise(((e4) => setTimeout(e4, 1500))), yield (0, a.startAgentSurvey)(this.url, e3, this.log);
                throw t3;
              }
            }));
          }
          setSubmitDisabled(e3) {
            const t3 = document.getElementById("magicfeedback-submit");
            t3 && (t3.disabled = e3);
          }
          clearError() {
            const e3 = document.getElementById(this.questionsId());
            null == e3 || e3.querySelectorAll(".magicfeedback-error").forEach(((e4) => e4.remove()));
          }
          showError(e3) {
            const t3 = document.getElementById(this.questionsId());
            t3 && (this.clearError(), t3.insertBefore((0, u.renderError)(e3), t3.firstChild));
          }
          startRateLimitCountdown(e3) {
            this.clearRateLimitTimer(), this.setSubmitDisabled(true);
            let t3 = Math.ceil(e3 / 1e3);
            const i2 = this.formOptionsConfig.rateLimitMessage || (0, p.t)(this.language, "message.rateLimit"), n2 = () => {
              if (t3 <= 0) return this.clearRateLimitTimer(), this.clearError(), void this.setSubmitDisabled(false);
              this.showError(i2.replace("{seconds}", String(t3))), t3 -= 1;
            };
            n2(), this.rateLimitTimer = setInterval(n2, 1e3);
          }
          clearRateLimitTimer() {
            this.rateLimitTimer && (clearInterval(this.rateLimitTimer), this.rateLimitTimer = null);
          }
          storageKey() {
            return `magicfeedback-agent-${this.integrationId}`;
          }
          isPreview() {
            return Boolean(this.config.get("dryRun"));
          }
          previewFlag() {
            return this.isPreview() ? { preview: true } : {};
          }
          persist() {
            if (!this.isPreview() && false !== this.formOptionsConfig.resume) try {
              const e3 = { sessionId: this.sessionId, conversation: this.conversation, currentTurn: this.currentTurn, maxTurns: this.maxTurns, askedRefs: this.askedRefs, questionHistory: this.questionHistory, savedAt: Date.now() };
              localStorage.setItem(this.storageKey(), JSON.stringify(e3));
            } catch (e3) {
              this.log.log("Could not persist the agent session", e3);
            }
          }
          restore() {
            var e3;
            try {
              const t3 = localStorage.getItem(this.storageKey());
              if (!t3) return null;
              const i2 = JSON.parse(t3);
              return (null == i2 ? void 0 : i2.sessionId) && (null === (e3 = i2.questionHistory) || void 0 === e3 ? void 0 : e3.length) ? Date.now() - (i2.savedAt || 0) > 18e5 ? (this.clearPersisted(), null) : (this.sessionId = i2.sessionId, this.conversation = i2.conversation || [], this.currentTurn = i2.currentTurn || 1, this.maxTurns = i2.maxTurns || 0, this.askedRefs = i2.askedRefs || [], this.questionHistory = i2.questionHistory, this.currentQuestion = this.questionHistory[this.questionHistory.length - 1], this.total = Math.max(this.maxTurns - 1, 0), this.progress = Math.max(this.currentTurn - 1, 0), i2) : null;
            } catch (e4) {
              return this.log.log("Could not restore the agent session", e4), null;
            }
          }
          clearPersisted() {
            try {
              localStorage.removeItem(this.storageKey());
            } catch (e3) {
            }
          }
          applyIntegrationContext(e3) {
            var t3, i2;
            this.integrationData = e3, (null === (t3 = null == e3 ? void 0 : e3.lang) || void 0 === t3 ? void 0 : t3.length) && (this.language = e3.lang[0]), (null == e3 ? void 0 : e3.product) && (this.product = e3.product), (null === (i2 = null == e3 ? void 0 : e3.style) || void 0 === i2 ? void 0 : i2.primaryColor) && (this.primaryColor = e3.style.primaryColor);
          }
        };
      }, 9303: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.Config = void 0, t2.Config = class {
          constructor() {
            this.variables = {}, this.variables.env = "prod", this.variables.debug = false, this.variables.dryRun = false;
          }
          get(e3) {
            return this.variables[e3];
          }
          set(e3, t3) {
            this.variables[e3] = t3;
          }
        };
      }, 1167: function(e2, t2, i) {
        "use strict";
        var n = this && this.__awaiter || function(e3, t3, i2, n2) {
          return new (i2 || (i2 = Promise))((function(r2, o2) {
            function a2(e4) {
              try {
                l2(n2.next(e4));
              } catch (e5) {
                o2(e5);
              }
            }
            function s2(e4) {
              try {
                l2(n2.throw(e4));
              } catch (e5) {
                o2(e5);
              }
            }
            function l2(e4) {
              var t4;
              e4.done ? r2(e4.value) : (t4 = e4.value, t4 instanceof i2 ? t4 : new i2((function(e5) {
                e5(t4);
              }))).then(a2, s2);
            }
            l2((n2 = n2.apply(e3, t3 || [])).next());
          }));
        };
        Object.defineProperty(t2, "__esModule", { value: true }), t2.Form = void 0;
        const r = i(4760), o = i(7490), a = i(4070), s = i(9071), l = i(7643), d = i(8129), c = i(2335), u = i(5349), p = i(1719), m = i(3378), h = i(7305), f = i(9481), g = i(7170), y = i(7627), v = i(3433), b = i(9089), E = i(4069), A = i(9039), k = i(1012), T = [r.FEEDBACKAPPANSWERTYPE.INFO_PAGE, r.FEEDBACKAPPANSWERTYPE.PASSWORD, r.FEEDBACKAPPANSWERTYPE.EMAIL, r.FEEDBACKAPPANSWERTYPE.CONTACT, r.FEEDBACKAPPANSWERTYPE.UPLOAD_FILE, r.FEEDBACKAPPANSWERTYPE.UPLOAD_IMAGE, r.FEEDBACKAPPANSWERTYPE.MAX_DIFF];
        t2.Form = class {
          constructor(e3, t3, i2, n2, r2) {
            this.urlAutoAdvanceChecked = false, this.config = e3, this.log = new a.Log(e3), this.formOptionsConfig = { addButton: true, addSuccessScreen: true, getMetaData: true, customMetaData: [], questionFormat: "standard" }, this.selector = "", this.appId = t3, this.publicKey = i2 || "", this.url = e3.get("url"), this.id = "", this.formData = null, this.activeLang = null, this.feedback = { text: "", answers: [], profile: null != n2 ? n2 : [], metrics: [], metadata: null != r2 ? r2 : [] }, this.history = new f.History(), this.agentForm = null, this.graph = new p.PageGraph([]), this.progress = 0, this.total = 0, this.completed = false, this.sending = false, this.timeToCompleted = 0;
          }
          generate(e3, t3) {
            var i2, r2, a2, l2, d2, c2, u2;
            return n(this, void 0, void 0, (function* () {
              try {
                this.formOptionsConfig = Object.assign(Object.assign({}, this.formOptionsConfig), t3), this.selector = e3;
                let n2 = this.formData;
                const p2 = (0, v.detectSurveyLang)((null == t3 ? void 0 : t3.lang) || this.config.get("lang"));
                if (void 0 !== this.formData && this.formData || (n2 = "" !== this.publicKey ? yield (0, s.getForm)(this.url, this.appId, this.publicKey, this.log, p2) : yield (0, s.getSessionForm)(this.url, this.appId, this.log, p2)), void 0 === n2 || !n2) throw new Error(`No data for app ${this.appId}`);
                if (null === (i2 = n2.error) || void 0 === i2 ? void 0 : i2.message) throw new Error(n2.error.message);
                if ("AGENT" === n2.mode) return this.agentForm = new o.AgentForm(this.config, this.appId, this.publicKey), this.agentForm.applyIntegrationContext(n2), void (yield this.agentForm.generate(e3, t3));
                if (n2.questions = (null === (r2 = n2.questions) || void 0 === r2 ? void 0 : r2.filter(((e4) => "ACTIVE" === e4.status))) || [], n2.pages = (null === (a2 = n2.pages) || void 0 === a2 ? void 0 : a2.filter(((e4) => "ACTIVE" === e4.status))) || [], null === (l2 = n2.pages) || void 0 === l2 || l2.forEach(((e4) => {
                  var t4;
                  return e4.integrationQuestions = null === (t4 = e4.integrationQuestions) || void 0 === t4 ? void 0 : t4.filter(((e5) => "ACTIVE" === e5.status));
                })), this.formData = n2, this.activeLang = this.resolveActiveLang(p2), !this.formData.savedAt) {
                  this.formData.savedAt = /* @__PURE__ */ new Date();
                  try {
                    localStorage.setItem(`magicfeedback-${this.appId}-${this.lang()}`, JSON.stringify(this.formData));
                  } catch (e4) {
                    this.log.log("Could not cache the form data", e4);
                  }
                }
                if (void 0 === this.formData.questions || !this.formData.questions) throw new Error(`No questions for app ${this.appId}`);
                this.formData.pages && 0 !== (null === (d2 = this.formData.pages) || void 0 === d2 ? void 0 : d2.length) || this.formatPages(), null === (c2 = this.formData.questions) || void 0 === c2 || c2.sort(((e4, t4) => e4.position - t4.position)), this.formData.pages = this.formData.pages.filter(((e4) => {
                  var t4;
                  return (null === (t4 = e4.integrationQuestions) || void 0 === t4 ? void 0 : t4.length) > 0;
                })), this.formOptionsConfig.getMetaData && this.getMetaData(), (null === (u2 = this.formData.style) || void 0 === u2 ? void 0 : u2.startMessage) ? yield this.generateWelcomeMessage(this.formData.style.startMessage) : this.generateForm("open");
              } catch (e4) {
                return this.log.err(e4), void (this.formOptionsConfig.onLoadedEvent && (yield this.formOptionsConfig.onLoadedEvent({ loading: false, error: e4 })));
              }
            }));
          }
          previewPage(e3, t3, i2 = {}) {
            var r2, o2, a2, s2, l2, d2, c2, u2, p2;
            return n(this, void 0, void 0, (function* () {
              try {
                if (!t3 || !t3.page) throw new Error("[MagicFeedback] No page provided for preview");
                if (!t3.page.integrationQuestions || 0 === t3.page.integrationQuestions.length) throw new Error("[MagicFeedback] No questions provided for preview");
                this.config.set("dryRun", true), this.formOptionsConfig = Object.assign(Object.assign(Object.assign({}, this.formOptionsConfig), { getMetaData: false }), i2), this.selector = e3;
                const n2 = (t3.page.integrationQuestions || []).filter(((e4) => !e4.status || "ACTIVE" === e4.status)).sort(((e4, t4) => e4.position - t4.position)), h2 = new m.Page(null !== (r2 = t3.page.id) && void 0 !== r2 ? r2 : "1", null !== (o2 = t3.page.position) && void 0 !== o2 ? o2 : 1, null !== (a2 = t3.appId) && void 0 !== a2 ? a2 : this.appId, n2, null !== (s2 = t3.page.integrationPageRoutes) && void 0 !== s2 ? s2 : []);
                this.formData = { id: null !== (l2 = t3.appId) && void 0 !== l2 ? l2 : this.appId, identity: null !== (d2 = t3.identity) && void 0 !== d2 ? d2 : "MAGICFORM", lang: [null !== (c2 = t3.lang) && void 0 !== c2 ? c2 : "en"], product: null !== (u2 = t3.product) && void 0 !== u2 ? u2 : { customIcons: false }, style: null !== (p2 = t3.style) && void 0 !== p2 ? p2 : {}, questions: n2, pages: [h2] }, yield this.generateForm();
              } catch (e4) {
                return this.log.err(e4), void (this.formOptionsConfig.onLoadedEvent && (yield this.formOptionsConfig.onLoadedEvent({ loading: false, error: e4 })));
              }
            }));
          }
          formatPages() {
            var e3;
            if (this.formData) switch (this.formData.identity) {
              case "MAGICSURVEY":
                this.formData.pages = [], null === (e3 = this.formData.questions) || void 0 === e3 || e3.forEach(((e4) => {
                  var t4, i2;
                  const n2 = new h.PageRoute(e4.id, e4.ref, h.OperatorType.NOEQUAL, [], h.TransitionType.PAGE, (e4.position + 1).toString(), e4.position.toString()), r2 = new m.Page(e4.position.toString(), e4.position, this.appId, [e4], [n2]);
                  null === (i2 = null === (t4 = this.formData) || void 0 === t4 ? void 0 : t4.pages) || void 0 === i2 || i2.push(r2);
                }));
                break;
              case "MAGICFORM":
                const t3 = new m.Page("1", 1, this.appId, this.formData.questions, []);
                this.formData.pages = [t3];
            }
          }
          generateContainer() {
            var e3, t3;
            const i2 = (0, c.generateContainer)(this.selector, this.appId), n2 = null === (t3 = null === (e3 = this.formData) || void 0 === e3 ? void 0 : e3.style) || void 0 === t3 ? void 0 : t3.primaryColor;
            return n2 && (0, c.applyPrimaryColor)(i2, n2), (0, c.applyDirection)(i2, this.lang()), i2;
          }
          generateForm(e3 = "open") {
            var t3, i2, r2;
            return n(this, void 0, void 0, (function* () {
              try {
                if (!this.formData || !this.formData.pages || 0 === this.formData.pages.length) throw new Error("No form data");
                this.graph = new p.PageGraph(this.formData.pages.sort(((e4, t4) => e4.position - t4.position)));
                let n2 = this.generateContainer();
                const o2 = document.createElement("form");
                o2.classList.add("magicfeedback-form"), o2.id = "magicfeedback-" + this.appId, o2.addEventListener("submit", ((e4) => e4.preventDefault()));
                const a2 = document.createElement("div");
                a2.classList.add("magicfeedback-questions"), a2.id = "magicfeedback-questions-" + this.appId;
                const s2 = this.graph.getFirstPage();
                if (!s2) throw new Error("No page found");
                if (this.total = this.graph.findMaxDepth(), s2.elements = (0, l.renderQuestions)(s2.questions, this.formOptionsConfig.questionFormat, this.lang(), null === (t3 = this.formData) || void 0 === t3 ? void 0 : t3.product, (() => this.autoSend())), null === (i2 = s2.elements) || void 0 === i2 || i2.forEach(((e4) => a2.appendChild(e4))), o2.appendChild(a2), (0, b.armGhostTapGuard)(a2), this.history.enqueue(s2), n2.appendChild(o2), this.progress = this.total - this.graph.findMaxDepth(s2), this.formOptionsConfig.addButton) {
                  const e4 = (0, l.renderActions)(null === (r2 = this.formData) || void 0 === r2 ? void 0 : r2.identity, (() => this.back()), this.formOptionsConfig.sendButtonText || (0, y.t)(this.lang(), "action.send"), this.formOptionsConfig.backButtonText || (0, y.t)(this.lang(), "action.back"), this.formOptionsConfig.nextButtonText || (0, y.t)(this.lang(), "action.next"));
                  o2.appendChild(e4), this.syncBackButton();
                }
                this.formOptionsConfig.addButton && o2.addEventListener("submit", ((e4) => {
                  e4.preventDefault(), this.send();
                })), this.timeToCompleted = Date.now();
                const d2 = this.autoAdvanceFromUrl(a2, s2);
                if (d2 && (a2.style.visibility = "hidden"), this.formOptionsConfig.onLoadedEvent && (yield this.formOptionsConfig.onLoadedEvent({ loading: d2, autoAdvancing: d2, progress: this.progress, total: this.total, formData: this.formData, lang: this.lang(), formOptionsConfig: this.formOptionsConfig })), d2) return void (yield this.autoSend());
                this.autofocusAfterRender(e3);
              } catch (e4) {
                return this.log.err(e4), void (this.formOptionsConfig.onLoadedEvent && this.formOptionsConfig.onLoadedEvent({ loading: false, error: e4 }));
              }
            }));
          }
          autoAdvanceFromUrl(e3, t3) {
            return !(this.urlAutoAdvanceChecked || (this.urlAutoAdvanceChecked = true, !(0, A.autoAdvanceRequested)() || 1 !== t3.questions.length || !(0, A.answeredInput)(e3, t3.questions[0].ref)));
          }
          startForm() {
            this.agentForm ? this.agentForm.startForm() : this.generateForm("navigation");
          }
          focusFirstQuestion() {
            return "undefined" != typeof document && (0, E.focusFirstTextQuestion)(document.getElementById("magicfeedback-questions-" + this.appId));
          }
          autofocusAfterRender(e3) {
            const t3 = this.formOptionsConfig.autofocus;
            t3 && ("open" === e3 && "always" !== t3 || this.focusFirstQuestion());
          }
          lang() {
            var e3;
            return this.activeLang || (null === (e3 = this.formData) || void 0 === e3 ? void 0 : e3.lang) && this.formData.lang[0] || "en";
          }
          getLang() {
            return this.lang();
          }
          resolveActiveLang(e3) {
            var t3, i2;
            const n2 = (null === (t3 = this.formData) || void 0 === t3 ? void 0 : t3.lang) || [];
            return (null === (i2 = this.formData) || void 0 === i2 ? void 0 : i2.servedLang) ? this.formData.servedLang : e3 && n2.includes(e3) ? e3 : n2[0] || null;
          }
          generateWelcomeMessage(e3) {
            return n(this, void 0, void 0, (function* () {
              try {
                const t3 = this.generateContainer(), i2 = (0, l.renderStartMessage)(e3, this.formOptionsConfig.addButton, this.formOptionsConfig.startButtonText || (0, y.t)(this.lang(), "action.start"), (() => this.startForm()));
                t3.appendChild(i2), this.formOptionsConfig.onLoadedEvent && (yield this.formOptionsConfig.onLoadedEvent({ loading: false, formData: this.formData, lang: this.lang() }));
              } catch (e4) {
                return this.log.err(e4), void (this.formOptionsConfig.onLoadedEvent && this.formOptionsConfig.onLoadedEvent({ loading: false, error: e4 }));
              }
            }));
          }
          getMetaData() {
            this.formOptionsConfig.customMetaData && (this.feedback.metadata = [...this.feedback.metadata, ...this.formOptionsConfig.customMetaData]), this.feedback.metadata.push({ key: "navigator-url", value: [window.location.href] }), this.feedback.metadata.push({ key: "navigator-origin", value: [window.location.origin] }), this.feedback.metadata.push({ key: "navigator-pathname", value: [window.location.pathname] }), this.feedback.metadata.push({ key: "navigator-search", value: [window.location.search] });
            const e3 = new URLSearchParams(window.location.search);
            Array.from(new Set(e3.keys())).forEach(((t3) => {
              const i2 = e3.getAll(t3);
              i2.length > 0 && this.feedback.metadata.push({ key: `query-${t3}`, value: i2 });
            })), this.feedback.metadata.push({ key: "navigator-user", value: [navigator.userAgent] }), this.feedback.metadata.push({ key: "navigator-language", value: [navigator.language] }), this.feedback.metadata.push({ key: "navigator-platform", value: [navigator.platform] }), this.feedback.metadata.push({ key: "navigator-appVersion", value: [navigator.appVersion] }), this.feedback.metadata.push({ key: "navigator-appName", value: [navigator.appName] }), this.feedback.metadata.push({ key: "navigator-product", value: [navigator.product] }), this.feedback.metadata.push({ key: "screen-width", value: [window.screen.width.toString()] }), this.feedback.metadata.push({ key: "screen-height", value: [window.screen.height.toString()] }), this.appId && "" === this.publicKey && this.feedback.metadata.push({ key: "MAGICFEEDBACK_SESSION", value: [this.appId] });
          }
          send(e3, t3, i2, o2) {
            var a2, s2;
            return n(this, void 0, void 0, (function* () {
              if (this.agentForm) return this.agentForm.next();
              const n2 = document.getElementById("magicfeedback-questions-" + this.appId);
              (0, A.cancelAutoAdvance)(n2), this.sending = true;
              try {
                if (i2 && (this.feedback.profile = [...this.feedback.profile, ...i2]), t3 && (this.feedback.metrics = [...this.feedback.metrics, ...t3]), e3 && (this.feedback.metadata = [...this.feedback.metadata, ...e3]), o2) {
                  this.feedback.answers = [...this.feedback.answers, ...o2], this.formOptionsConfig.beforeSubmitEvent && (yield this.formOptionsConfig.beforeSubmitEvent({ loading: true, progress: this.progress, total: this.total }));
                  const e4 = yield this.pushAnswers(false);
                  if (!e4) throw new k.SubmitError("SEND_FAILED", "No response");
                  return this.id = e4, void (this.formOptionsConfig.afterSubmitEvent && (yield this.formOptionsConfig.afterSubmitEvent({ loading: false, progress: this.progress, total: this.total })));
                }
                yield (0, d.awaitUploadReady)(n2), this.answer(), this.formOptionsConfig.beforeSubmitEvent && (yield this.formOptionsConfig.beforeSubmitEvent({ loading: true, progress: this.progress, total: this.total }));
                const l2 = this.history.back();
                if (!l2) throw new k.SubmitError("NO_PAGE", "No page found");
                for (const e4 of l2.questions.filter(((e5) => e5.require && ![r.FEEDBACKAPPANSWERTYPE.CONSENT, r.FEEDBACKAPPANSWERTYPE.INFO_PAGE].includes(e5.type)))) {
                  const t4 = e4.assets, i3 = this.feedback.answers.filter(((t5) => t5.key.includes(e4.ref) && !t5.key.includes("extra-option")));
                  if (0 === i3.length || i3.find(((e5) => 0 === e5.value.length))) throw this.log.err(`The question ${e4.ref} is required`), new k.SubmitError("REQUIRED", "No response");
                  if (null == t4 ? void 0 : t4.minOptions) {
                    let n3 = [];
                    if ((null == t4 ? void 0 : t4.exclusiveAnswers) && (n3 = null == t4 ? void 0 : t4.exclusiveAnswers), !i3[0].value.find(((e5) => n3.includes(e5))) && i3[0].value.length < (null == t4 ? void 0 : t4.minOptions)) throw this.log.err(`The question ${e4.ref} requires at least ${null == t4 ? void 0 : t4.minOptions} options`), new k.SubmitError("REQUIRED", "No response");
                  }
                  if (e4.type === r.FEEDBACKAPPANSWERTYPE.MAX_DIFF) {
                    const t5 = null !== (s2 = null === (a2 = e4.assets) || void 0 === a2 ? void 0 : a2.setIndex) && void 0 !== s2 ? s2 : 1, i4 = this.parseMaxDiffAnswer(this.feedback.answers.find(((t6) => t6.key === e4.ref))).find(((e5) => e5.set === t5));
                    if (!(null == i4 ? void 0 : i4.best) || !(null == i4 ? void 0 : i4.worst)) throw this.log.err(`The MaxDiff question ${e4.ref} requires the most and the least important`), new k.SubmitError("REQUIRED", "No response");
                  }
                  if (e4.type === r.FEEDBACKAPPANSWERTYPE.MULTI_QUESTION_MATRIX) {
                    const i4 = this.feedback.answers.find(((t5) => t5.key === e4.ref));
                    if (!i4) throw this.log.err(`The matrix question ${e4.ref} is required`), new k.SubmitError("REQUIRED", "No response");
                    const n3 = this.parseMatrixAnswerPre(i4), r2 = Array.isArray(null == t4 ? void 0 : t4.options) ? t4.options : [];
                    if (r2.length > 0) {
                      if (r2.find(((e5) => {
                        const t5 = n3.find(((t6) => t6.key === e5));
                        return !t5 || !Array.isArray(t5.value) || 0 === t5.value.length;
                      }))) throw this.log.err(`The matrix question ${e4.ref} requires an answer in every row`), new k.SubmitError("REQUIRED", "No response");
                    } else if (0 === n3.length || n3.some(((e5) => !Array.isArray(e5.value) || 0 === e5.value.length))) throw this.log.err(`The matrix question ${e4.ref} requires an answer in every row`), new k.SubmitError("REQUIRED", "No response");
                  }
                }
                const c2 = yield this.pushAnswers(false);
                if (!c2) throw new k.SubmitError("SEND_FAILED", "No response");
                this.id = c2, yield this.processNextQuestion(n2);
              } catch (e4) {
                this.log.err(`An error occurred while submitting the form ${this.appId}:`, e4), this.formOptionsConfig.afterSubmitEvent && (yield this.formOptionsConfig.afterSubmitEvent({ loading: false, progress: this.progress, total: this.total, error: e4 }));
              } finally {
                this.sending = false, null == n2 || n2.style.removeProperty("visibility");
              }
            }));
          }
          autoSend() {
            if (!this.sending) return this.send();
          }
          answer() {
            const e3 = "magicfeedback-" + this.appId, t3 = document.getElementById(e3);
            if (!t3) return this.log.err(`Form "${e3}" not found.`), this.feedback.answers = [], [];
            const i2 = this.history.back();
            if (!i2) return this.feedback.answers = (0, u.scrapeInputs)(t3), this.feedback.answers;
            const n2 = [];
            let o2 = false;
            const a2 = t3.querySelectorAll(".magicfeedback-input"), l2 = {}, c2 = {}, p2 = {}, m2 = {};
            if (a2.forEach(((e4) => {
              var t4, a3;
              const u2 = e4, h3 = i2.questions.find(((e5) => {
                var t5;
                return null === (t5 = u2.name) || void 0 === t5 ? void 0 : t5.includes(e5.ref);
              })), f2 = u2.type, g2 = u2.classList[0], y2 = { key: u2.name, value: [] }, v2 = "magicfeedback-consent" === g2 ? u2.checked.toString() : u2.value;
              if (y2.key && "" !== y2.key) if (y2.key.startsWith("extra-option-")) "" !== v2 && (y2.value.push(v2), n2.push(y2));
              else switch (null == h3 ? void 0 : h3.type) {
                case r.FEEDBACKAPPANSWERTYPE.EMAIL:
                case r.FEEDBACKAPPANSWERTYPE.TEXT:
                case r.FEEDBACKAPPANSWERTYPE.LONGTEXT:
                case r.FEEDBACKAPPANSWERTYPE.NUMBER:
                case r.FEEDBACKAPPANSWERTYPE.DATE:
                case r.FEEDBACKAPPANSWERTYPE.CONTACT:
                case r.FEEDBACKAPPANSWERTYPE.PASSWORD:
                  "" !== v2 && ("email" === f2 ? (0, s.validateEmail)(v2) ? (this.feedback.profile.push({ key: "email", value: [v2] }), y2.value.push(v2), n2.push(y2)) : (this.log.err("Invalid email"), o2 = true) : (y2.value.push(v2), n2.push(y2)));
                  break;
                case r.FEEDBACKAPPANSWERTYPE.RADIO:
                  u2.checked && (y2.value.push(v2), n2.push(y2));
                  break;
                case r.FEEDBACKAPPANSWERTYPE.MULTIPLECHOICE:
                case r.FEEDBACKAPPANSWERTYPE.MULTIPLECHOISE_IMAGE:
                  u2.checked && (c2[y2.key] || (c2[y2.key] = []), c2[y2.key].push(v2));
                  break;
                case r.FEEDBACKAPPANSWERTYPE.BOOLEAN:
                  u2.checked && (y2.value.push(v2), n2.push(y2));
                  break;
                case r.FEEDBACKAPPANSWERTYPE.CONSENT:
                  y2.value.push(u2.checked.toString()), n2.push(y2);
                  break;
                case r.FEEDBACKAPPANSWERTYPE.RATING_EMOJI:
                case r.FEEDBACKAPPANSWERTYPE.RATING_NUMBER:
                case r.FEEDBACKAPPANSWERTYPE.RATING_STAR:
                  u2.checked && (y2.value.push(v2), n2.push(y2));
                  break;
                case r.FEEDBACKAPPANSWERTYPE.SELECT:
                  "" !== v2 && (y2.value.push(v2), n2.push(y2));
                  break;
                case r.FEEDBACKAPPANSWERTYPE.POINT_SYSTEM:
                  "number" === f2 && u2.id && (p2[y2.key] || (p2[y2.key] = []), "" !== v2 && p2[y2.key].push(`${u2.id}:${v2}%`));
                  break;
                case r.FEEDBACKAPPANSWERTYPE.PRIORITY_LIST:
                  "hidden" === f2 && (l2[y2.key] || (l2[y2.key] = []), l2[y2.key].push(v2));
                  break;
                case r.FEEDBACKAPPANSWERTYPE.MULTI_QUESTION_MATRIX:
                  e4.checked && (y2.value.push(v2), n2.push(y2));
                  break;
                case r.FEEDBACKAPPANSWERTYPE.MAX_DIFF: {
                  if ("radio" !== f2 || !h3) break;
                  const e5 = y2.key === `${h3.ref}-best` ? "best" : y2.key === `${h3.ref}-worst` ? "worst" : null;
                  if (!e5) break;
                  m2[h3.ref] || (m2[h3.ref] = { set: null !== (a3 = null === (t4 = h3.assets) || void 0 === t4 ? void 0 : t4.setIndex) && void 0 !== a3 ? a3 : 1, shown: [], best: null, worst: null });
                  const i3 = m2[h3.ref];
                  "best" === e5 && i3.shown.push(v2), u2.checked && (i3[e5] = v2);
                  break;
                }
                case r.FEEDBACKAPPANSWERTYPE.UPLOAD_IMAGE:
                case r.FEEDBACKAPPANSWERTYPE.UPLOAD_FILE: {
                  const e5 = (0, d.getUploadValues)(u2);
                  e5.length && (y2.value.push(...e5), n2.push(y2));
                  break;
                }
              }
            })), o2) return [];
            Object.entries(c2).forEach((([e4, t4]) => {
              t4 && 0 !== t4.length && n2.push({ key: e4, value: t4 });
            })), Object.entries(p2).forEach((([e4, t4]) => {
              t4 && 0 !== t4.length && n2.push({ key: e4, value: t4 });
            })), Object.entries(l2).forEach((([e4, t4]) => {
              if (!t4 || 0 === t4.length) return;
              const i3 = t4.slice().sort(((e5, t5) => Number(e5.split(".")[0]) - Number(t5.split(".")[0])));
              n2.push({ key: e4, value: i3 });
            })), Object.entries(m2).forEach((([e4, t4]) => {
              (t4.best || t4.worst) && n2.push({ key: e4, value: [JSON.stringify([t4])] });
            }));
            try {
              i2.questions.filter(((e4) => e4.type === r.FEEDBACKAPPANSWERTYPE.MULTI_QUESTION_MATRIX)).forEach(((e4) => {
                const t4 = e4.ref + "-", i3 = n2.filter(((e5) => e5.key.startsWith(t4)));
                if (0 === i3.length) return;
                const r2 = i3.map(((e5) => ({ key: e5.key.substring(t4.length), value: e5.value }))), o3 = { key: e4.ref, value: [JSON.stringify(r2)] };
                for (const e5 of i3) {
                  const t5 = n2.findIndex(((t6) => t6.key === e5.key));
                  -1 !== t5 && n2.splice(t5, 1);
                }
                const a3 = n2.findIndex(((t5) => t5.key === e4.ref));
                -1 !== a3 ? n2[a3] = o3 : n2.push(o3);
              }));
            } catch (e4) {
              this.log.err("Error agrupando MULTI_QUESTION_MATRIX", e4);
            }
            const h2 = this.withEarlierMaxDiffSets((0, v.toBaseAnswers)(n2, i2.questions), i2.questions);
            return this.feedback.answers = h2, i2.setAnswer(h2), h2;
          }
          withEarlierMaxDiffSets(e3, t3) {
            return e3.map(((e4) => {
              if (!t3.some(((t4) => t4.ref === e4.key && t4.type === r.FEEDBACKAPPANSWERTYPE.MAX_DIFF))) return e4;
              const i2 = this.parseMaxDiffAnswer(e4), n2 = [...this.parseMaxDiffAnswer(this.earlierAnswer(e4.key)).filter(((e5) => !i2.some(((t4) => t4.set === e5.set)))), ...i2].sort(((e5, t4) => e5.set - t4.set));
              return Object.assign(Object.assign({}, e4), { value: [JSON.stringify(n2)] });
            }));
          }
          earlierAnswer(e3) {
            var t3, i2;
            for (let n2 = this.history.size() - 2; n2 >= 0; n2--) {
              const r2 = null === (i2 = null === (t3 = this.history.get(n2)) || void 0 === t3 ? void 0 : t3.answers) || void 0 === i2 ? void 0 : i2.find(((t4) => t4.key === e3));
              if (r2) return r2;
            }
          }
          finish() {
            return n(this, void 0, void 0, (function* () {
              if (this.completed = true, this.timeToCompleted = Date.now() - this.timeToCompleted, this.feedback.metadata.push({ key: "time-to-complete", value: [this.timeToCompleted.toString()] }), this.formOptionsConfig.addSuccessScreen) {
                const e3 = document.getElementById("magicfeedback-container-" + this.appId);
                e3.childNodes.length > 0 && e3.removeChild(e3.childNodes[0]);
                const t3 = (0, l.renderSuccess)(this.formOptionsConfig.successMessage || (0, y.t)(this.lang(), "message.success"));
                e3.appendChild(t3);
              }
              this.feedback.answers = [];
              try {
                const e3 = yield this.pushAnswers(true);
                if (!e3) {
                  const e4 = new k.SubmitError("SEND_FAILED", `An error occurred while submitting the form ${this.appId}:`);
                  throw this.formOptionsConfig.afterSubmitEvent && (yield this.formOptionsConfig.afterSubmitEvent({ loading: false, progress: this.progress, total: this.total, completed: this.completed, error: e4 })), e4;
                }
                this.id = e3, this.formOptionsConfig.afterSubmitEvent && (yield this.formOptionsConfig.afterSubmitEvent({ response: this.id, loading: false, progress: this.progress, total: this.total, completed: this.completed, error: null }));
              } catch (e3) {
                this.log.err(`An error occurred while submitting the form ${this.appId}:`, e3), this.formOptionsConfig.afterSubmitEvent && (yield this.formOptionsConfig.afterSubmitEvent({ loading: false, progress: this.progress, total: this.total, completed: this.completed, error: e3 }));
              }
            }));
          }
          pushAnswers(e3 = false) {
            return n(this, void 0, void 0, (function* () {
              try {
                if (this.config.get("dryRun")) {
                  const e4 = this.id || `dry-run-${this.appId}-${Date.now()}`;
                  return this.log.log(`Dry run enabled: skipping feedback submit for form ${this.appId}`), e4;
                }
                const t3 = this.config.get("url"), i2 = { integration: this.appId, publicKey: this.publicKey, feedback: this.feedback, completed: e3, lang: this.lang() };
                return yield (0, s.sendFeedback)(t3, this.id ? Object.assign(Object.assign({}, i2), { sessionId: this.id }) : i2, this.log);
              } catch (e4) {
                return this.log.err(`An error occurred while submitting the form ${this.appId}:`, e4), "";
              }
            }));
          }
          callFollowUpQuestion(e3) {
            var t3, i2;
            return n(this, void 0, void 0, (function* () {
              if (!(null == e3 ? void 0 : e3.followup)) return null;
              const n2 = null !== (t3 = this.feedback.answers.find(((t4) => t4.key === e3.ref))) && void 0 !== t3 ? t3 : this.feedback.answers.find(((t4) => t4.key.includes(e3.ref) && !t4.key.includes("extra-option"))), r2 = null === (i2 = null == n2 ? void 0 : n2.value) || void 0 === i2 ? void 0 : i2.find(((e4) => null != e4 && "" !== e4));
              if (void 0 === r2) return this.log.log(`The question ${e3.ref} has no answer, skipping its follow up`), null;
              try {
                const t4 = this.config.get("url"), i3 = Object.assign(Object.assign(Object.assign({ answer: r2 }, "" !== this.publicKey && { publicKey: this.publicKey }), "" === this.publicKey && { campaignSessionId: this.appId }), { sessionId: this.id, question: e3, previousAnswers: this.previousAnswers(e3), upcomingQuestions: this.upcomingQuestions() });
                return yield (0, s.getFollowUpQuestion)(t4, i3, this.log);
              } catch (t4) {
                return this.log.err(`An error occurred while requesting the follow up of ${e3.ref} in the form ${this.appId}:`, t4), null;
              }
            }));
          }
          previousAnswers(e3) {
            var t3;
            const i2 = /* @__PURE__ */ new Map();
            for (let n2 = 0; n2 < this.history.size(); n2++) {
              const r2 = this.history.get(n2);
              if (r2) for (const n3 of r2.questions) {
                if (n3.ref === e3.ref) continue;
                if (T.includes(n3.type)) continue;
                const o2 = this.followUpAnswerValue(n3, null === (t3 = r2.answers) || void 0 === t3 ? void 0 : t3.find(((e4) => e4.key === n3.ref)));
                void 0 !== o2 && (i2.delete(n3.ref), i2.set(n3.ref, { title: n3.title, answer: o2 }));
              }
            }
            return [...i2.values()];
          }
          followUpAnswerValue(e3, t3) {
            var i2;
            const n2 = (null !== (i2 = null == t3 ? void 0 : t3.value) && void 0 !== i2 ? i2 : []).filter(((e4) => null != e4 && "" !== e4));
            if (0 === n2.length) return;
            if (e3.type === r.FEEDBACKAPPANSWERTYPE.BOOLEAN && 1 === n2.length && ["Yes", "No"].includes(n2[0])) return "Yes" === n2[0];
            if (e3.type === r.FEEDBACKAPPANSWERTYPE.MULTI_QUESTION_MATRIX) {
              const t4 = this.parseMatrixAnswerPre({ key: e3.ref, value: n2 }).map(((e4) => `${e4.key}: ${(Array.isArray(e4.value) ? e4.value : [e4.value]).join(", ")}`));
              return t4.length > 0 ? t4 : void 0;
            }
            const o2 = n2.map(((e4) => "string" == typeof e4 ? e4 : JSON.stringify(e4)));
            return 1 === o2.length ? o2[0] : o2;
          }
          upcomingQuestions() {
            var e3, t3;
            const i2 = this.history.back();
            if (!i2) return [];
            const n2 = [], o2 = /* @__PURE__ */ new Set(), a2 = /* @__PURE__ */ new Set();
            let s2 = i2.isFollowup && i2.origin ? i2.origin : i2, l2 = null !== (e3 = s2.answers) && void 0 !== e3 ? e3 : [];
            for (; !a2.has(s2.id); ) {
              let e4;
              if (a2.add(s2.id), l2) {
                const i4 = this.graph.findRoute(s2, l2);
                e4 = i4 ? i4.transition === h.TransitionType.PAGE && null !== (t3 = i4.transitionDestiny) && void 0 !== t3 ? t3 : void 0 : this.graph.getNextEdgeByDefault(s2);
              } else {
                if (s2.edges.some(((e5) => e5.typeCondition !== h.ConditionType.DIRECT && e5.typeCondition !== h.ConditionType.PRECONDITIONAL))) break;
                e4 = this.graph.getNextEdgeByDefault(s2);
              }
              const i3 = e4 ? this.graph.getNodeById(e4) : void 0;
              if (!i3) break;
              if (i3.edges.filter(((e5) => e5.typeCondition === h.ConditionType.PRECONDITIONAL)).some(((e5) => !this.latestAnswer(e5.questionRef)))) break;
              if (this.skipsByPreconditions(i3)) s2 = i3, l2 = [];
              else {
                for (const e5 of i3.questions) e5.type !== r.FEEDBACKAPPANSWERTYPE.INFO_PAGE && (o2.has(e5.ref) || (o2.add(e5.ref), n2.push({ title: e5.title })));
                s2 = i3, l2 = null;
              }
            }
            return n2;
          }
          processNextQuestion(e3) {
            var t3, i2;
            return n(this, void 0, void 0, (function* () {
              const n2 = this.history.back();
              if (!n2) throw new k.SubmitError("NO_PAGE", "No page found");
              const r2 = n2.isFollowup ? [] : n2.getFollowupQuestions();
              if (0 === (null == r2 ? void 0 : r2.length)) return void (yield this.renderNextQuestion(e3, n2));
              const o2 = [];
              for (const e4 of r2) {
                const t4 = n2.questions.find(((t5) => t5.ref === e4));
                if (t4) {
                  const e5 = yield this.callFollowUpQuestion(t4);
                  e5 && o2.push(e5);
                }
              }
              if (0 === o2.length) return void (yield this.renderNextQuestion(e3, n2));
              const a2 = new m.Page(n2.id, n2.position, this.appId, o2, n2.edges), s2 = new g.PageNode(n2.id, n2.position, n2.edges, a2, o2, true);
              s2.origin = n2.isFollowup && n2.origin ? n2.origin : n2, s2.elements = (0, l.renderQuestions)(o2, this.formOptionsConfig.questionFormat, this.lang(), null === (t3 = this.formData) || void 0 === t3 ? void 0 : t3.product, (() => this.autoSend())), this.history.enqueue(s2), this.syncBackButton(), this.progress += 0.5, e3.innerHTML = "", null === (i2 = s2.elements) || void 0 === i2 || i2.forEach(((t4) => e3.appendChild(t4))), (0, b.armGhostTapGuard)(e3), this.formOptionsConfig.afterSubmitEvent && (yield this.formOptionsConfig.afterSubmitEvent({ response: this.id, loading: false, progress: this.progress, total: this.total, followup: s2.isFollowup, completed: this.completed, error: null })), this.autofocusAfterRender("navigation");
            }));
          }
          renderNextQuestion(e3, t3) {
            var i2, r2, o2;
            return n(this, void 0, void 0, (function* () {
              const n2 = t3.isFollowup && t3.origin ? t3.origin : t3, a2 = n2 === t3 ? this.feedback.answers : [...null !== (i2 = n2.answers) && void 0 !== i2 ? i2 : [], ...this.feedback.answers];
              let s2 = this.graph.getNextPage(n2, a2);
              if (s2) {
                if (this.skipsByPreconditions(s2)) return this.feedback.answers = [], void (yield this.renderNextQuestion(e3, s2));
                s2.elements = (0, l.renderQuestions)(s2.questions, this.formOptionsConfig.questionFormat, this.lang(), null === (r2 = this.formData) || void 0 === r2 ? void 0 : r2.product, (() => this.autoSend())), e3.innerHTML = "", null === (o2 = s2.elements) || void 0 === o2 || o2.forEach(((t4) => e3.appendChild(t4))), (0, b.armGhostTapGuard)(e3), this.history.enqueue(s2), this.syncBackButton(), this.progress = this.total - this.graph.findMaxDepth(s2), this.formOptionsConfig.afterSubmitEvent && (yield this.formOptionsConfig.afterSubmitEvent({ response: this.id, loading: false, progress: this.progress, total: this.total, followup: s2.isFollowup, completed: this.completed, error: null })), this.autofocusAfterRender("navigation");
              } else this.finish();
            }));
          }
          skipsByPreconditions(e3) {
            var t3;
            const i2 = e3.edges.filter(((e4) => "PRECONDITIONAL" === e4.typeCondition)).sort(((e4, t4) => e4.position < t4.position ? -1 : e4.position > t4.position ? 1 : 0));
            if (0 === i2.length) return false;
            const n2 = i2.some(((e4) => e4.transition === h.TransitionType.ALLOW));
            let o2 = n2;
            for (const e4 of i2) {
              const i3 = this.latestAnswer(e4.questionRef);
              let n3 = false;
              if (i3) {
                const o3 = null === (t3 = this.formData) || void 0 === t3 ? void 0 : t3.questions.find(((t4) => t4.ref === e4.questionRef)), a2 = Array.isArray(i3.value) ? i3.value : [i3.value], s2 = Array.isArray(e4.value) ? e4.value : [e4.value];
                if ((null == o3 ? void 0 : o3.type) === r.FEEDBACKAPPANSWERTYPE.MULTI_QUESTION_MATRIX) n3 = this.evaluateMatrixPreconditional(e4, i3);
                else switch (e4.typeOperator) {
                  case "EQUAL":
                  case "INQ":
                    n3 = a2.some(((e5) => s2.includes(e5)));
                    break;
                  case "NOEQUAL":
                  case "NINQ":
                    n3 = a2.every(((e5) => !s2.includes(e5)));
                    break;
                  case "GREATER":
                    n3 = a2.some(((e5) => Number(e5) > Number(s2[0])));
                    break;
                  case "LESS":
                    n3 = a2.some(((e5) => Number(e5) < Number(s2[0])));
                    break;
                  case "GREATEREQUAL":
                    n3 = a2.some(((e5) => Number(e5) >= Number(s2[0])));
                    break;
                  case "LESSEQUAL":
                    n3 = a2.some(((e5) => Number(e5) <= Number(s2[0])));
                }
              }
              if (e4.transition === h.TransitionType.ALLOW) n3 || (o2 = false);
              else if (e4.transition === h.TransitionType.NEXT && n3) return true;
            }
            return !!n2 && !o2;
          }
          latestAnswer(e3) {
            var t3, i2;
            for (let n2 = this.history.size() - 1; n2 >= 0; n2--) {
              const r2 = null === (i2 = null === (t3 = this.history.get(n2)) || void 0 === t3 ? void 0 : t3.answers) || void 0 === i2 ? void 0 : i2.find(((t4) => t4.key === e3));
              if (r2) return r2;
            }
          }
          syncBackButton() {
            const e3 = document.getElementById("magicfeedback-" + this.appId), t3 = null == e3 ? void 0 : e3.querySelector(".magicfeedback-back");
            t3 && (t3.hidden = this.history.size() <= 1);
          }
          back() {
            var e3;
            return n(this, void 0, void 0, (function* () {
              if (this.history.size() <= 1) return;
              const t3 = document.getElementById("magicfeedback-questions-" + this.appId);
              (0, A.cancelAutoAdvance)(t3), t3 && t3.childNodes.length > 0 && (t3.innerHTML = ""), this.history.rollback(), this.syncBackButton();
              const i2 = this.history.back();
              i2 ? (null === (e3 = i2.elements) || void 0 === e3 || e3.forEach(((e4) => t3.appendChild(e4))), (0, b.armGhostTapGuard)(t3), this.progress = this.total - this.graph.findMaxDepth(i2)) : this.progress = this.history.size(), this.formOptionsConfig.onBackEvent && (yield this.formOptionsConfig.onBackEvent({ loading: false, progress: this.progress, followup: (null == i2 ? void 0 : i2.isFollowup) || false, error: i2 ? null : "No page found" })), i2 && this.autofocusAfterRender("navigation");
            }));
          }
          previewQuestion(e3, t3, i2) {
            var n2, r2;
            const o2 = Array.isArray(t3) ? t3 : [t3];
            if (!o2 || 0 === o2.length) throw new Error("[MagicFeedback] No question provided for preview");
            const a2 = document.getElementById(e3);
            if (!a2) throw new Error(`[MagicFeedback] Element with ID '${e3}' not found.`);
            const { format: s2 = this.formOptionsConfig.questionFormat || "standard", language: d2 = this.lang(), product: u2 = (null === (n2 = this.formData) || void 0 === n2 ? void 0 : n2.product) || { customIcons: false }, style: p2 = (null === (r2 = this.formData) || void 0 === r2 ? void 0 : r2.style) || {}, clearContainer: m2 = true, wrap: h2 = true } = i2 || {};
            m2 && (a2.innerHTML = ""), (null == p2 ? void 0 : p2.primaryColor) && (0, c.applyPrimaryColor)(a2, p2.primaryColor), (0, c.applyDirection)(a2, d2);
            let f2 = [];
            try {
              f2 = (0, l.renderQuestions)(o2, s2, d2, u2);
            } catch (e4) {
              throw this.log.err(e4), e4;
            }
            let g2 = a2;
            if (h2) {
              const e4 = document.createElement("div");
              e4.classList.add("magicfeedback-preview-question"), g2.appendChild(e4), g2 = e4;
            }
            return f2.forEach(((e4) => g2.appendChild(e4))), a2;
          }
          parseMaxDiffAnswer(e3) {
            var t3;
            if (!e3 || "string" != typeof (null === (t3 = e3.value) || void 0 === t3 ? void 0 : t3[0])) return [];
            try {
              const t4 = JSON.parse(e3.value[0]);
              return Array.isArray(t4) ? t4 : [];
            } catch (e4) {
              return [];
            }
          }
          parseMatrixAnswerPre(e3) {
            if (!e3 || !e3.value) return [];
            if (1 === e3.value.length && "string" == typeof e3.value[0] && e3.value[0].trim().startsWith("[")) try {
              const t3 = JSON.parse(e3.value[0]);
              if (Array.isArray(t3)) return t3;
            } catch (e4) {
              return [];
            }
            return Array.isArray(e3.value) && e3.value.length > 0 && "object" == typeof e3.value[0] && null !== e3.value[0] && "key" in e3.value[0] ? e3.value : [];
          }
          evaluateMatrixPreconditional(e3, t3) {
            const i2 = Array.isArray(e3.value) ? e3.value : [e3.value], n2 = new Set(e3.option || []), r2 = this.parseMatrixAnswerPre(t3);
            if (!r2.length) return false;
            const o2 = n2.size > 0 ? r2.filter(((e4) => n2.has(e4.key))) : r2;
            if (!o2.length) return false;
            switch (e3.typeOperator) {
              case "EQUAL":
              case "INQ":
                return o2.some(((e4) => (Array.isArray(e4.value) ? e4.value : [e4.value]).some(((e5) => i2.includes(e5)))));
              case "NOEQUAL":
              case "NINQ":
                return o2.every(((e4) => (Array.isArray(e4.value) ? e4.value : [e4.value]).every(((e5) => !i2.includes(e5)))));
              case "GREATER":
                return o2.some(((e4) => (Array.isArray(e4.value) ? e4.value : [e4.value]).some(((e5) => i2.some(((t4) => Number(e5) > Number(t4)))))));
              case "LESS":
                return o2.some(((e4) => (Array.isArray(e4.value) ? e4.value : [e4.value]).some(((e5) => i2.some(((t4) => Number(e5) < Number(t4)))))));
              case "GREATEREQUAL":
                return o2.some(((e4) => (Array.isArray(e4.value) ? e4.value : [e4.value]).some(((e5) => i2.some(((t4) => Number(e5) >= Number(t4)))))));
              case "LESSEQUAL":
                return o2.some(((e4) => (Array.isArray(e4.value) ? e4.value : [e4.value]).some(((e5) => i2.some(((t4) => Number(e5) <= Number(t4)))))));
              default:
                return false;
            }
          }
        };
      }, 3378: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.Page = void 0, t2.Page = class {
          constructor(e3, t3, i, n, r) {
            this.id = e3, this.position = t3, this.generatedAt = (/* @__PURE__ */ new Date()).toISOString(), this.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), this.status = "ACTIVE", this.integrationId = i, this.integrationQuestions = n, this.integrationPageRoutes = r;
          }
        };
      }, 1719: (e2, t2, i) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.PageGraph = void 0;
        const n = i(7170), r = i(4760), o = i(7305);
        t2.PageGraph = class {
          constructor(e3) {
            this.nodes = /* @__PURE__ */ new Map(), this.buildGraph(e3);
          }
          buildGraph(e3) {
            e3.forEach(((e4) => {
              var t3;
              e4.integrationPageRoutes && (e4.integrationPageRoutes = (null === (t3 = e4.integrationPageRoutes) || void 0 === t3 ? void 0 : t3.sort(((e5, t4) => {
                const i3 = new Date((null == e5 ? void 0 : e5.generatedAt) || 0).getTime(), n2 = new Date((null == t4 ? void 0 : t4.generatedAt) || 0).getTime();
                return i3 !== n2 ? i3 - n2 : "DIRECT" === e5.typeCondition && "DIRECT" !== t4.typeCondition ? 1 : "DIRECT" !== e5.typeCondition && "DIRECT" === t4.typeCondition ? -1 : 0;
              }))) || []);
              const i2 = new n.PageNode(e4.id, e4.position, e4.integrationPageRoutes || [], e4, e4.integrationQuestions);
              this.nodes.set(i2.id, i2);
            }));
          }
          getNodeById(e3) {
            return this.nodes.get(e3);
          }
          getNextEdgeByDefault(e3) {
            if (!e3) return;
            const t3 = e3.edges.find(((e4) => e4.typeCondition === o.ConditionType.DIRECT));
            if (!t3 || ![o.TransitionType.FINISH, o.TransitionType.REDIRECT].includes(t3.transition)) {
              if (t3 && t3.transitionDestiny) return t3.transitionDestiny;
              for (const t4 of this.nodes.values()) if (t4.position === e3.position + 1) return t4.id;
            }
          }
          getFirstPage() {
            let e3, t3 = Number.MAX_VALUE;
            for (const i2 of this.nodes.values()) i2.position < t3 && (t3 = i2.position, e3 = i2);
            return e3;
          }
          getNextPage(e3, t3) {
            var i2;
            if (!e3) return;
            const n2 = this.findRoute(e3, t3);
            if (!n2) {
              const t4 = this.getNextEdgeByDefault(e3);
              if (!t4) return;
              return this.getNodeById(t4);
            }
            switch (n2.transition) {
              case o.TransitionType.PAGE:
                if (!n2.transitionDestiny) return;
                return this.getNodeById(n2.transitionDestiny);
              case o.TransitionType.FINISH:
                return;
              case o.TransitionType.REDIRECT:
                return void (window.location.href = (null === (i2 = n2.transitionDestiny) || void 0 === i2 ? void 0 : i2.includes("?")) ? `${n2.transitionDestiny}&${window.location.search.slice(1)}` : `${n2.transitionDestiny}${window.location.search}`);
              default:
                return;
            }
          }
          findRoute(e3, t3) {
            return e3.edges.sort(((e4, t4) => "DIRECT" === e4.typeCondition ? 1 : "DIRECT" === t4.typeCondition ? -1 : 0)), e3.edges.find(((i2) => {
              const n2 = e3.questions.find(((e4) => e4.ref === i2.questionRef)), a = null == t3 ? void 0 : t3.filter(((e4) => e4.key === i2.questionRef));
              if ("DIRECT" === i2.typeCondition) return true;
              if (!a || 0 === a.length) return false;
              if ((null == n2 ? void 0 : n2.type) === r.FEEDBACKAPPANSWERTYPE.MULTI_QUESTION_MATRIX) return this.evaluateMatrixCondition(i2, a);
              const s = Array.isArray(i2.value) ? i2.value : [i2.value];
              switch (i2.typeOperator) {
                case o.OperatorType.EQUAL:
                  return a.some(((e4) => (Array.isArray(e4.value) ? e4.value : [e4.value]).some(((e5) => s.includes(e5)))));
                case o.OperatorType.NOEQUAL:
                  return a.every(((e4) => (Array.isArray(e4.value) ? e4.value : [e4.value]).every(((e5) => !s.includes(e5)))));
                case o.OperatorType.GREATER:
                  return a.some(((e4) => (Array.isArray(e4.value) ? e4.value : [e4.value]).some(((e5) => s.some(((t4) => Number(e5) > Number(t4)))))));
                case o.OperatorType.LESS:
                  return a.some(((e4) => (Array.isArray(e4.value) ? e4.value : [e4.value]).some(((e5) => s.some(((t4) => Number(e5) < Number(t4)))))));
                case o.OperatorType.GREATEREQUAL:
                  return a.some(((e4) => (Array.isArray(e4.value) ? e4.value : [e4.value]).some(((e5) => s.some(((t4) => Number(e5) >= Number(t4)))))));
                case o.OperatorType.LESSEQUAL:
                  return a.some(((e4) => (Array.isArray(e4.value) ? e4.value : [e4.value]).some(((e5) => s.some(((t4) => Number(e5) <= Number(t4)))))));
                case o.OperatorType.INQ:
                  return a.some(((e4) => (Array.isArray(e4.value) ? e4.value : [e4.value]).some(((e5) => s.includes(e5)))));
                case o.OperatorType.NINQ:
                  return a.every(((e4) => (Array.isArray(e4.value) ? e4.value : [e4.value]).every(((e5) => !s.includes(e5)))));
                default:
                  return false;
              }
            }));
          }
          findDepth(e3) {
            const t3 = this.getNodeById(e3);
            if (!t3) return 0;
            const i2 = /* @__PURE__ */ new Set();
            return this.DFSUtil(t3, i2, 0);
          }
          findMaxDepth(e3) {
            if (e3 || (e3 = this.getFirstPage()), !e3) return 0;
            const t3 = /* @__PURE__ */ new Set();
            let i2 = 1;
            return i2 = Math.max(i2, this.DFSUtil(e3, t3, i2)), i2;
          }
          DFSUtil(e3, t3, i2) {
            t3.add(e3);
            let n2 = i2;
            const r2 = [...e3.edges.filter(((e4) => e4.typeCondition !== o.ConditionType.PRECONDITIONAL)) || []], a = this.getNextEdgeByDefault(e3);
            if (a) {
              const i3 = this.getNodeById(a);
              i3 && !t3.has(i3) && r2.push(new o.PageRoute(i3.id, "", o.OperatorType.DEFAULT, [""], o.TransitionType.PAGE, i3.id, e3.id));
            }
            for (const e4 of r2) {
              if (!e4.transitionDestiny) continue;
              const r3 = this.getNodeById(e4.transitionDestiny);
              if (r3 && !t3.has(r3)) {
                const e5 = i2 + 1, o2 = new Set(t3), a2 = this.DFSUtil(r3, o2, e5);
                n2 = Math.max(n2, a2);
              }
            }
            return n2;
          }
          parseMatrixAnswer(e3) {
            if (!e3 || !e3.value) return [];
            if (1 === e3.value.length && "string" == typeof e3.value[0] && e3.value[0].trim().startsWith("[")) try {
              const t3 = JSON.parse(e3.value[0]);
              if (Array.isArray(t3)) return t3;
            } catch (e4) {
              return [];
            }
            return Array.isArray(e3.value) && e3.value.length > 0 && "object" == typeof e3.value[0] && null !== e3.value[0] && "key" in e3.value[0] ? e3.value : [];
          }
          evaluateMatrixCondition(e3, t3) {
            const i2 = Array.isArray(e3.value) ? e3.value : [e3.value], n2 = new Set(e3.option || []), r2 = t3[0], a = this.parseMatrixAnswer(r2);
            if (!a.length) return false;
            const s = n2.size > 0 ? a.filter(((e4) => n2.has(e4.key))) : a;
            if (!s.length) return false;
            switch (e3.typeOperator) {
              case o.OperatorType.EQUAL:
              case o.OperatorType.INQ:
                return s.some(((e4) => (Array.isArray(e4.value) ? e4.value : [e4.value]).some(((e5) => i2.includes(e5)))));
              case o.OperatorType.NOEQUAL:
              case o.OperatorType.NINQ:
                return s.every(((e4) => (Array.isArray(e4.value) ? e4.value : [e4.value]).every(((e5) => !i2.includes(e5)))));
              case o.OperatorType.GREATER:
                return s.some(((e4) => (Array.isArray(e4.value) ? e4.value : [e4.value]).some(((e5) => i2.some(((t4) => Number(e5) > Number(t4)))))));
              case o.OperatorType.LESS:
                return s.some(((e4) => (Array.isArray(e4.value) ? e4.value : [e4.value]).some(((e5) => i2.some(((t4) => Number(e5) < Number(t4)))))));
              case o.OperatorType.GREATEREQUAL:
                return s.some(((e4) => (Array.isArray(e4.value) ? e4.value : [e4.value]).some(((e5) => i2.some(((t4) => Number(e5) >= Number(t4)))))));
              case o.OperatorType.LESSEQUAL:
                return s.some(((e4) => (Array.isArray(e4.value) ? e4.value : [e4.value]).some(((e5) => i2.some(((t4) => Number(e5) <= Number(t4)))))));
              default:
                return false;
            }
          }
        };
      }, 7170: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.PageNode = void 0, t2.PageNode = class {
          constructor(e3, t3, i, n, r, o = false) {
            this.answers = [], this.id = e3, this.position = t3, this.edges = i, this.data = n, this.questions = r.sort(((e4, t4) => e4.position - t4.position)), this.elements = [], this.isFollowup = o;
          }
          getFollowupQuestions() {
            return this.questions.filter(((e3) => e3.followup)).map(((e3) => e3.ref));
          }
          getRequiredQuestions() {
            return this.questions.filter(((e3) => e3.require)).map(((e3) => e3.ref));
          }
          setAnswer(e3) {
            this.answers = e3;
          }
        };
      }, 7305: (e2, t2) => {
        "use strict";
        var i, n, r, o;
        Object.defineProperty(t2, "__esModule", { value: true }), t2.PageRoute = t2.StatusType = t2.OperatorType = t2.ConditionType = t2.TransitionType = void 0, (o = t2.TransitionType || (t2.TransitionType = {})).PAGE = "PAGE", o.FINISH = "FINISH", o.REDIRECT = "REDIRECT", o.NEXT = "NEXT", o.ALLOW = "ALLOW", (function(e3) {
          e3.LOGICAL = "LOGICAL", e3.DIRECT = "DIRECT", e3.PRECONDITIONAL = "PRECONDITIONAL";
        })(i = t2.ConditionType || (t2.ConditionType = {})), (r = t2.OperatorType || (t2.OperatorType = {})).EQUAL = "EQUAL", r.NOEQUAL = "NOEQUAL", r.GREATER = "GREATER", r.LESS = "LESS", r.GREATEREQUAL = "GREATEREQUAL", r.LESSEQUAL = "LESSEQUAL", r.INQ = "INQ", r.NINQ = "NINQ", r.DEFAULT = "DEFAULT", (function(e3) {
          e3.ACTIVE = "ACTIVE", e3.DEPRECATED = "DEPRECATED", e3.DELETE = "DELETE";
        })(n = t2.StatusType || (t2.StatusType = {})), t2.PageRoute = class {
          constructor(e3, t3, r2, o2, a, s, l, d, c, u) {
            this.id = e3, this.questionRef = t3, this.typeCondition = d || i.LOGICAL, this.typeOperator = r2, this.value = o2 || [], this.transition = a, this.transitionDestiny = s, this.status = n.ACTIVE, this.generatedAt = /* @__PURE__ */ new Date(), this.updatedAt = /* @__PURE__ */ new Date(), this.integrationPageId = l, this.position = c || 0, this.option = u || [];
          }
        };
      }, 4760: (e2, t2) => {
        "use strict";
        var i, n;
        Object.defineProperty(t2, "__esModule", { value: true }), t2.AGENT_ANSWER_TYPE_BLOCKED = t2.QuestionType = t2.FEEDBACKAPPANSWERTYPE = void 0, (n = t2.FEEDBACKAPPANSWERTYPE || (t2.FEEDBACKAPPANSWERTYPE = {})).CONTACT = "CONTACT", n.MULTIPLECHOISE_IMAGE = "MULTIPLECHOISE_IMAGE", n.EMAIL = "EMAIL", n.RATING_STAR = "RATING_STAR", n.RADIO = "RADIO", n.MULTIPLECHOICE = "MULTIPLECHOICE", n.SELECT = "SELECT", n.TEXT = "TEXT", n.LONGTEXT = "LONGTEXT", n.NUMBER = "NUMBER", n.RATING_EMOJI = "RATING_EMOJI", n.RATING_NUMBER = "RATING_NUMBER", n.DATE = "DATE", n.BOOLEAN = "BOOLEAN", n.PASSWORD = "PASSWORD", n.CONSENT = "CONSENT", n.MULTI_QUESTION_MATRIX = "MULTI_QUESTION_MATRIX", n.POINT_SYSTEM = "POINT_SYSTEM", n.PRIORITY_LIST = "PRIORITY_LIST", n.INFO_PAGE = "INFO_PAGE", n.UPLOAD_FILE = "UPLOAD_FILE", n.UPLOAD_IMAGE = "UPLOAD_IMAGE", n.MAX_DIFF = "MAX_DIFF", t2.QuestionType = class {
        }, t2.AGENT_ANSWER_TYPE_BLOCKED = "ABUSIVE_OR_OFFENSIVE", (function(e3) {
          e3.FORM = "form", e3.DIV = "div";
        })(i || (i = {}));
      }, 2335: (e2, t2, i) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.applyDirection = t2.applyPrimaryColor = t2.generateContainer = void 0;
        const n = i(7627);
        t2.generateContainer = function(e3, t3) {
          let i2 = document.getElementById(e3);
          if (!i2 && (i2 = document.getElementById("magicfeedback-container-" + t3), !i2)) throw new Error(`Element with ID '${e3}' not found.`);
          return i2.classList.add("magicfeedback-container"), i2.id = "magicfeedback-container-" + t3, i2.innerHTML = "", i2;
        }, t2.applyPrimaryColor = function(e3, t3) {
          e3.style.setProperty("--mf-primary", t3), e3.style.setProperty("--mf-primary-hover", `color-mix(in srgb, ${t3} 85%, black)`), e3.style.setProperty("--mf-primary-light", `color-mix(in srgb, ${t3} 15%, white)`), e3.style.setProperty("--mf-primary-border", `color-mix(in srgb, ${t3} 35%, transparent)`), e3.style.setProperty("--mf-border-focus", t3);
        }, t2.applyDirection = function(e3, t3) {
          const i2 = (0, n.isRtlLanguage)(t3);
          e3.setAttribute("dir", i2 ? "rtl" : "ltr"), e3.classList.toggle("magicfeedback-rtl", i2);
        };
      }, 1366: (e2, t2, i) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.getUrlParam = t2.getBooleanOptions = t2.parseTitle = void 0;
        const n = i(7627);
        t2.parseTitle = function(e3, t3) {
          return e3 ? "object" == typeof e3 ? e3[t3] || e3.en : e3 : "";
        }, t2.getBooleanOptions = function(e3) {
          return [(0, n.t)(e3, "boolean.yes"), (0, n.t)(e3, "boolean.no")];
        }, t2.getUrlParam = function(e3) {
          return new URLSearchParams(window.location.search).get(e3);
        };
      }, 2709: (e2, t2, i) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.RATING_NUMBER_MIN_CAPTIONED_WIDTH = t2.RATING_NUMBER_MIN_CHIP_WIDTH = t2.usesLegacyRatingNumber = t2.createRatingNumberElement = t2.createStarRating = t2.createRatingPlaceholder = void 0;
        const n = i(7627), r = i(9039);
        function o(e3, t3, i2 = "ltr") {
          const n2 = document.createElement("div");
          n2.classList.add("magicfeedback-rating-placeholder");
          const r2 = document.createElement("span");
          r2.textContent = null != e3 ? e3 : "", r2.classList.add("magicfeedback-rating-placeholder-value");
          const o2 = document.createElement("span");
          return o2.textContent = null != t3 ? t3 : "", o2.classList.add("magicfeedback-rating-placeholder-value"), "ltr" === i2 ? (e3 && n2.appendChild(r2), t3 && n2.appendChild(o2)) : (t3 && n2.appendChild(o2), e3 && n2.appendChild(r2)), n2;
        }
        t2.createRatingPlaceholder = o, t2.createStarRating = function(e3, t3, i2, n2 = () => {
        }, a) {
          const s = document.createElement("div");
          s.classList.add("magicfeedback-rating-star-container"), s.style.maxWidth = "300px", s.style.margin = "auto", s.dataset.originalSelection = "0";
          const l = (e4) => {
            s.querySelectorAll(".rating__star").forEach(((t4, i3) => {
              t4.classList.toggle("magicfeedback-rating-star-selected", i3 < e4);
            }));
          };
          for (let t4 = 1; t4 <= 5; t4++) {
            const i3 = document.createElement("label");
            i3.classList.add("magicfeedback-rating-star-option");
            const o2 = document.createElement("input");
            o2.id = `rating-${e3}-${t4}`, o2.type = "radio", o2.name = e3, o2.value = t4.toString(), o2.style.position = "absolute", o2.style.opacity = "0", o2.style.width = "0", o2.style.height = "0", o2.classList.add("magicfeedback-input"), a && a === o2.value && (o2.checked = true), o2.addEventListener("change", (() => {
              l(Number(o2.value)), s.dataset.originalSelection = o2.value;
            })), (0, r.autoAdvanceOn)(o2, n2), i3.appendChild(o2);
            const d2 = document.createElement("label");
            d2.htmlFor = `rating-${e3}-${t4}`, d2.classList.add("rating__star"), d2.textContent = "\u2605", d2.style.fontSize = "40px", d2.style.color = "#CCCCCC", d2.style.cursor = "pointer", d2.addEventListener("mouseenter", (() => l(t4))), d2.addEventListener("mouseleave", (() => l(Number(s.dataset.originalSelection || "0")))), i3.appendChild(d2), s.appendChild(i3);
          }
          const d = s.querySelector("input:checked");
          d && (s.dataset.originalSelection = d.value, l(Number(d.value)));
          const c = o(t3, i2);
          return c.childElementCount > 0 && s.appendChild(c), s;
        }, t2.createRatingNumberElement = function(e3, i2, o2, a, s, l, d, c, u = {}) {
          var p, m;
          const h = document.createElement("div");
          h.classList.add("magicfeedback-rating-number");
          const f = !!u.legacy, g = f && !!u.isPhone, y = g ? (function(e4) {
            const t3 = (null == e4 ? void 0 : e4.max) ? Number(e4.max) : 10, i3 = (null == e4 ? void 0 : e4.min) ? Number(e4.min) : 0;
            return (n2) => {
              var r2;
              return (null === (r2 = null == e4 ? void 0 : e4.numberPlaceholders) || void 0 === r2 ? void 0 : r2[n2]) || (n2 === i3 ? null == e4 ? void 0 : e4.minPlaceholder : void 0) || (n2 === t3 ? null == e4 ? void 0 : e4.maxPlaceholder : void 0) || void 0;
            };
          })(i2) : null;
          g && (a = "column", i2 = Object.assign(Object.assign({}, i2), { minPlaceholder: void 0, maxPlaceholder: void 0, numberPlaceholders: void 0 })), f && h.classList.add("magicfeedback-rating-number--legacy");
          const v = "column" === a, b = "ltr" === o2 ? a : `${a}-reverse`, E = document.createElement("div");
          E.classList.add("magicfeedback-rating-number-container"), E.classList.add(`magicfeedback-rating-number-container-${o2}`), E.classList.add(`magicfeedback-rating-number-container-${a}`), E.style.display = "flex", E.style.flexDirection = b, E.setAttribute("role", "radiogroup"), E.setAttribute("aria-label", (null == i2 ? void 0 : i2.ariaLabel) || (0, n.t)(c, "rating.ariaLabel"));
          const A = (null == i2 ? void 0 : i2.max) ? Number(null == i2 ? void 0 : i2.max) : 10, k = (null == i2 ? void 0 : i2.min) ? Number(null == i2 ? void 0 : i2.min) : 0;
          !v && A - k + 1 > 6 && E.classList.add("magicfeedback-rating-number-container-row--dense");
          const T = (null == i2 ? void 0 : i2.numberPlaceholders) || null, C = !(!T || !Object.keys(T).length), P = !v && !f && !!T && Object.values(T).some(((e4) => !!e4)), S = "bottom" === (null == i2 ? void 0 : i2.numberPlaceholdersPosition) ? "bottom" : "top";
          P && (E.style.alignItems = "stretch");
          let w = null;
          if (!v && !P && ((null == i2 ? void 0 : i2.minPlaceholder) || (null == i2 ? void 0 : i2.maxPlaceholder))) {
            w = document.createElement("div"), w.classList.add("magicfeedback-rating-number-scale-labels");
            const e4 = document.createElement("span");
            e4.classList.add("magicfeedback-rating-number-scale-label"), e4.textContent = null !== (p = null == i2 ? void 0 : i2.minPlaceholder) && void 0 !== p ? p : "";
            const t3 = document.createElement("span");
            t3.classList.add("magicfeedback-rating-number-scale-label"), t3.textContent = null !== (m = null == i2 ? void 0 : i2.maxPlaceholder) && void 0 !== m ? m : "", "ltr" === o2 ? (w.appendChild(e4), w.appendChild(t3)) : (w.appendChild(t3), w.appendChild(e4));
          }
          let O = null;
          if (v && !C && E.classList.add("magicfeedback-rating-number-container-column--bare"), (v ? !C : !P) && ((null == i2 ? void 0 : i2.minPlaceholder) || (null == i2 ? void 0 : i2.maxPlaceholder))) {
            const e4 = "ltr" === o2 ? null == i2 ? void 0 : i2.minPlaceholder : null == i2 ? void 0 : i2.maxPlaceholder, t3 = "ltr" === o2 ? null == i2 ? void 0 : i2.maxPlaceholder : null == i2 ? void 0 : i2.minPlaceholder, n2 = (e5) => {
              const t4 = document.createElement("div");
              return t4.classList.add("magicfeedback-rating-number-scale-label-block"), v || (t4.classList.add("magicfeedback-rating-number-scale-label-block--stacked"), t4.style.display = "none"), t4.textContent = e5, t4;
            };
            e4 && h.appendChild(n2(e4)), t3 && (O = n2(t3));
          }
          for (let t3 = k; t3 <= A; t3++) {
            const n2 = document.createElement("div");
            n2.classList.add("magicfeedback-rating-number-option"), n2.classList.add(`magicfeedback-rating-number-option-${a}`);
            const o3 = document.createElement("label");
            o3.htmlFor = `rating-${e3}-${t3}`, o3.classList.add("magicfeedback-rating-number-option-label-container");
            const c2 = C && (T[t3] || (t3 === k ? null == i2 ? void 0 : i2.minPlaceholder : void 0) || (t3 === A ? null == i2 ? void 0 : i2.maxPlaceholder : void 0)), u2 = document.createElement("input");
            u2.id = `rating-${e3}-${t3}`, u2.type = "radio", u2.name = e3, u2.value = t3.toString(), u2.classList.add(s), u2.classList.add("magicfeedback-input");
            const p2 = null == y ? void 0 : y(t3);
            u2.setAttribute("aria-label", c2 ? `${t3} \u2014 ${c2}` : p2 ? `${t3} \u2014 ${p2}` : `${t3}`), (0, r.autoAdvanceOn)(u2, l), d && d === u2.value && (u2.checked = true), o3.appendChild(u2);
            const m2 = document.createElement("span");
            m2.classList.add("magicfeedback-rating-number-value");
            const h2 = document.createElement("span");
            if (h2.textContent = p2 ? `${t3} = ${p2}` : t3.toString(), h2.classList.add("magicfeedback-rating-number-value-num"), f && (h2.style.fontWeight = "normal"), m2.appendChild(h2), (v || P) && c2) {
              const e4 = document.createElement("span");
              e4.textContent = c2, e4.classList.add("magicfeedback-rating-number-value-label"), v || (e4.style.display = "none"), m2.appendChild(e4);
            } else !v && !P && T && T[t3] && (o3.title = T[t3]);
            if (o3.appendChild(m2), P) {
              const e4 = document.createElement("label");
              e4.htmlFor = u2.id, e4.classList.add("magicfeedback-rating-number-option-caption"), e4.textContent = c2 || "", n2.classList.add("magicfeedback-rating-number-option--captioned"), n2.classList.add(`magicfeedback-rating-number-option--caption-${S}`), n2.style.flexDirection = "top" === S ? "column" : "column-reverse", n2.style.justifyContent = "flex-end", n2.appendChild(e4);
            }
            n2.appendChild(o3), E.appendChild(n2);
          }
          if (h.appendChild(E), O && h.appendChild(O), w) {
            const e4 = null == i2 ? void 0 : i2.minMaxPlaceholderPosition;
            "top" !== e4 && "bottom" !== e4 || (w.classList.add(`magicfeedback-rating-number-scale-labels--${e4}`), w.style.order = "top" === e4 ? "-1" : "1"), "top" === e4 ? h.insertBefore(w, E) : h.appendChild(w);
          }
          if (v || f || (function(e4, i3, n2, r2, o3 = t2.RATING_NUMBER_MIN_CHIP_WIDTH) {
            if ("undefined" == typeof ResizeObserver) return;
            const a2 = i3.classList.contains("magicfeedback-rating-number-container-row--dense"), s2 = !!i3.querySelector(".magicfeedback-rating-number-option--captioned");
            let l2 = 0, d2 = false;
            const c2 = "function" == typeof requestAnimationFrame ? requestAnimationFrame : (e5) => (e5(0), 0);
            let u2 = 0, p2 = false;
            new ResizeObserver(((t3) => {
              var m2;
              const h2 = null === (m2 = t3[0]) || void 0 === m2 ? void 0 : m2.contentRect.width;
              h2 && h2 !== u2 && (u2 = h2, p2 || (p2 = true, c2((() => {
                var t4;
                p2 = false, d2 || (l2 = parseFloat(getComputedStyle(i3).columnGap) || 0), (t4 = u2 < n2 * o3 + (n2 - 1) * l2) !== d2 && (d2 = t4, e4.classList.toggle("magicfeedback-rating-number--stacked", t4), e4.querySelectorAll(":scope > .magicfeedback-rating-number-scale-labels").forEach(((e5) => {
                  e5.style.display = t4 ? "none" : "";
                })), e4.querySelectorAll(":scope > .magicfeedback-rating-number-scale-label-block--stacked").forEach(((e5) => {
                  e5.style.display = t4 ? "" : "none";
                })), i3.classList.toggle("magicfeedback-rating-number-container-row", !t4), i3.classList.toggle("magicfeedback-rating-number-container-row--dense", !t4 && a2), i3.classList.toggle("magicfeedback-rating-number-container-column", t4), i3.classList.toggle("magicfeedback-rating-number-container-column--bare", t4 && !s2), i3.style.flexDirection = t4 ? "ltr" === r2 ? "column" : "column-reverse" : "ltr" === r2 ? "row" : "row-reverse", i3.querySelectorAll(":scope > .magicfeedback-rating-number-option").forEach(((e5) => {
                  if (e5.classList.toggle("magicfeedback-rating-number-option-row", !t4), e5.classList.toggle("magicfeedback-rating-number-option-column", t4), !e5.classList.contains("magicfeedback-rating-number-option--captioned")) return;
                  const i4 = e5.classList.contains("magicfeedback-rating-number-option--caption-top");
                  e5.style.flexDirection = t4 ? "" : i4 ? "column" : "column-reverse", e5.querySelectorAll(".magicfeedback-rating-number-option-caption").forEach(((e6) => {
                    e6.style.display = t4 ? "none" : "";
                  })), e5.querySelectorAll(".magicfeedback-rating-number-value-label").forEach(((e6) => {
                    e6.style.display = t4 ? "" : "none";
                  }));
                })));
              }))));
            })).observe(e4);
          })(h, E, A - k + 1, o2, P ? t2.RATING_NUMBER_MIN_CAPTIONED_WIDTH : t2.RATING_NUMBER_MIN_CHIP_WIDTH), (null == i2 ? void 0 : i2.extraOption) && (null == i2 ? void 0 : i2.extraOptionText)) {
            const t3 = document.createElement("div");
            t3.classList.add("magicfeedback-rating-number-extra-row");
            const n2 = document.createElement("div");
            n2.classList.add("magicfeedback-rating-number-option"), n2.classList.add("magicfeedback-rating-number-option--extra");
            const o3 = document.createElement("label");
            o3.htmlFor = `rating-${e3}-extra`, o3.classList.add("magicfeedback-rating-number-option-label-container");
            const a2 = document.createElement("input");
            a2.id = `rating-${e3}-extra`, a2.type = "radio", a2.name = e3, a2.value = "-", a2.classList.add(s), a2.classList.add("magicfeedback-input"), a2.setAttribute("aria-label", null == i2 ? void 0 : i2.extraOptionText), (0, r.autoAdvanceOn)(a2, l);
            const d2 = document.createElement("span");
            d2.classList.add("magicfeedback-rating-number-value");
            const c2 = document.createElement("span");
            c2.textContent = null == i2 ? void 0 : i2.extraOptionText, c2.classList.add("magicfeedback-rating-number-value-label"), d2.appendChild(c2), o3.appendChild(a2), o3.appendChild(d2), n2.appendChild(o3), t3.appendChild(n2), h.appendChild(t3);
          }
          return h;
        }, t2.usesLegacyRatingNumber = function(e3) {
          return !!e3 && /matas/i.test(e3);
        }, t2.RATING_NUMBER_MIN_CHIP_WIDTH = 44, t2.RATING_NUMBER_MIN_CAPTIONED_WIDTH = 72;
      }, 368: (e2, t2, i) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.getQuestionRenderer = void 0;
        const n = i(4760), r = i(620), o = i(9006), a = i(3034), s = i(8924), l = i(2807), d = i(2311), c = i(8139), u = i(6363), p = i(7282), m = i(9369), h = i(2626), f = i(2255), g = i(1042), y = i(1994), v = i(1615), b = i(8160), E = i(9169), A = i(1724), k = i(2287), T = i(9796), C = i(5430), P = /* @__PURE__ */ new Map([[n.FEEDBACKAPPANSWERTYPE.TEXT, s.renderText], [n.FEEDBACKAPPANSWERTYPE.LONGTEXT, o.renderLongText], [n.FEEDBACKAPPANSWERTYPE.NUMBER, a.renderNumber], [n.FEEDBACKAPPANSWERTYPE.RADIO, r.renderChoice], [n.FEEDBACKAPPANSWERTYPE.MULTIPLECHOICE, r.renderChoice], [n.FEEDBACKAPPANSWERTYPE.BOOLEAN, l.renderBoolean], [n.FEEDBACKAPPANSWERTYPE.SELECT, d.renderSelect], [n.FEEDBACKAPPANSWERTYPE.DATE, c.renderDate], [n.FEEDBACKAPPANSWERTYPE.EMAIL, u.renderEmail], [n.FEEDBACKAPPANSWERTYPE.PASSWORD, p.renderPassword], [n.FEEDBACKAPPANSWERTYPE.CONSENT, m.renderConsent], [n.FEEDBACKAPPANSWERTYPE.RATING_EMOJI, h.renderRatingEmoji], [n.FEEDBACKAPPANSWERTYPE.RATING_NUMBER, f.renderRatingNumber], [n.FEEDBACKAPPANSWERTYPE.RATING_STAR, g.renderRatingStar], [n.FEEDBACKAPPANSWERTYPE.MULTI_QUESTION_MATRIX, y.renderMatrix], [n.FEEDBACKAPPANSWERTYPE.PRIORITY_LIST, v.renderPriorityList], [n.FEEDBACKAPPANSWERTYPE.POINT_SYSTEM, b.renderPointSystem], [n.FEEDBACKAPPANSWERTYPE.UPLOAD_IMAGE, E.renderUploadImage], [n.FEEDBACKAPPANSWERTYPE.UPLOAD_FILE, A.renderUploadFile], [n.FEEDBACKAPPANSWERTYPE.MULTIPLECHOISE_IMAGE, k.renderMultipleChoiceImage], [n.FEEDBACKAPPANSWERTYPE.INFO_PAGE, T.renderInfoPage], [n.FEEDBACKAPPANSWERTYPE.MAX_DIFF, C.renderMaxDiff]]);
        t2.getQuestionRenderer = function(e3) {
          return P.get(e3);
        };
      }, 2807: (e2, t2, i) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.renderBoolean = void 0;
        const n = i(1366), r = i(9039);
        t2.renderBoolean = ({ question: e3, language: t3, urlParamValue: i2, send: o }) => {
          const { ref: a, assets: s } = e3, l = document.createElement("div"), d = "magicfeedback-radio", c = document.createElement("div");
          return c.classList.add("magicfeedback-boolean-container"), c.style.display = "flex", c.style.flexDirection = "row", c.style.justifyContent = "space-between", c.style.width = "70%", c.style.margin = "auto", ((null == s ? void 0 : s.addIcon) ? ["\u{1F44D}", "\u{1F44E}"] : (0, n.getBooleanOptions)(t3)).forEach(((e4, t4) => {
            const n2 = document.createElement("label");
            n2.classList.add("magicfeedback-boolean-option"), n2.htmlFor = `rating-${a}-${t4}`, n2.style.cursor = "pointer", n2.style.display = "flex", n2.style.justifyContent = "center", n2.style.alignItems = "center", n2.style.margin = "auto", n2.style.padding = "0", n2.style.width = "45%", n2.style.height = "38px";
            const s2 = document.createElement("label");
            s2.htmlFor = `rating-${a}-${t4}`, s2.textContent = e4, s2.style.margin = "0", s2.style.padding = "0";
            const l2 = document.createElement("input");
            l2.id = `rating-${a}-${t4}`, l2.type = "radio", l2.name = a, l2.value = ["Yes", "No"][t4], l2.classList.add(d), l2.classList.add("magicfeedback-input"), l2.style.position = "absolute", l2.style.opacity = "0", l2.style.width = "0", l2.style.height = "0", l2.style.margin = "0", (0, r.autoAdvanceOn)(l2, o), i2 && i2.toLowerCase() === l2.value.toLowerCase() && (l2.checked = true), n2.appendChild(l2), n2.appendChild(s2), c.appendChild(n2);
          })), l.appendChild(c), { element: l, elementTypeClass: d };
        };
      }, 620: (e2, t2, i) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.CHOICE_ROW_MIN_OPTION_WIDTH = t2.renderChoice = void 0;
        const n = i(4760), r = i(3262), o = i(9039);
        t2.renderChoice = ({ question: e3, language: i2, urlParamValue: s, randomPosition: l, send: d }) => {
          const { type: c, ref: u, value: p, defaultValue: m, assets: h } = e3, f = document.createElement("div"), g = "magicfeedback-" + ("MULTIPLECHOICE" === c ? "checkbox" : "radio");
          let y = p || [];
          l && (y = y.sort((() => Math.random() - 0.5)));
          let v = (null == h ? void 0 : h.exclusiveAnswers) || [];
          (null == h ? void 0 : h.extraOption) && (v = v.filter(((e4) => e4 !== h.extraOptionText))), v.length > 0 && (null == v || v.forEach(((e4) => {
            y.includes(e4) || y.push(e4);
          })));
          const b = null == h ? void 0 : h.extraOptionText;
          return (null == h ? void 0 : h.extraOption) && b && !y.includes(b) && y.push(b), y.forEach(((e4, t3) => {
            const a2 = document.createElement("div");
            a2.classList.add(`magicfeedback-${"MULTIPLECHOICE" === c ? "checkbox" : "radio"}-container`);
            const l2 = document.createElement("label"), p2 = document.createElement("input");
            if (p2.id = `rating-${u}-${t3}`, p2.type = "MULTIPLECHOICE" === c ? "checkbox" : "radio", p2.name = u, p2.value = e4, p2.classList.add(g), p2.classList.add("magicfeedback-input"), c === n.FEEDBACKAPPANSWERTYPE.MULTIPLECHOICE && (null == h ? void 0 : h.maxOptions) && (null == h ? void 0 : h.maxOptions) > 0 && p2.addEventListener("change", (() => {
              document.querySelectorAll(`input[name="${u}"]:checked`).length > (null == h ? void 0 : h.maxOptions) && (p2.checked = false);
            })), c === n.FEEDBACKAPPANSWERTYPE.RADIO && d && (!(null == h ? void 0 : h.extraOptionText) || (null == h ? void 0 : h.extraOptionText) && e4 !== (null == h ? void 0 : h.extraOptionText)) && (0, o.autoAdvanceOn)(p2, d), e4 !== m && e4 !== s || (p2.checked = true), l2.textContent = e4, l2.htmlFor = `rating-${u}-${t3}`, p2.addEventListener("change", ((t4) => {
              const i3 = document.getElementById(`extra-option-${u}`);
              t4.target.checked && v.includes(e4) ? (y.forEach(((t5) => {
                t5 !== e4 && (document.querySelector(`input[value="${t5}"]`).checked = false);
              })), i3 && (i3.style.display = "none")) : v.forEach(((t5) => {
                t5 !== e4 && (document.querySelector(`input[value="${t5}"]`).checked = false);
              })), (null == h ? void 0 : h.extraOption) && e4 === (null == h ? void 0 : h.extraOptionText) && i3 && (i3.style.display = t4.target.checked ? "block" : "none");
            })), a2.appendChild(p2), a2.appendChild(l2), f.appendChild(a2), (null == h ? void 0 : h.extraOption) && e4 === (null == h ? void 0 : h.extraOptionText)) {
              const e5 = document.createElement("input");
              e5.type = "text", e5.placeholder = (null == h ? void 0 : h.extraOptionPlaceholder) || r.placeholder.answer(i2 || "en"), e5.classList.add("magicfeedback-extra-option"), e5.classList.add("magicfeedback-input"), e5.id = `extra-option-${u}`, e5.name = `extra-option-${u}`, e5.style.display = "none", f.appendChild(e5);
            }
          })), c === n.FEEDBACKAPPANSWERTYPE.RADIO && "row" === (null == h ? void 0 : h.direction) && (f.classList.add("magicfeedback-radio--row"), (function(e4, i3) {
            if (e4.classList.toggle("magicfeedback-radio--stacked", window.innerWidth < a), "undefined" == typeof ResizeObserver) return;
            const n2 = "function" == typeof requestAnimationFrame ? requestAnimationFrame : (e5) => (e5(0), 0);
            let r2 = 0, o2 = false;
            new ResizeObserver(((s2) => {
              var l2;
              const d2 = null === (l2 = s2[0]) || void 0 === l2 ? void 0 : l2.contentRect.width;
              d2 && d2 !== r2 && (r2 = d2, o2 || (o2 = true, n2((() => {
                o2 = false, ((n3) => {
                  const r3 = parseFloat(getComputedStyle(e4).columnGap) || 0, o3 = i3 * t2.CHOICE_ROW_MIN_OPTION_WIDTH + (i3 - 1) * r3;
                  e4.classList.toggle("magicfeedback-radio--stacked", window.innerWidth < a || n3 < o3);
                })(r2);
              }))));
            })).observe(e4);
          })(f, y.length)), { element: f, elementTypeClass: g };
        }, t2.CHOICE_ROW_MIN_OPTION_WIDTH = 120;
        const a = 600;
      }, 9369: (e2, t2, i) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.renderConsent = void 0;
        const n = i(9039);
        t2.renderConsent = ({ question: e3, urlParamValue: t3, send: i2 }) => {
          const { id: r, ref: o, value: a, require: s } = e3, l = document.createElement("input");
          return l.type = "checkbox", l.id = `magicfeedback-${r}`, l.name = o, l.value = "true", l.required = s, l.classList.add("magicfeedback-consent"), l.classList.add("magicfeedback-input"), t3 && a.includes(t3) && (l.checked = true), (0, n.autoAdvanceOn)(l, i2), { element: l, elementTypeClass: "magicfeedback-consent" };
        };
      }, 8139: (e2, t2, i) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.renderDate = void 0;
        const n = i(3262);
        t2.renderDate = ({ language: e3, placeholderText: t3, urlParamValue: i2 }) => {
          const r = document.createElement("input");
          return r.type = "date", r.placeholder = t3 || n.placeholder.date(e3 || "en"), i2 && (r.value = i2), { element: r, elementTypeClass: "magicfeedback-date" };
        };
      }, 6363: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.renderEmail = void 0, t2.renderEmail = ({ placeholderText: e3, urlParamValue: t3 }) => {
          const i = document.createElement("input");
          return i.type = "email", i.placeholder = e3 || "you@example.com", t3 && (i.value = t3), { element: i, elementTypeClass: "magicfeedback-email" };
        };
      }, 9796: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.renderInfoPage = void 0, t2.renderInfoPage = ({ question: e3, placeholderText: t3 }) => {
          var i, n;
          const r = document.createElement("div");
          if ("string" == typeof (null === (i = e3.assets) || void 0 === i ? void 0 : i.placeholder) ? "" !== e3.assets.placeholder.trim() : Boolean(null === (n = e3.assets) || void 0 === n ? void 0 : n.placeholder)) {
            const e4 = document.createElement("div");
            e4.classList.add("magicfeedback-info-message"), e4.innerHTML = t3 || "", r.appendChild(e4);
          }
          return { element: r, elementTypeClass: "magicfeedback-info-page" };
        };
      }, 9006: (e2, t2, i) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.renderLongText = void 0;
        const n = i(3262);
        t2.renderLongText = ({ language: e3, placeholderText: t3, urlParamValue: i2, maxCharacters: r }) => {
          const o = document.createElement("textarea");
          return o.rows = 3, r > 0 && (o.maxLength = r), o.placeholder = t3 || n.placeholder.answer(e3 || "en"), i2 && (o.value = i2), { element: o, elementTypeClass: "magicfeedback-longtext" };
        };
      }, 1994: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.renderMatrix = void 0, t2.renderMatrix = ({ question: e3, isPhone: t3, randomPosition: i }) => {
          const { ref: n, value: r, assets: o } = e3, a = document.createElement("div"), s = document.createElement("div");
          s.classList.add("magicfeedback-multi-question-matrix-container");
          let l = (null == o ? void 0 : o.options) || [], d = [...r], c = [];
          if (i && (l = null == l ? void 0 : l.sort((() => Math.random() - 0.5)), d = [...d].sort((() => Math.random() - 0.5))), (null == o ? void 0 : o.exclusiveAnswers) && (c = null == o ? void 0 : o.exclusiveAnswers, null == c || c.forEach(((e4) => {
            d.includes(e4) || d.push(e4);
          }))), t3) {
            const e4 = document.createElement("div");
            e4.classList.add("magicfeedback-multi-question-matrix-list"), null == l || l.forEach(((t4) => {
              const i2 = document.createElement("div");
              i2.classList.add("magicfeedback-multi-question-matrix-list-item"), i2.style.display = "flex", i2.style.flexDirection = "column", i2.style.alignItems = "flex-start", i2.style.marginBottom = "10px";
              const r2 = document.createElement("label");
              r2.classList.add("magicfeedback-multi-question-matrix-label"), r2.style.paddingBottom = "10px", r2.textContent = t4, i2.appendChild(r2), d.forEach(((e5) => {
                const r3 = document.createElement("div");
                r3.classList.add("magicfeedback-radio-container"), r3.style.display = "flex", r3.style.alignItems = "center", r3.style.justifyContent = "flex-start", r3.style.width = "99%", r3.style.margin = "5px auto";
                const o2 = document.createElement("label"), a2 = document.createElement("input");
                a2.id = `${n}-${t4}-${e5}`, a2.type = "radio", a2.name = `${n}-${t4}`, a2.value = e5, a2.classList.add("magicfeedback-input"), o2.textContent = e5, o2.htmlFor = `${n}-${t4}-${e5}`, r3.appendChild(a2), r3.appendChild(o2), i2.appendChild(r3);
              })), e4.appendChild(i2);
            })), s.appendChild(e4);
          } else {
            const e4 = document.createElement("table");
            e4.classList.add("magicfeedback-multi-question-matrix-table");
            const t4 = document.createElement("thead");
            t4.classList.add("magicfeedback-multi-question-matrix-header"), t4.style.paddingBottom = "15px";
            const i2 = document.createElement("tr"), r2 = document.createElement("th");
            i2.appendChild(r2), d.forEach(((e5) => {
              const t5 = document.createElement("th");
              t5.textContent = e5, i2.appendChild(t5);
            })), t4.appendChild(i2), e4.appendChild(t4);
            const o2 = document.createElement("tbody");
            null == l || l.forEach(((e5) => {
              const t5 = document.createElement("tr");
              t5.classList.add("magicfeedback-multi-question-matrix-row-tr");
              const i3 = document.createElement("td");
              i3.classList.add("magicfeedback-multi-question-matrix-question");
              const r3 = document.createElement("label");
              r3.classList.add("magicfeedback-multi-question-matrix-label"), r3.textContent = e5, i3.appendChild(r3), t5.appendChild(i3), d.forEach(((i4) => {
                const r4 = document.createElement("td"), o3 = document.createElement("input");
                o3.type = "radio", o3.name = `${n}-${e5}`, o3.value = i4, o3.id = `${n}-${e5}-${i4}`, o3.classList.add("magicfeedback-input");
                const a2 = document.createElement("label");
                a2.classList.add("magicfeedback-multi-question-matrix-option-label"), a2.htmlFor = o3.id, a2.textContent = i4, r4.classList.add("magicfeedback-multi-question-matrix-option"), r4.appendChild(o3), r4.appendChild(a2), t5.appendChild(r4);
              })), o2.appendChild(t5);
            })), e4.appendChild(o2), s.appendChild(e4);
          }
          return a.appendChild(s), { element: a, elementTypeClass: "magicfeedback-multi-question-matrix" };
        };
      }, 5430: (e2, t2, i) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.renderMaxDiff = void 0;
        const n = i(1366), r = i(7627), o = "http://www.w3.org/2000/svg";
        t2.renderMaxDiff = ({ question: e3, language: t3, randomPosition: i2 }) => {
          const { ref: a, value: s, assets: l } = e3, d = document.createElement("div");
          let c = [...s || []];
          i2 && (c = c.sort((() => Math.random() - 0.5)));
          const u = { best: (0, n.parseTitle)(null == l ? void 0 : l.bestLabel, t3) || (0, r.t)(t3, "maxDiff.best"), worst: (0, n.parseTitle)(null == l ? void 0 : l.worstLabel, t3) || (0, r.t)(t3, "maxDiff.worst") }, p = document.createElement("div");
          p.classList.add("magicfeedback-max-diff-container");
          const m = Number(null == l ? void 0 : l.setIndex) || 1, h = Number(null == l ? void 0 : l.setCount) || 1;
          (null == l ? void 0 : l.showSetProgress) && h > 1 && p.appendChild((function(e4, t4, i3) {
            const n2 = document.createElement("div");
            n2.classList.add("magicfeedback-max-diff-progress");
            const o2 = document.createElement("span");
            o2.classList.add("magicfeedback-max-diff-progress-label"), o2.textContent = (0, r.t)(i3, "maxDiff.setProgress", { k: e4, n: t4 });
            const a2 = document.createElement("span");
            a2.classList.add("magicfeedback-max-diff-progress-track"), a2.setAttribute("aria-hidden", "true");
            const s2 = document.createElement("span");
            return s2.classList.add("magicfeedback-max-diff-progress-fill"), s2.style.width = `${Math.min(100, e4 / t4 * 100)}%`, a2.appendChild(s2), n2.appendChild(o2), n2.appendChild(a2), n2;
          })(m, h, t3));
          const f = document.createElement("table");
          f.classList.add("magicfeedback-max-diff-table");
          const g = (e4) => {
            const t4 = document.createElement("th");
            t4.scope = "col", t4.classList.add("magicfeedback-max-diff-head", `magicfeedback-max-diff-head-${e4}`);
            const i3 = document.createElement("span");
            return i3.classList.add("magicfeedback-max-diff-head-label"), i3.appendChild((function(e5) {
              const t5 = document.createElementNS(o, "svg");
              t5.setAttribute("viewBox", "0 0 24 24"), t5.setAttribute("width", "16"), t5.setAttribute("height", "16"), t5.setAttribute("fill", "none"), t5.setAttribute("stroke", "currentColor"), t5.setAttribute("stroke-width", "2.6"), t5.setAttribute("stroke-linecap", "round"), t5.setAttribute("stroke-linejoin", "round"), t5.setAttribute("aria-hidden", "true");
              const i4 = document.createElementNS(o, "path");
              return i4.setAttribute("d", "best" === e5 ? "M12 19V5M5 12l7-7 7 7" : "M12 5v14M19 12l-7 7-7-7"), t5.appendChild(i4), t5;
            })(e4)), i3.appendChild(document.createTextNode(u[e4])), t4.appendChild(i3), t4;
          }, y = document.createElement("thead"), v = document.createElement("tr"), b = document.createElement("td");
          b.classList.add("magicfeedback-max-diff-head-spacer"), v.appendChild(g("best")), v.appendChild(b), v.appendChild(g("worst")), y.appendChild(v), f.appendChild(y);
          const E = (e4, t4, i3) => {
            const n2 = document.createElement("td");
            n2.classList.add("magicfeedback-max-diff-cell");
            const r2 = document.createElement("label");
            r2.classList.add("magicfeedback-max-diff-pick");
            const o2 = document.createElement("input");
            return o2.type = "radio", o2.name = `${a}-${e4}`, o2.value = t4, o2.id = `${a}-${e4}-${i3}`, o2.classList.add("magicfeedback-input", "magicfeedback-max-diff-input", `magicfeedback-max-diff-${e4}`), o2.setAttribute("aria-label", `${t4}: ${u[e4]}`), r2.appendChild(o2), n2.appendChild(r2), n2;
          }, A = document.createElement("tbody");
          return c.forEach(((e4, t4) => {
            const i3 = document.createElement("tr");
            i3.classList.add("magicfeedback-max-diff-row");
            const n2 = document.createElement("th");
            n2.scope = "row", n2.classList.add("magicfeedback-max-diff-item"), n2.textContent = e4, i3.appendChild(E("best", e4, t4)), i3.appendChild(n2), i3.appendChild(E("worst", e4, t4)), A.appendChild(i3);
          })), f.appendChild(A), f.addEventListener("change", ((e4) => {
            var t4;
            const i3 = e4.target;
            i3.classList.contains("magicfeedback-max-diff-input") && (null === (t4 = i3.closest("tr")) || void 0 === t4 || t4.querySelectorAll(".magicfeedback-max-diff-input").forEach(((e5) => {
              e5 !== i3 && (e5.checked = false);
            })));
          })), p.appendChild(f), d.appendChild(p), { element: d, elementTypeClass: "magicfeedback-max-diff" };
        };
      }, 2287: (e2, t2, i) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.renderMultipleChoiceImage = void 0;
        const n = i(9039);
        t2.renderMultipleChoiceImage = ({ question: e3, randomPosition: t3, urlParamValue: i2, send: r }) => {
          const o = document.createElement("div"), { ref: a, assets: s } = e3;
          let l = [...e3.value];
          const d = document.createElement("div");
          d.classList.add("magicfeedback-multiple-choice-image-container"), d.style.display = "flex", d.style.flexDirection = "row", d.style.flexWrap = "wrap", d.style.justifyContent = "center";
          const c = l.length;
          let u = 1, p = 1;
          if (window.innerWidth < 600) u = 1, p = c;
          else switch (c) {
            case 1:
            case 2:
            case 3:
              u = c, p = 1;
              break;
            case 4:
            case 5:
            case 6:
              p = 2, u = Math.ceil(c / p);
              break;
            case 7:
            case 8:
            case 9:
              p = 3, u = Math.ceil(c / p);
              break;
            default:
              p = 4, u = Math.ceil(c / p);
          }
          const m = void 0 !== (null == s ? void 0 : s.addTitle) && (null == s ? void 0 : s.addTitle), h = void 0 !== (null == s ? void 0 : s.multiOption) && (null == s ? void 0 : s.multiOption), f = void 0 !== (null == s ? void 0 : s.extraOption) && (null == s ? void 0 : s.extraOption);
          function g(e4) {
            try {
              const { position: t4, url: o2, value: s2 } = e4, l2 = document.createElement("div");
              l2.classList.add("magicfeedback-multiple-choice-image-option"), l2.style.width = `calc(100% / ${u} - 2px)`, l2.style.height = `calc(100% / ${p} - 2px)`, l2.style.padding = "8px", l2.style.margin = "0";
              const c2 = document.createElement("label");
              c2.classList.add("magicfeedback-image-option-label-container"), c2.htmlFor = `rating-${a}-${t4}`, c2.style.cursor = "pointer", c2.addEventListener("click", (() => {
                c2.style.border = "2px solid #000";
              }));
              const f2 = document.createElement("label");
              f2.textContent = s2, f2.classList.add("magicfeedback-multiple-choice-image-label");
              const g2 = document.createElement("input");
              g2.id = `rating-${a}-${t4}`, g2.type = h ? "checkbox" : "radio", g2.name = a, g2.value = s2, g2.style.position = "absolute", g2.style.opacity = "0", g2.style.width = "0", g2.style.height = "0", g2.classList.add("magicfeedback-input"), i2 && i2 === g2.value && (g2.checked = true), h || (0, n.autoAdvanceOn)(g2, r);
              const y = document.createElement("img");
              y.classList.add("magicfeedback-multiple-choice-image-image"), y.src = o2, y.style.cursor = "pointer", y.style.backgroundSize = "cover", y.style.backgroundPosition = "center", y.style.width = "100%", y.style.height = "100%", y.style.objectFit = "cover", y.style.margin = "auto", c2.appendChild(g2), c2.appendChild(y), m && c2.appendChild(f2), l2.appendChild(c2), d.appendChild(l2);
            } catch (e5) {
              console.error(e5);
            }
          }
          return t3 && (l = l.sort((() => Math.random() - 0.5))), l.forEach(((e4) => g(JSON.parse(e4)))), f && (null == s ? void 0 : s.extraOptionValue) && (null == s ? void 0 : s.extraOptionValue.length) > 0 && g(null == s ? void 0 : s.extraOptionValue[0]), o.appendChild(d), { element: o, elementTypeClass: "magicfeedback-multiple-choice-image" };
        };
      }, 3034: (e2, t2, i) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.renderNumber = void 0;
        const n = i(3262), r = i(1366);
        t2.renderNumber = ({ question: e3, format: t3, language: i2, urlParamValue: o }) => {
          const a = document.createElement("input");
          a.type = "number", a.placeholder = "slim" === t3 ? (0, r.parseTitle)(e3.title, i2) : n.placeholder.number(i2 || "en");
          const { value: s } = e3;
          return s.length && (s.sort(((e4, t4) => Number(e4) - Number(t4))), a.max = s[s.length - 1], a.min = s[0], a.value = s[0]), o && !isNaN(Number(o)) && (a.value = o), { element: a, elementTypeClass: "magicfeedback-number" };
        };
      }, 7282: (e2, t2, i) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.renderPassword = void 0;
        const n = i(3262);
        t2.renderPassword = ({ language: e3, placeholderText: t3, urlParamValue: i2 }) => {
          const r = document.createElement("input");
          return r.type = "password", r.placeholder = t3 || n.placeholder.password(e3 || "en"), i2 && (r.value = i2), { element: r, elementTypeClass: "magicfeedback-password" };
        };
      }, 8160: (e2, t2, i) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.renderPointSystem = void 0;
        const n = i(3262);
        t2.renderPointSystem = ({ question: e3, language: t3 }) => {
          const { ref: i2, value: r } = e3, o = document.createElement("div"), a = document.createElement("div");
          a.classList.add("magicfeedback-point-system-container");
          const s = document.createElement("ul");
          s.classList.add("magicfeedback-point-system-list"), s.style.padding = "0";
          const l = 100 / r.length, d = document.createElement("div");
          d.classList.add("magicfeedback-error"), d.textContent = n.placeholder.pointsystemerror(t3 || "en"), d.style.color = "#C70039", d.style.fontSize = "14px", d.style.textAlign = "end", d.style.width = "100%", d.style.display = "none";
          const c = document.createElement("div");
          c.classList.add("magicfeedback-point-system-total"), c.style.textAlign = "end", c.style.fontSize = "15px", c.style.marginTop = "5px";
          const u = document.createElement("bdi");
          return u.setAttribute("dir", "ltr"), u.textContent = "0 / 100 %", c.appendChild(u), r.forEach(((e4, t4) => {
            const n2 = document.createElement("li");
            n2.classList.add("magicfeedback-point-system-item"), n2.style.display = "flex", n2.style.justifyContent = "space-between", n2.style.alignItems = "center", n2.style.margin = "5px";
            const r2 = document.createElement("label");
            r2.textContent = e4, r2.style.fontSize = "15px", n2.appendChild(r2);
            const o2 = document.createElement("span");
            o2.classList.add("magicfeedback-point-system-input-container");
            const a2 = document.createElement("input");
            a2.name = i2, a2.id = `${e4}`, a2.type = "number", a2.min = "0", a2.max = "100", a2.value = "0", a2.classList.add("magicfeedback-input"), a2.style.width = "40px", a2.style.border = "0", a2.style.textAlign = "center", a2.style.margin = "0 5px", a2.autofocus = 0 === t4;
            const p = document.createElement("span");
            p.textContent = "%", p.style.color = "#000", a2.addEventListener("input", (() => {
              const e5 = s.querySelectorAll("input");
              let t5 = 0;
              e5.forEach(((e6) => {
                t5 += Number(e6.value);
              })), t5 > 100 && (a2.value = `${l}%`, t5 -= Number(a2.value));
              const i3 = document.getElementById("magicfeedback-submit");
              i3 && (t5 < 100 ? (c.style.color = "orange", i3.setAttribute("disabled", "true")) : (d.style.display = "none", c.style.color = "green", i3.removeAttribute("disabled"))), u.textContent = `${t5} / 100 %`;
            })), a2.addEventListener("focus", (() => {
              const e5 = document.getElementById("magicfeedback-submit");
              e5 && (e5.setAttribute("disabled", "true"), e5.addEventListener("pointerover", (() => {
                const e6 = s.querySelectorAll("input");
                let t5 = 0;
                e6.forEach(((e7) => {
                  t5 += Number(e7.value);
                })), t5 < 100 && (d.style.display = "block");
              })));
            })), o2.appendChild(a2), o2.appendChild(p), n2.appendChild(o2), s.appendChild(n2);
          })), a.appendChild(s), a.appendChild(c), a.appendChild(d), o.appendChild(a), { element: o, elementTypeClass: "magicfeedback-point-system" };
        };
      }, 1615: (e2, t2, i) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.renderPriorityList = void 0;
        const n = i(7627);
        t2.renderPriorityList = ({ question: e3, randomPosition: t3, language: i2 }) => {
          var r, o, a;
          const s = document.createElement("div"), l = (function(e4) {
            const { value: t4, ref: i3, randomPosition: r2 = false, limitPriority: o2 = false, maxPriority: a2 = 0, language: s2 = "en", placeholder: l2 = "" } = e4, d = (e5) => (0, n.t)(s2, "priority." + e5), c = document.createElement("div");
            if (c.classList.add("magicfeedback-priority-list-container"), o2 && a2 && a2 > 0) {
              const e5 = [], o3 = document.createElement("div");
              o3.classList.add("magicfeedback-priority-list-header");
              const u2 = document.createElement("div");
              u2.classList.add("magicfeedback-priority-list-instruction"), u2.textContent = "" !== l2 ? l2 : `${d("instruction")}`, u2.style.display = "none";
              const p2 = document.createElement("button");
              p2.type = "button", p2.textContent = d("selectOptions"), p2.classList.add("magicfeedback-button"), p2.classList.add("magicfeedback-priority-list-open-btn"), o3.appendChild(p2), o3.appendChild(u2);
              const m = document.createElement("div");
              m.classList.add("magicfeedback-priority-list-reorder");
              const h = document.createElement("ul");
              h.classList.add("magicfeedback-priority-list-list"), m.appendChild(h);
              const f = () => {
                h.innerHTML = "", e5.forEach(((t5, n2) => {
                  const r3 = document.createElement("li");
                  r3.classList.add("magicfeedback-priority-list-item");
                  const o4 = document.createElement("input");
                  o4.classList.add("magicfeedback-input-magicfeedback-priority-list"), o4.classList.add("magicfeedback-input"), o4.type = "hidden", o4.id = `priority-list-${i3}`, o4.name = i3, o4.value = `${n2 + 1}. ${t5}`, r3.appendChild(o4);
                  const a3 = document.createElement("label");
                  a3.classList.add("magicfeedback-priority-list-item-label"), a3.textContent = `${n2 + 1}. ${t5}`, r3.appendChild(a3);
                  const s3 = document.createElement("div");
                  s3.classList.add("magicfeedback-priority-list-arrows");
                  const l3 = document.createElement("img");
                  l3.classList.add("magicfeedback-priority-list-arrow-up"), l3.src = "https://magicfeedback-c6458-dev.web.app/assets/arrow.svg", l3.style.visibility = 0 === n2 ? "hidden" : "visible";
                  const d2 = document.createElement("img");
                  d2.classList.add("magicfeedback-priority-list-arrow-down"), d2.src = "https://magicfeedback-c6458-dev.web.app/assets/arrow.svg", d2.style.transform = "rotate(180deg)", d2.style.visibility = n2 === e5.length - 1 ? "hidden" : "visible", l3.addEventListener("click", (() => {
                    var i4, n3, s4, c2;
                    const u3 = r3.previousElementSibling;
                    if (u3) {
                      const p3 = Number(null === (i4 = o4.value) || void 0 === i4 ? void 0 : i4.split(".")[0]) - 1;
                      o4.value = `${p3}. ${t5}`, a3.textContent = `${p3}. ${t5}`, l3.style.visibility = 1 === p3 ? "hidden" : "visible", d2.style.visibility = p3 === e5.length ? "hidden" : "visible";
                      const m2 = u3.querySelector(".magicfeedback-input-magicfeedback-priority-list"), f2 = u3.querySelector(".magicfeedback-priority-list-item-label"), g2 = u3.querySelector(".magicfeedback-priority-list-arrow-up"), y2 = u3.querySelector(".magicfeedback-priority-list-arrow-down");
                      if (m2 && f2 && g2 && y2) {
                        const t6 = Number(null === (n3 = m2.value) || void 0 === n3 ? void 0 : n3.split(".")[0]) + 1;
                        m2.value = `${t6}.${null === (s4 = f2.textContent) || void 0 === s4 ? void 0 : s4.split(".")[1]}`, f2.textContent = `${t6}.${null === (c2 = f2.textContent) || void 0 === c2 ? void 0 : c2.split(".")[1]}`, g2.style.visibility = 1 === t6 ? "hidden" : "visible", y2.style.visibility = t6 === e5.length ? "hidden" : "visible";
                      }
                      h.insertBefore(r3, u3);
                    }
                  })), d2.addEventListener("click", (() => {
                    var i4, n3, s4;
                    const c2 = r3.nextElementSibling;
                    if (c2) {
                      const u3 = Number(null === (i4 = o4.value) || void 0 === i4 ? void 0 : i4.split(".")[0]) + 1;
                      o4.value = `${u3}. ${t5}`, a3.textContent = `${u3}. ${t5}`, l3.style.visibility = 1 === u3 ? "hidden" : "visible", d2.style.visibility = u3 === e5.length ? "hidden" : "visible";
                      const p3 = c2.querySelector(".magicfeedback-input-magicfeedback-priority-list"), m2 = c2.querySelector(".magicfeedback-priority-list-item-label"), f2 = c2.querySelector(".magicfeedback-priority-list-arrow-up"), g2 = c2.querySelector(".magicfeedback-priority-list-arrow-down");
                      if (p3 && m2 && f2 && g2) {
                        const t6 = Number(p3.value.split(".")[0]) - 1;
                        p3.value = `${t6}.${null === (n3 = m2.textContent) || void 0 === n3 ? void 0 : n3.split(".")[1]}`, m2.textContent = `${t6}.${null === (s4 = m2.textContent) || void 0 === s4 ? void 0 : s4.split(".")[1]}`, f2.style.visibility = 1 === t6 ? "hidden" : "visible", g2.style.visibility = t6 === e5.length ? "hidden" : "visible";
                      }
                      h.insertBefore(c2, r3);
                    }
                  })), s3.appendChild(l3), s3.appendChild(d2), r3.appendChild(s3), h.appendChild(r3);
                }));
              }, g = document.createElement("div");
              g.classList.add("magicfeedback-modal-backdrop"), g.setAttribute("dir", (0, n.isRtlLanguage)(s2) ? "rtl" : "ltr"), g.style.position = "fixed", g.style.top = "0", g.style.left = "0", g.style.width = "100vw", g.style.height = "100vh", g.style.background = "rgba(0,0,0,0.4)", g.style.display = "none", g.style.alignItems = "center", g.style.justifyContent = "center", g.style.zIndex = "9999";
              const y = document.createElement("div");
              y.classList.add("magicfeedback-modal"), y.style.background = "#fff", y.style.borderRadius = "8px", y.style.boxShadow = "0 8px 24px rgba(0,0,0,0.2)", y.style.maxWidth = "520px", y.style.width = "90%", y.style.maxHeight = "80vh", y.style.display = "flex", y.style.flexDirection = "column", y.style.overflow = "hidden", y.style.padding = "16px", y.style.position = "relative";
              const v = document.createElement("h5");
              v.classList.add("magicfeedback-modal-title"), v.style.flexShrink = "0", v.style.marginTop = "0";
              const b = () => Math.min(e5.length + 1, a2), E = () => {
                v.textContent = `${d("selectOptionNumber")}${b()}`;
              };
              E();
              const A = document.createElement("div");
              A.classList.add("magicfeedback-modal-list"), A.style.flex = "1 1 auto", A.style.overflowY = "auto", A.style.minHeight = "0", (r2 ? [...t4].sort((() => Math.random() - 0.5)) : [...t4]).forEach(((t5) => {
                const n2 = document.createElement("label");
                n2.classList.add("magicfeedback-modal-row");
                const r3 = document.createElement("input");
                r3.type = "checkbox", r3.classList.add("magicfeedback-input"), r3.name = `${i3}-selection`, r3.value = t5;
                const o4 = document.createElement("span");
                o4.textContent = t5, r3.addEventListener("change", (() => {
                  if (r3.checked) {
                    if (e5.length >= a2) return r3.checked = false, n2.classList.add("magicfeedback-warning"), void setTimeout((() => {
                      n2.classList.remove("magicfeedback-warning");
                    }), 800);
                    e5.push(t5);
                  } else {
                    const i4 = e5.indexOf(t5);
                    -1 !== i4 && e5.splice(i4, 1);
                  }
                  E(), C();
                })), n2.appendChild(r3), n2.appendChild(o4), A.appendChild(n2);
              }));
              const k = document.createElement("div");
              k.classList.add("magicfeedback-modal-actions"), k.style.flexShrink = "0";
              const T = document.createElement("div");
              T.classList.add("magicfeedback-modal-counter");
              const C = () => {
                const t5 = d("of");
                T.textContent = `${d("prioritized")} ${e5.length} ${t5} ${a2}`, u2.style.display = e5.length > 0 ? "block" : "none";
              };
              C();
              const P = document.createElement("button");
              P.type = "button", P.classList.add("magicfeedback-modal-close"), P.setAttribute("aria-label", d("cancel")), P.title = d("cancel"), P.textContent = "\xD7", P.style.position = "absolute", P.style.top = "8px", P.style.setProperty("inset-inline-end", "8px"), P.style.border = "none", P.style.background = "transparent", P.style.fontSize = "24px", P.style.cursor = "pointer";
              const S = () => {
                document.body.appendChild(g), g.style.display = "flex", E(), C();
              }, w = () => {
                g.style.display = "none", c.appendChild(g);
              };
              P.addEventListener("click", (() => {
                w();
              }));
              const O = document.createElement("button");
              return O.type = "button", O.textContent = d("confirm"), O.classList.add("magicfeedback-button"), O.classList.add("magicfeedback-button-primary"), O.addEventListener("click", (() => {
                w(), f();
              })), k.appendChild(T), k.appendChild(O), y.appendChild(P), y.appendChild(v), y.appendChild(A), y.appendChild(k), g.appendChild(y), p2.addEventListener("click", (() => {
                S();
              })), g.addEventListener("click", ((e6) => {
                e6.target === g && w();
              })), c.appendChild(o3), c.appendChild(m), c.appendChild(g), f(), c;
            }
            const u = document.createElement("ul");
            u.classList.add("magicfeedback-priority-list-list");
            const p = r2 ? [...t4].sort((() => Math.random() - 0.5)) : [...t4];
            return p.forEach(((e5, t5) => {
              const n2 = document.createElement("li");
              n2.classList.add("magicfeedback-priority-list-item"), n2.style.display = "flex", n2.style.justifyContent = "space-between", n2.style.alignItems = "center", n2.style.margin = "5px";
              const r3 = document.createElement("input");
              r3.classList.add("magicfeedback-input-magicfeedback-priority-list"), r3.classList.add("magicfeedback-input"), r3.type = "hidden", r3.id = `priority-list-${i3}`, r3.name = i3, r3.value = `${t5 + 1}. ${e5}`, n2.appendChild(r3);
              const o3 = document.createElement("label");
              o3.classList.add("magicfeedback-priority-list-item-label"), o3.textContent = `${t5 + 1}. ${e5}`, n2.appendChild(o3);
              const a3 = document.createElement("div");
              a3.style.display = "flex", a3.style.alignItems = "center", a3.style.justifyContent = "space-between";
              const s3 = document.createElement("img");
              s3.classList.add("magicfeedback-priority-list-arrow-up"), s3.src = "https://magicfeedback-c6458-dev.web.app/assets/arrow.svg", s3.style.width = "20px", s3.style.height = "20px", s3.style.cursor = "pointer", s3.style.margin = "0 5px", s3.style.color = "#000", s3.style.visibility = 0 === t5 ? "hidden" : "visible", s3.addEventListener("click", (() => {
                var t6, i4, a4, d2;
                const c2 = n2.previousElementSibling;
                if (c2) {
                  const m = Number(null === (t6 = r3.value) || void 0 === t6 ? void 0 : t6.split(".")[0]) - 1;
                  r3.value = `${m}. ${e5}`, o3.textContent = `${m}. ${e5}`, s3.style.visibility = 1 === m ? "hidden" : "visible", l3.style.visibility = m === p.length ? "hidden" : "visible";
                  const h = c2.querySelector(".magicfeedback-input-magicfeedback-priority-list"), f = c2.querySelector(".magicfeedback-priority-list-item-label"), g = c2.querySelector(".magicfeedback-priority-list-arrow-up"), y = c2.querySelector(".magicfeedback-priority-list-arrow-down");
                  if (h && f && g && y) {
                    const e6 = Number(null === (i4 = h.value) || void 0 === i4 ? void 0 : i4.split(".")[0]) + 1;
                    h.value = `${e6}.${null === (a4 = f.textContent) || void 0 === a4 ? void 0 : a4.split(".")[1]}`, f.textContent = `${e6}.${null === (d2 = f.textContent) || void 0 === d2 ? void 0 : d2.split(".")[1]}`, g.style.visibility = 1 === e6 ? "hidden" : "visible", y.style.visibility = e6 === p.length ? "hidden" : "visible";
                  }
                  u.insertBefore(n2, c2);
                }
              }));
              const l3 = document.createElement("img");
              l3.classList.add("magicfeedback-priority-list-arrow-down"), l3.src = "https://magicfeedback-c6458-dev.web.app/assets/arrow.svg", l3.style.width = "20px", l3.style.height = "20px", l3.style.cursor = "pointer", l3.style.margin = "0 5px", l3.style.color = "#000", l3.style.transform = "rotate(180deg)", l3.style.visibility = t5 === p.length - 1 ? "hidden" : "visible", l3.addEventListener("click", (() => {
                var t6, i4, a4;
                const d2 = n2.nextElementSibling;
                if (d2) {
                  const c2 = Number(null === (t6 = r3.value) || void 0 === t6 ? void 0 : t6.split(".")[0]) + 1;
                  r3.value = `${c2}. ${e5}`, o3.textContent = `${c2}. ${e5}`, s3.style.visibility = 1 === c2 ? "hidden" : "visible", l3.style.visibility = c2 === p.length ? "hidden" : "visible";
                  const m = d2.querySelector(".magicfeedback-input-magicfeedback-priority-list"), h = d2.querySelector(".magicfeedback-priority-list-item-label"), f = d2.querySelector(".magicfeedback-priority-list-arrow-up"), g = d2.querySelector(".magicfeedback-priority-list-arrow-down");
                  if (m && h && f && g) {
                    const e6 = Number(m.value.split(".")[0]) - 1;
                    m.value = `${e6}.${null === (i4 = h.textContent) || void 0 === i4 ? void 0 : i4.split(".")[1]}`, h.textContent = `${e6}.${null === (a4 = h.textContent) || void 0 === a4 ? void 0 : a4.split(".")[1]}`, f.style.visibility = 1 === e6 ? "hidden" : "visible", g.style.visibility = e6 === p.length ? "hidden" : "visible";
                  }
                  u.insertBefore(d2, n2);
                }
              })), a3.appendChild(s3), a3.appendChild(l3), n2.appendChild(a3), u.appendChild(n2);
            })), c.appendChild(u), c;
          })({ value: e3.value, ref: e3.ref, randomPosition: t3, limitPriority: (null === (r = e3.assets) || void 0 === r ? void 0 : r.limitPriority) || false, maxPriority: (null === (o = e3.assets) || void 0 === o ? void 0 : o.maxPriority) || 0, placeholder: (null === (a = e3.assets) || void 0 === a ? void 0 : a.placeholder) || "", language: i2 || "en" });
          return s.appendChild(l), { element: s, elementTypeClass: "magicfeedback-priority-list" };
        };
      }, 2626: (e2, t2, i) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.renderRatingEmoji = void 0;
        const n = i(2709), r = i(9039), o = "https://survey-dev.magicfeedback.io/assets/emojis";
        t2.renderRatingEmoji = ({ question: e3, url: t3, send: i2, urlParamValue: a }) => {
          const { ref: s, assets: l } = e3, d = document.createElement("div"), c = "magicfeedback-rating", u = document.createElement("div");
          u.classList.add("magicfeedback-rating-container");
          const p = (null == l ? void 0 : l.max) ? Number(null == l ? void 0 : l.max) : 5, m = (null == l ? void 0 : l.min) ? Number(null == l ? void 0 : l.min) : 1, h = (0, n.createRatingPlaceholder)(null == l ? void 0 : l.minPlaceholder, null == l ? void 0 : l.maxPlaceholder);
          for (let e4 = m; e4 <= p; e4++) {
            const n2 = document.createElement("div");
            n2.classList.add("magicfeedback-rating-option");
            const l2 = document.createElement("label");
            l2.htmlFor = `rating-${s}-${e4}`, l2.classList.add("magicfeedback-rating-option-label-container");
            const d2 = document.createElement("label");
            d2.htmlFor = `rating-${s}-${e4}`, d2.textContent = e4.toString();
            const h2 = document.createElement("img");
            if (h2.alt = `face-${s}-${e4}`, h2.className = `rating-image${e4}`, 0 === m && 10 === p) h2.src = `${t3}/${e4}.svg`, h2.onerror = () => h2.src = `${o}/${e4}.svg`;
            else if (1 === m && 5 === p) switch (e4) {
              case 1:
                h2.src = `${t3}/1.svg`, h2.onerror = () => h2.src = `${o}/1.svg`;
                break;
              case 2:
                h2.src = `${t3}/2.svg`, h2.onerror = () => h2.src = `${o}/2.svg`;
                break;
              case 3:
                h2.src = `${t3}/6.svg`, h2.onerror = () => h2.src = `${o}/6.svg`;
                break;
              case 4:
                h2.src = `${t3}/9.svg`, h2.onerror = () => h2.src = `${o}/9.svg`;
                break;
              case 5:
                h2.src = `${t3}/10.svg`, h2.onerror = () => h2.src = `${o}/10.svg`;
            }
            else {
              const i3 = Math.round(10 / (p - m) * (e4 - m));
              h2.src = `${t3}/${i3}.svg`, h2.onerror = () => h2.src = `${o}/${i3}.svg`;
            }
            const f = document.createElement("input");
            f.id = `rating-${s}-${e4}`, f.type = "radio", f.name = s, f.value = e4.toString(), f.classList.add(c), f.classList.add("magicfeedback-input"), (0, r.autoAdvanceOn)(f, i2), a && a === f.value && (f.checked = true), l2.appendChild(f), l2.appendChild(h2), l2.appendChild(d2), n2.appendChild(l2), u.appendChild(n2);
          }
          if ((null == l ? void 0 : l.extraOption) && (null == l ? void 0 : l.extraOptionText)) {
            const e4 = document.createElement("div");
            e4.classList.add("magicfeedback-rating-option");
            const t4 = document.createElement("label");
            t4.htmlFor = `rating-${s}-extra`, t4.classList.add("magicfeedback-rating-option-label-container");
            const n2 = document.createElement("label");
            n2.htmlFor = `rating-${s}-extra`, n2.textContent = null == l ? void 0 : l.extraOptionText;
            const o2 = document.createElement("img");
            o2.src = "https://magicfeedback-c6458-dev.web.app/assets/question.svg", o2.alt = `face-${s}-extra`, o2.className = "magicfeedback-rating-image-extra";
            const a2 = document.createElement("input");
            a2.id = `rating-${s}-extra`, a2.type = "radio", a2.name = s, a2.value = "-", a2.classList.add(c), a2.classList.add("magicfeedback-input"), (0, r.autoAdvanceOn)(a2, i2), t4.appendChild(a2), t4.appendChild(o2), t4.appendChild(n2), e4.appendChild(t4), u.appendChild(e4);
          }
          return h.childElementCount > 0 && u.appendChild(h), d.appendChild(u), { element: d, elementTypeClass: c };
        };
      }, 2255: (e2, t2, i) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.renderRatingNumber = void 0;
        const n = i(2709);
        t2.renderRatingNumber = ({ question: e3, order: t3, direction: i2, send: r, urlParamValue: o, language: a, isPhone: s, productId: l }) => {
          const d = "magicfeedback-rating-number";
          return { element: (0, n.createRatingNumberElement)(e3.ref, e3.assets, t3, i2, d, r, o, a, { legacy: (0, n.usesLegacyRatingNumber)(l), isPhone: s }), elementTypeClass: d };
        };
      }, 1042: (e2, t2, i) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.renderRatingStar = void 0;
        const n = i(2709);
        t2.renderRatingStar = ({ question: e3, send: t3, urlParamValue: i2 }) => {
          var r, o;
          const a = document.createElement("div"), s = (0, n.createStarRating)(e3.ref, null === (r = e3.assets) || void 0 === r ? void 0 : r.minPlaceholder, null === (o = e3.assets) || void 0 === o ? void 0 : o.maxPlaceholder, t3, i2);
          return a.appendChild(s), { element: a, elementTypeClass: "magicfeedback-rating-star" };
        };
      }, 2311: (e2, t2, i) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.renderSelect = void 0;
        const n = i(1366), r = i(7627);
        t2.renderSelect = ({ question: e3, format: t3, language: i2, urlParamValue: o }) => {
          const { title: a, value: s, defaultValue: l } = e3, d = document.createElement("select"), c = document.createElement("option");
          return c.value = "", c.text = "slim" === t3 ? (0, n.parseTitle)(a, i2) : l || (0, r.t)(i2, "select.placeholder"), c.disabled = true, c.selected = true, d.appendChild(c), s.forEach(((e4) => {
            const t4 = document.createElement("option");
            t4.value = e4, t4.text = e4, d.appendChild(t4);
          })), o && s.includes(o) && (d.value = o), { element: d, elementTypeClass: "magicfeedback-select" };
        };
      }, 8924: (e2, t2, i) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.renderText = void 0;
        const n = i(3262);
        t2.renderText = ({ language: e3, placeholderText: t3, urlParamValue: i2, send: r }) => {
          const o = document.createElement("input");
          return o.type = "text", o.placeholder = t3 || n.placeholder.answer(e3 || "en"), i2 && (o.value = i2), o.addEventListener("keyup", ((e4) => {
            e4.preventDefault(), "Enter" === e4.key && r && r();
          })), { element: o, elementTypeClass: "magicfeedback-text" };
        };
      }, 1724: (e2, t2, i) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.renderUploadFile = void 0;
        const n = i(8129);
        t2.renderUploadFile = ({ question: e3, language: t3 }) => (0, n.createUploadControl)(e3, t3, "file");
      }, 9169: (e2, t2, i) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.renderUploadImage = void 0;
        const n = i(8129);
        t2.renderUploadImage = ({ question: e3, language: t3 }) => (0, n.createUploadControl)(e3, t3, "image");
      }, 8129: function(e2, t2, i) {
        "use strict";
        var n = this && this.__awaiter || function(e3, t3, i2, n2) {
          return new (i2 || (i2 = Promise))((function(r2, o2) {
            function a2(e4) {
              try {
                l2(n2.next(e4));
              } catch (e5) {
                o2(e5);
              }
            }
            function s2(e4) {
              try {
                l2(n2.throw(e4));
              } catch (e5) {
                o2(e5);
              }
            }
            function l2(e4) {
              var t4;
              e4.done ? r2(e4.value) : (t4 = e4.value, t4 instanceof i2 ? t4 : new i2((function(e5) {
                e5(t4);
              }))).then(a2, s2);
            }
            l2((n2 = n2.apply(e3, t3 || [])).next());
          }));
        };
        Object.defineProperty(t2, "__esModule", { value: true }), t2.createUploadControl = t2.awaitUploadReady = t2.getUploadValues = t2.formatFileSize = void 0;
        const r = i(3262), o = i(1366), a = "__mfUploadValues", s = "__mfUploadReady";
        function l(e3) {
          if ("number" != typeof e3 || isNaN(e3)) return "";
          if (e3 < 1024) return `${e3} B`;
          const t3 = e3 / 1024;
          if (t3 < 1024) return `${t3 < 10 ? t3.toFixed(1) : Math.round(t3)} KB`;
          const i2 = t3 / 1024;
          return `${i2 < 10 ? i2.toFixed(1) : Math.round(i2)} MB`;
        }
        t2.formatFileSize = l, t2.getUploadValues = function(e3) {
          const t3 = e3[a];
          return Array.isArray(t3) ? t3 : [];
        }, t2.awaitUploadReady = function(e3) {
          return n(this, void 0, void 0, (function* () {
            if (!e3) return;
            const t3 = Array.from(e3.querySelectorAll(".magicfeedback-upload-native"));
            yield Promise.all(t3.map(((e4) => e4[s])).filter(Boolean));
          }));
        }, t2.createUploadControl = function(e3, t3, i2) {
          const { ref: n2, require: d, title: c, assets: u } = e3, p = "image" === i2 ? "magicfeedback-upload-image" : "magicfeedback-upload-file", m = (null == u ? void 0 : u.multiple) || false, h = m ? (null == u ? void 0 : u.maxFiles) || 0 : 1, f = Number(null == u ? void 0 : u.maxFileSize) > 0 ? Number(null == u ? void 0 : u.maxFileSize) : 0, g = 1024 * f * 1024, y = document.createElement("div");
          y.classList.add("magicfeedback-upload");
          const v = document.createElement("input");
          v.type = "file", "image" === i2 && (v.accept = "image/*"), v.multiple = m, v.required = d, v.name = n2, v.id = `magicfeedback-upload-input-${n2}`, v.classList.add(p), v.classList.add("magicfeedback-input"), v.classList.add("magicfeedback-upload-native"), v[a] = [], v[s] = Promise.resolve();
          const b = (0, o.parseTitle)(c, t3);
          b && v.setAttribute("aria-label", b);
          const E = document.createElement("div");
          E.classList.add("magicfeedback-upload-dropzone");
          const A = document.createElement("span");
          A.classList.add("magicfeedback-upload-icon"), A.innerHTML = "image" === i2 ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>' : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 16l-4-4-4 4"/><path d="M12 12v9"/><path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"/></svg>';
          const k = document.createElement("span");
          k.classList.add("magicfeedback-upload-cta"), k.textContent = r.placeholder.upload.cta(t3);
          const T = document.createElement("span");
          T.classList.add("magicfeedback-upload-hint"), T.textContent = (function(e4, t4, i3, n3, o2) {
            const a2 = [r.placeholder.upload.formats(e4, t4)];
            return i3 && n3 > 0 && a2.push(r.placeholder.upload.maxFiles(e4, n3)), o2 > 0 && a2.push(r.placeholder.upload.maxSize(e4, o2)), a2.filter(Boolean).join(" \xB7 ");
          })(t3, i2, m, h, f), E.appendChild(v), E.appendChild(A), E.appendChild(k), E.appendChild(T);
          const C = document.createElement("div");
          C.classList.add("magicfeedback-upload-error");
          const P = document.createElement("ul");
          P.classList.add("magicfeedback-upload-list"), y.appendChild(E), y.appendChild(C), y.appendChild(P);
          const S = /* @__PURE__ */ new WeakMap(), w = (e4) => {
            const t4 = S.get(e4);
            return t4 ? Promise.resolve(t4) : new Promise(((t5) => {
              const i3 = new FileReader(), n3 = (i4) => {
                const n4 = JSON.stringify({ name: e4.name, type: e4.type, size: e4.size, content: i4 });
                S.set(e4, n4), t5(n4);
              };
              i3.onload = () => n3("string" == typeof i3.result ? i3.result : ""), i3.onerror = () => n3(""), i3.readAsDataURL(e4);
            }));
          }, O = [], x = (e4) => {
            try {
              const t4 = h > 0 ? e4.slice(0, h) : e4, i3 = new DataTransfer();
              t4.forEach(((e5) => i3.items.add(e5))), v.files = i3.files;
            } catch (e5) {
            }
            !(function() {
              O.forEach(((e6) => URL.revokeObjectURL(e6))), O.length = 0, P.innerHTML = "";
              const e5 = Array.from(v.files || []);
              y.classList.toggle("magicfeedback-upload--has-files", e5.length > 0), e5.forEach(((e6, n3) => {
                const o2 = document.createElement("li");
                o2.classList.add("magicfeedback-upload-file-item");
                const a2 = document.createElement("span");
                if (a2.classList.add("magicfeedback-upload-thumb"), "image" === i2 && e6.type.startsWith("image/")) {
                  const t4 = URL.createObjectURL(e6);
                  O.push(t4);
                  const i3 = document.createElement("img");
                  i3.src = t4, i3.alt = e6.name, a2.appendChild(i3);
                } else a2.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></svg>';
                const s2 = document.createElement("span");
                s2.classList.add("magicfeedback-upload-file-info");
                const d2 = document.createElement("span");
                d2.classList.add("magicfeedback-upload-file-name"), d2.textContent = e6.name, d2.title = e6.name;
                const c2 = document.createElement("span");
                c2.classList.add("magicfeedback-upload-file-size"), c2.textContent = l(e6.size), s2.appendChild(d2), s2.appendChild(c2);
                const u2 = document.createElement("button");
                u2.type = "button", u2.classList.add("magicfeedback-upload-remove"), u2.setAttribute("aria-label", `${r.placeholder.upload.remove(t3)}: ${e6.name}`), u2.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>', u2.addEventListener("click", ((e7) => {
                  e7.preventDefault(), e7.stopPropagation(), x(Array.from(v.files || []).filter(((e8, t4) => t4 !== n3)));
                })), o2.appendChild(a2), o2.appendChild(s2), o2.appendChild(u2), P.appendChild(o2);
              }));
            })(), (() => {
              const e5 = Array.from(v.files || []), t4 = Promise.all(e5.map(w)).then(((e6) => {
                v[a] = e6;
              }));
              v[s] = t4;
            })();
          }, L = (e4) => {
            if (!e4.length) return C.textContent = "", void C.classList.remove("is-visible");
            const i3 = e4.map(((e5) => e5.name)).join(", ");
            C.textContent = `${r.placeholder.upload.tooLarge(t3, f)}: ${i3}`, C.classList.add("is-visible");
          }, N = (e4) => {
            if (!g) return { accepted: e4, rejected: [] };
            const t4 = [], i3 = [];
            return e4.forEach(((e5) => (e5.size <= g ? t4 : i3).push(e5))), { accepted: t4, rejected: i3 };
          };
          v.addEventListener("change", (() => {
            const { accepted: e4, rejected: t4 } = N(Array.from(v.files || []));
            L(t4), x(e4);
          }));
          const I = (e4) => {
            e4.preventDefault(), e4.stopPropagation();
          };
          return ["dragenter", "dragover"].forEach(((e4) => E.addEventListener(e4, ((e5) => {
            I(e5), E.classList.add("is-dragover");
          })))), ["dragleave", "dragend"].forEach(((e4) => E.addEventListener(e4, ((e5) => {
            I(e5), E.classList.remove("is-dragover");
          })))), E.addEventListener("drop", ((e4) => {
            I(e4), E.classList.remove("is-dragover");
            const t4 = e4.dataTransfer;
            let n3 = t4 ? Array.from(t4.files) : [];
            if ("image" === i2 && (n3 = n3.filter(((e5) => e5.type.startsWith("image/")))), !n3.length) return;
            const { accepted: r2, rejected: o2 } = N(n3);
            if (L(o2), !r2.length) return;
            const a2 = m ? Array.from(v.files || []) : [];
            x(a2.concat(r2));
          })), { element: y, elementTypeClass: p };
        };
      }, 4759: function(e2, t2, i) {
        "use strict";
        var n = this && this.__awaiter || function(e3, t3, i2, n2) {
          return new (i2 || (i2 = Promise))((function(r2, o2) {
            function a2(e4) {
              try {
                l2(n2.next(e4));
              } catch (e5) {
                o2(e5);
              }
            }
            function s2(e4) {
              try {
                l2(n2.throw(e4));
              } catch (e5) {
                o2(e5);
              }
            }
            function l2(e4) {
              var t4;
              e4.done ? r2(e4.value) : (t4 = e4.value, t4 instanceof i2 ? t4 : new i2((function(e5) {
                e5(t4);
              }))).then(a2, s2);
            }
            l2((n2 = n2.apply(e3, t3 || [])).next());
          }));
        }, r = this && this.__importDefault || function(e3) {
          return e3 && e3.__esModule ? e3 : { default: e3 };
        };
        Object.defineProperty(t2, "__esModule", { value: true }), t2.nextAgentTurn = t2.startAgentSurvey = void 0;
        const o = r(i(6539)), a = i(9071), s = i(5407), l = i(3501);
        function d(e3, t3, i2, r2, s2) {
          var d2;
          return n(this, void 0, void 0, (function* () {
            let n2;
            try {
              n2 = yield (0, o.default)(e3 + t3, { method: "POST", headers: Object.assign({ "Content-Type": "application/json" }, a.header), body: JSON.stringify(i2) });
            } catch (e4) {
              throw r2.err(`[agentSurvey/${s2}] network error`, e4), new l.AgentApiError("NETWORK", (null == e4 ? void 0 : e4.message) || "Network error");
            }
            if (!n2.ok) {
              let e4 = null;
              try {
                e4 = yield n2.json();
              } catch (e5) {
              }
              const t4 = (0, l.mapAgentStatus)(n2.status, s2);
              throw r2.err(`[agentSurvey/${s2}] ${n2.status}`, e4), new l.AgentApiError(t4, (null === (d2 = null == e4 ? void 0 : e4.error) || void 0 === d2 ? void 0 : d2.message) || (null == e4 ? void 0 : e4.message) || n2.statusText, n2.status, "RATE_LIMITED" === t4 ? (function(e5) {
                var t5, i3;
                const n3 = null === (i3 = null === (t5 = null == e5 ? void 0 : e5.headers) || void 0 === t5 ? void 0 : t5.get) || void 0 === i3 ? void 0 : i3.call(t5, "Retry-After"), r3 = n3 ? Number(n3) : NaN;
                return Number.isFinite(r3) && r3 > 0 ? 1e3 * r3 : 6e4;
              })(n2) : void 0, e4);
            }
            try {
              const e4 = yield n2.json();
              return r2.log(`[agentSurvey/${s2}] ok`, e4), e4;
            } catch (e4) {
              throw new l.AgentApiError("MALFORMED", "Unreadable response body", n2.status);
            }
          }));
        }
        t2.startAgentSurvey = function(e3, t3, i2) {
          return d(e3, s.endpoints.sdk.agentSurveyStart, t3, i2, "start");
        }, t2.nextAgentTurn = function(e3, t3, i2) {
          return d(e3, s.endpoints.sdk.agentSurveyNext, t3, i2, "next");
        };
      }, 3501: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.mapAgentStatus = t2.AgentApiError = void 0;
        class i extends Error {
          constructor(e3, t3, n, r, o) {
            super(t3), this.kind = e3, this.status = n, this.retryAfterMs = r, this.body = o, this.name = "AgentApiError", Object.setPrototypeOf(this, i.prototype);
          }
          get retryable() {
            return "RATE_LIMITED" === this.kind || "AI_UNAVAILABLE" === this.kind || "NETWORK" === this.kind;
          }
        }
        t2.AgentApiError = i, t2.mapAgentStatus = function(e3, t3) {
          return 429 === e3 ? "RATE_LIMITED" : 406 === e3 || 401 === e3 || 403 === e3 ? "AUTH" : 404 === e3 ? "NOT_FOUND" : 400 === e3 || 422 === e3 ? "BAD_CONFIG" : e3 >= 500 ? "start" === t3 ? "AI_UNAVAILABLE" : "NETWORK" : "MALFORMED";
        };
      }, 1351: (e2, t2, i) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.encodeAnswer = t2.toAgentStep = t2.ratingBounds = t2.mapAgentType = t2.DEFAULT_ANSWER_DELIMITER = void 0;
        const n = i(4760), r = i(1366);
        t2.DEFAULT_ANSWER_DELIMITER = ", ";
        const o = [n.FEEDBACKAPPANSWERTYPE.RADIO, n.FEEDBACKAPPANSWERTYPE.MULTIPLECHOICE, n.FEEDBACKAPPANSWERTYPE.SELECT, n.FEEDBACKAPPANSWERTYPE.MULTIPLECHOISE_IMAGE], a = Object.values(n.FEEDBACKAPPANSWERTYPE);
        function s(e3, t3, i2) {
          var s2, l2, d2;
          const c2 = String(e3 || "").trim().toUpperCase();
          return "RATING" === c2 ? n.FEEDBACKAPPANSWERTYPE.RATING_NUMBER : c2 === n.FEEDBACKAPPANSWERTYPE.CONTACT ? (null === (s2 = i2.log) || void 0 === s2 || s2.log("[agentSurvey] CONTACT has no renderer, falling back to TEXT"), n.FEEDBACKAPPANSWERTYPE.TEXT) : a.includes(c2) ? o.includes(c2) && 0 === t3.length ? (null === (d2 = i2.log) || void 0 === d2 || d2.err(`[agentSurvey] ${c2} arrived with no options, falling back to TEXT`), n.FEEDBACKAPPANSWERTYPE.TEXT) : c2 !== n.FEEDBACKAPPANSWERTYPE.BOOLEAN || 2 !== t3.length || (function(e4, t4) {
            if (2 !== e4.length) return false;
            const i3 = e4.map(((e5) => String(e5).trim().toLowerCase())), n2 = (0, r.getBooleanOptions)(t4).map(((e5) => e5.toLowerCase())), o2 = ["yes", "no"];
            return i3[0] === o2[0] && i3[1] === o2[1] || i3[0] === n2[0] && i3[1] === n2[1];
          })(t3, i2.language) ? c2 : n.FEEDBACKAPPANSWERTYPE.RADIO : (null === (l2 = i2.log) || void 0 === l2 || l2.err(`[agentSurvey] unknown question type "${e3}", falling back to TEXT`), n.FEEDBACKAPPANSWERTYPE.TEXT);
        }
        function l(e3) {
          const t3 = e3.map(Number).filter(((e4) => Number.isFinite(e4)));
          return t3.length >= 2 ? { min: Math.min(...t3), max: Math.max(...t3) } : { min: 1, max: 5 };
        }
        function d(e3, t3, i2) {
          const r2 = { randomPosition: false, direction: "row", order: "ltr" };
          return e3 !== n.FEEDBACKAPPANSWERTYPE.RATING_NUMBER && e3 !== n.FEEDBACKAPPANSWERTYPE.RATING_EMOJI || Object.assign(r2, l(t3)), e3 === n.FEEDBACKAPPANSWERTYPE.LONGTEXT && (r2.maxCharacters = 0), Object.assign(Object.assign({}, r2), (null == i2 ? void 0 : i2.assets) || {});
        }
        function c(e3, t3, i2) {
          var n2, r2, o2, a2;
          const { full: l2, title: c2 } = t3, u = [...null !== (r2 = null !== (n2 = e3.questionValues) && void 0 !== n2 ? n2 : null == l2 ? void 0 : l2.value) && void 0 !== r2 ? r2 : []], p = s(null !== (o2 = null == l2 ? void 0 : l2.type) && void 0 !== o2 ? o2 : e3.questionType, u, i2), m = e3.questionRef || (null == l2 ? void 0 : l2.ref) || `agent-q-${e3.currentTurn}`;
          return { id: (null == l2 ? void 0 : l2.id) || `agent-${i2.sessionId}-${e3.currentTurn}`, title: c2 || "", type: p, questionType: { conf: null }, ref: m, require: null === (a2 = null == l2 ? void 0 : l2.require) || void 0 === a2 || a2, external_id: (null == l2 ? void 0 : l2.external_id) || "", value: u, defaultValue: (null == l2 ? void 0 : l2.defaultValue) || "", followup: false, position: e3.currentTurn, assets: d(p, u, l2), refMetric: (null == l2 ? void 0 : l2.refMetric) || "", integrationId: i2.integrationId, integrationPageId: "", status: "ACTIVE" };
        }
        t2.mapAgentType = s, t2.ratingBounds = l, t2.toAgentStep = function(e3, t3) {
          var i2, r2, o2;
          const a2 = e3, s2 = e3.currentTurn, l2 = e3.maxTurns, d2 = a2.coverageSummary, u = (e4) => ({ kind: "END", reason: e4, currentTurn: s2, maxTurns: l2, coverageSummary: d2 });
          if (a2.answerType === n.AGENT_ANSWER_TYPE_BLOCKED) return u("BLOCKED");
          if (true === a2.shouldEnd) return u("SHOULD_END");
          const p = (function(e4) {
            const t4 = e4.question && "object" == typeof e4.question ? e4.question : e4.nextQuestion && "object" == typeof e4.nextQuestion ? e4.nextQuestion : null;
            if (t4) {
              const e5 = t4, i3 = e5.title;
              return { full: e5, title: "string" == typeof i3 ? i3 : i3 ? JSON.stringify(i3) : null };
            }
            return { full: null, title: "string" == typeof e4.nextQuestion ? e4.nextQuestion : null };
          })(e3);
          return "NONE" === String(null !== (o2 = null !== (r2 = null === (i2 = p.full) || void 0 === i2 ? void 0 : i2.type) && void 0 !== r2 ? r2 : e3.questionType) && void 0 !== o2 ? o2 : "").trim().toUpperCase() ? u("TYPE_NONE") : p.title && p.title.trim() ? { kind: "QUESTION", question: c(e3, p, t3), isFromBase: true === e3.isFromBase, currentTurn: s2, maxTurns: l2, topic: a2.topic, coverageGaps: e3.coverageGaps, coverageSummary: d2 } : u("NO_QUESTION");
        }, t2.encodeAnswer = function(e3, i2, n2 = t2.DEFAULT_ANSWER_DELIMITER) {
          const r2 = i2.ref, o2 = (e4) => e4.flatMap(((e5) => Array.isArray(e5.value) ? e5.value : [e5.value])).map(((e5) => "string" == typeof e5 ? e5 : JSON.stringify(e5))).map(((e5) => (e5 || "").trim())).filter(((e5) => "" !== e5)), a2 = o2(e3.filter(((e4) => e4.key === r2))), s2 = o2(e3.filter(((e4) => e4.key === `extra-option-${r2}`)));
          return [a2.filter(((e4, t3) => a2.indexOf(e4) === t3)).join(n2), s2.join(n2)].filter(((e4) => "" !== e4)).join(n2);
        };
      }, 5349: (e2, t2, i) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.scrapeInputs = void 0;
        const n = i(8129);
        t2.scrapeInputs = function(e3) {
          const t3 = e3.querySelectorAll(".magicfeedback-input"), i2 = [], r = {};
          return t3.forEach(((e4) => {
            var t4;
            const o = e4, a = o.name;
            if (!a) return;
            const s = o.type;
            if (("radio" === s || "checkbox" === s) && !o.checked) return;
            const l = o.value, d = o.classList[0];
            if ((null == d ? void 0 : d.includes("magicfeedback-priority-list")) || (null === (t4 = o.id) || void 0 === t4 ? void 0 : t4.startsWith("priority-list-"))) return r[a] || (r[a] = []), void r[a].push(l);
            if (null == d ? void 0 : d.includes("magicfeedback-upload")) {
              const e5 = (0, n.getUploadValues)(o);
              return void (e5.length && i2.push({ key: a, value: e5 }));
            }
            const c = "magicfeedback-consent" === d ? o.checked.toString() : l;
            null != c && i2.push({ key: a, value: [c] });
          })), Object.entries(r).forEach((([e4, t4]) => {
            const n2 = t4.slice().sort(((e5, t5) => Number(e5.split(".")[0]) - Number(t5.split(".")[0])));
            i2.push({ key: e4, value: n2 });
          })), i2;
        };
      }, 7627: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.t = t2.isLanguageSupported = t2.isRtlLanguage = t2.hasOwnTranslation = t2.TRANSLATION_KEYS = t2.normalizeLanguage = t2.RTL_LANGUAGES = t2.AVAILABLE_LANGUAGES = t2.SUPPORTED_LANGUAGES = void 0;
        const i = { "placeholder.answer": "Write your answer here...", "placeholder.number": "Write your number here...", "placeholder.email": "Write your email here...", "placeholder.date": "Write your date here...", "placeholder.password": "Write your password here...", "pointSystem.error": "The total points must be 100 %", "boolean.yes": "Yes", "boolean.no": "No", "upload.cta": "Drag & drop or click to upload", "upload.imagesOnly": "Images only", "upload.anyFileType": "Any file type", "upload.maxFiles": "Max {n} files", "upload.maxSize": "Max {mb} MB", "upload.tooLarge": "File is too large (max {mb} MB)", "upload.remove": "Remove", "select.placeholder": "Select an option", "rating.ariaLabel": "Rating", "maxDiff.best": "Most important", "maxDiff.worst": "Least important", "maxDiff.setProgress": "Block {k} of {n}", "priority.selectUpTo": "Select up to", "priority.options": "options", "priority.thenOrder": "and then order them", "priority.selectOptions": "Select options", "priority.cancel": "Cancel", "priority.confirm": "Confirm", "priority.selectOptionNumber": "Select option #", "priority.prioritized": "Prioritized", "priority.of": "of", "priority.instruction": "Your priority list can be seen below. If you wish, you can rearrange your choices using the arrows. Click 'Next' to confirm your selection and proceed.", "action.send": "Send", "action.back": "Back", "action.next": "Next", "action.start": "Go!", "message.success": "Thank you for your feedback!", "message.blocked": "Thanks for your time - we'll end the conversation here.", "message.required": "Please answer before continuing.", "message.rateLimit": "Too many requests. Retrying in {seconds}s..." }, n = { en: i, es: { "placeholder.answer": "Escribe tu respuesta aqu\xED...", "placeholder.number": "Escribe tu n\xFAmero aqu\xED...", "placeholder.email": "Escribe tu correo electr\xF3nico aqu\xED...", "placeholder.date": "Escribe tu fecha aqu\xED...", "placeholder.password": "Escribe tu contrase\xF1a aqu\xED...", "pointSystem.error": "El total de puntos debe ser 100 %", "boolean.yes": "S\xED", "boolean.no": "No", "upload.cta": "Arrastra y suelta o haz clic para subir", "upload.imagesOnly": "Solo im\xE1genes", "upload.anyFileType": "Cualquier tipo de archivo", "upload.maxFiles": "M\xE1x. {n} archivos", "upload.maxSize": "M\xE1x. {mb} MB", "upload.tooLarge": "Archivo demasiado grande (m\xE1x. {mb} MB)", "upload.remove": "Eliminar", "select.placeholder": "Selecciona una opci\xF3n", "rating.ariaLabel": "Valoraci\xF3n", "maxDiff.best": "M\xE1s importante", "maxDiff.worst": "Menos importante", "maxDiff.setProgress": "Bloque {k} de {n}", "priority.selectUpTo": "Selecciona hasta", "priority.options": "opciones", "priority.thenOrder": "y luego ord\xE9nalas", "priority.selectOptions": "Seleccionar opciones", "priority.cancel": "Cancelar", "priority.confirm": "Confirmar", "priority.selectOptionNumber": "Selecciona la opci\xF3n #", "priority.prioritized": "Priorizadas", "priority.of": "de", "priority.instruction": 'Tu lista priorizada se muestra abajo. Si deseas, puedes reordenar las opciones con las flechas. Haz clic en "Siguiente" para confirmar y continuar.', "action.send": "Enviar", "action.back": "Atr\xE1s", "action.next": "Siguiente", "action.start": "\xA1Empezar!", "message.success": "\xA1Gracias por tus comentarios!", "message.blocked": "Gracias por tu tiempo, terminamos aqu\xED la conversaci\xF3n.", "message.required": "Por favor, responde antes de continuar.", "message.rateLimit": "Demasiadas solicitudes. Reintentando en {seconds} s..." }, de: { "placeholder.answer": "Schreiben Sie hier Ihre Antwort...", "placeholder.number": "Geben Sie hier Ihre Zahl ein...", "placeholder.email": "Geben Sie hier Ihre E-Mail-Adresse ein...", "placeholder.date": "Geben Sie hier Ihr Datum ein...", "placeholder.password": "Geben Sie hier Ihr Passwort ein...", "pointSystem.error": "Die Gesamtpunktzahl muss 100 % betragen", "boolean.yes": "Ja", "boolean.no": "Nein", "upload.cta": "Ziehen Sie Dateien hierher oder klicken Sie zum Hochladen", "upload.imagesOnly": "Nur Bilder", "upload.anyFileType": "Beliebiger Dateityp", "upload.maxFiles": "Max. {n} Dateien", "upload.maxSize": "Max. {mb} MB", "upload.tooLarge": "Datei ist zu gro\xDF (max. {mb} MB)", "upload.remove": "Entfernen", "select.placeholder": "Option ausw\xE4hlen", "rating.ariaLabel": "Bewertung", "maxDiff.best": "Am wichtigsten", "maxDiff.worst": "Am wenigsten wichtig", "maxDiff.setProgress": "Block {k} von {n}", "priority.selectUpTo": "W\xE4hlen Sie bis zu", "priority.options": "Optionen", "priority.thenOrder": "und ordnen Sie sie dann", "priority.selectOptions": "Optionen ausw\xE4hlen", "priority.cancel": "Abbrechen", "priority.confirm": "Best\xE4tigen", "priority.selectOptionNumber": "W\xE4hlen Sie Option #", "priority.prioritized": "Priorisiert", "priority.of": "von", "priority.instruction": 'Ihre Priorit\xE4tenliste wird unten angezeigt. Wenn Sie m\xF6chten, k\xF6nnen Sie Ihre Auswahl mit den Pfeilen neu anordnen. Klicken Sie auf "Weiter", um Ihre Auswahl zu best\xE4tigen und fortzufahren.', "action.send": "Senden", "action.back": "Zur\xFCck", "action.next": "Weiter", "action.start": "Los!", "message.success": "Vielen Dank f\xFCr Ihr Feedback!", "message.blocked": "Danke f\xFCr Ihre Zeit - wir beenden das Gespr\xE4ch hier.", "message.required": "Bitte antworten Sie, bevor Sie fortfahren.", "message.rateLimit": "Zu viele Anfragen. Erneuter Versuch in {seconds} s..." }, fr: { "placeholder.answer": "\xC9crivez votre r\xE9ponse ici...", "placeholder.number": "\xC9crivez votre nombre ici...", "placeholder.email": "\xC9crivez votre e-mail ici...", "placeholder.date": "\xC9crivez votre date ici...", "placeholder.password": "\xC9crivez votre mot de passe ici...", "pointSystem.error": "Le total des points doit \xEAtre de 100 %", "boolean.yes": "Oui", "boolean.no": "Non", "upload.cta": "Glissez-d\xE9posez ou cliquez pour t\xE9l\xE9verser", "upload.imagesOnly": "Images uniquement", "upload.anyFileType": "Tout type de fichier", "upload.maxFiles": "Max. {n} fichiers", "upload.maxSize": "Max. {mb} Mo", "upload.tooLarge": "Fichier trop volumineux (max. {mb} Mo)", "upload.remove": "Supprimer", "select.placeholder": "S\xE9lectionnez une option", "rating.ariaLabel": "\xC9valuation", "maxDiff.best": "Le plus important", "maxDiff.worst": "Le moins important", "maxDiff.setProgress": "Bloc {k} sur {n}", "priority.selectUpTo": "S\xE9lectionnez jusqu'\xE0", "priority.options": "options", "priority.thenOrder": "puis classez-les", "priority.selectOptions": "S\xE9lectionner des options", "priority.cancel": "Annuler", "priority.confirm": "Confirmer", "priority.selectOptionNumber": "S\xE9lectionnez l'option #", "priority.prioritized": "Prioris\xE9es", "priority.of": "sur", "priority.instruction": `Votre liste de priorit\xE9s est affich\xE9e ci-dessous. Si vous le souhaitez, vous pouvez r\xE9organiser vos choix \xE0 l'aide des fl\xE8ches. Cliquez sur "Suivant" pour confirmer votre s\xE9lection et continuer.`, "action.send": "Envoyer", "action.back": "Retour", "action.next": "Suivant", "action.start": "C'est parti !", "message.success": "Merci pour votre retour !", "message.blocked": "Merci pour votre temps, nous terminons la conversation ici.", "message.required": "Veuillez r\xE9pondre avant de continuer.", "message.rateLimit": "Trop de requ\xEAtes. Nouvelle tentative dans {seconds} s..." }, pt: { "placeholder.answer": "Escreva sua resposta aqui...", "placeholder.number": "Escreva seu n\xFAmero aqui...", "placeholder.email": "Escreva seu e-mail aqui...", "placeholder.date": "Escreva sua data aqui...", "placeholder.password": "Escreva sua senha aqui...", "pointSystem.error": "O total de pontos deve ser 100 %", "boolean.yes": "Sim", "boolean.no": "N\xE3o", "upload.cta": "Arraste e solte ou clique para enviar", "upload.imagesOnly": "Somente imagens", "upload.anyFileType": "Qualquer tipo de arquivo", "upload.maxFiles": "M\xE1x. {n} arquivos", "upload.maxSize": "M\xE1x. {mb} MB", "upload.tooLarge": "Arquivo muito grande (m\xE1x. {mb} MB)", "upload.remove": "Remover", "select.placeholder": "Selecione uma op\xE7\xE3o", "rating.ariaLabel": "Avalia\xE7\xE3o", "maxDiff.best": "Mais importante", "maxDiff.worst": "Menos importante", "maxDiff.setProgress": "Bloco {k} de {n}", "priority.selectUpTo": "Selecione at\xE9", "priority.options": "op\xE7\xF5es", "priority.thenOrder": "e depois ordene-as", "priority.selectOptions": "Selecionar op\xE7\xF5es", "priority.cancel": "Cancelar", "priority.confirm": "Confirmar", "priority.selectOptionNumber": "Selecione a op\xE7\xE3o #", "priority.prioritized": "Priorizadas", "priority.of": "de", "priority.instruction": 'Sua lista de prioridades pode ser vista abaixo. Se quiser, voc\xEA pode reorganizar suas escolhas usando as setas. Clique em "Pr\xF3ximo" para confirmar sua sele\xE7\xE3o e continuar.', "action.send": "Enviar", "action.back": "Voltar", "action.next": "Pr\xF3ximo", "action.start": "Come\xE7ar!", "message.success": "Obrigado pelo seu feedback!", "message.blocked": "Obrigado pelo seu tempo, encerramos a conversa por aqui.", "message.required": "Responda antes de continuar.", "message.rateLimit": "Muitas solicita\xE7\xF5es. Tentando novamente em {seconds} s..." }, da: { "placeholder.answer": "Skriv dit svar her...", "placeholder.number": "Skriv dit nummer her...", "placeholder.email": "Skriv din e-mail her...", "placeholder.date": "Skriv din dato her...", "placeholder.password": "Skriv dit kodeord her...", "pointSystem.error": "Samlet antal point skal v\xE6re 100 %", "boolean.yes": "Ja", "boolean.no": "Nej", "upload.cta": "Tr\xE6k og slip eller klik for at uploade", "upload.imagesOnly": "Kun billeder", "upload.anyFileType": "Enhver filtype", "upload.maxFiles": "Maks. {n} filer", "upload.maxSize": "Maks. {mb} MB", "upload.tooLarge": "Filen er for stor (maks. {mb} MB)", "upload.remove": "Fjern", "select.placeholder": "V\xE6lg en mulighed", "rating.ariaLabel": "Bed\xF8mmelse", "maxDiff.best": "Vigtigst", "maxDiff.worst": "Mindst vigtigt", "maxDiff.setProgress": "Blok {k} af {n}", "priority.selectUpTo": "V\xE6lg op til", "priority.options": "muligheder", "priority.thenOrder": "og sorter dem derefter", "priority.selectOptions": "V\xE6lg muligheder", "priority.cancel": "Annuller", "priority.confirm": "Bekr\xE6ft", "priority.selectOptionNumber": "V\xE6lg mulighed #", "priority.prioritized": "Prioriteret", "priority.of": "af", "priority.instruction": 'Din prioritetsliste vises nedenfor. Hvis du \xF8nsker det, kan du omarrangere dine valg ved hj\xE6lp af pilene. Klik p\xE5 "N\xE6ste" for at bekr\xE6fte dit valg og forts\xE6tte.', "action.send": "Send", "action.back": "Tilbage", "action.next": "N\xE6ste", "action.start": "Start!", "message.success": "Tak for din feedback!", "message.blocked": "Tak for din tid - vi afslutter samtalen her.", "message.required": "Svar venligst, f\xF8r du forts\xE6tter.", "message.rateLimit": "For mange foresp\xF8rgsler. Pr\xF8ver igen om {seconds} s..." }, fi: { "placeholder.answer": "Kirjoita vastauksesi t\xE4h\xE4n...", "placeholder.number": "Kirjoita numerosi t\xE4h\xE4n...", "placeholder.email": "Kirjoita s\xE4hk\xF6postiosoitteesi t\xE4h\xE4n...", "placeholder.date": "Kirjoita p\xE4iv\xE4m\xE4\xE4r\xE4si t\xE4h\xE4n...", "placeholder.password": "Kirjoita salasanasi t\xE4h\xE4n...", "pointSystem.error": "Kokonaispisteiden on oltava 100 %", "boolean.yes": "Kyll\xE4", "boolean.no": "Ei", "upload.cta": "Ved\xE4 ja pudota tai napsauta ladataksesi", "upload.imagesOnly": "Vain kuvat", "upload.anyFileType": "Mik\xE4 tahansa tiedostotyyppi", "upload.maxFiles": "Enint\xE4\xE4n {n} tiedostoa", "upload.maxSize": "Enint\xE4\xE4n {mb} MB", "upload.tooLarge": "Tiedosto on liian suuri (enint\xE4\xE4n {mb} MB)", "upload.remove": "Poista", "select.placeholder": "Valitse vaihtoehto", "rating.ariaLabel": "Arvio", "maxDiff.best": "T\xE4rkein", "maxDiff.worst": "V\xE4hiten t\xE4rke\xE4", "maxDiff.setProgress": "Osa {k}/{n}", "priority.selectUpTo": "Valitse enint\xE4\xE4n", "priority.options": "vaihtoehtoa", "priority.thenOrder": "ja j\xE4rjest\xE4 ne sitten", "priority.selectOptions": "Valitse vaihtoehdot", "priority.cancel": "Peruuta", "priority.confirm": "Vahvista", "priority.selectOptionNumber": "Valitse vaihtoehto #", "priority.prioritized": "Priorisoitu", "priority.of": " / ", "priority.instruction": 'Prioriteettilistasi n\xE4kyy alla. Voit halutessasi j\xE4rjest\xE4\xE4 valinnat uudelleen nuolien avulla. Napsauta "Seuraava" vahvistaaksesi valinnan ja jatkaaksesi.', "action.send": "L\xE4het\xE4", "action.back": "Takaisin", "action.next": "Seuraava", "action.start": "Aloita!", "message.success": "Kiitos palautteestasi!", "message.blocked": "Kiitos ajastasi - lopetamme keskustelun t\xE4h\xE4n.", "message.required": "Vastaa ennen jatkamista.", "message.rateLimit": "Liikaa pyynt\xF6j\xE4. Yritet\xE4\xE4n uudelleen {seconds} s kuluttua..." }, no: { "placeholder.answer": "Skriv svaret ditt her...", "placeholder.number": "Skriv nummeret ditt her...", "placeholder.email": "Skriv e-posten din her...", "placeholder.date": "Skriv datoen din her...", "placeholder.password": "Skriv passordet ditt her...", "pointSystem.error": "Totalt antall poeng m\xE5 v\xE6re 100 %", "boolean.yes": "Ja", "boolean.no": "Nei", "upload.cta": "Dra og slipp eller klikk for \xE5 laste opp", "upload.imagesOnly": "Kun bilder", "upload.anyFileType": "Alle filtyper", "upload.maxFiles": "Maks {n} filer", "upload.maxSize": "Maks {mb} MB", "upload.tooLarge": "Filen er for stor (maks {mb} MB)", "upload.remove": "Fjern", "select.placeholder": "Velg et alternativ", "rating.ariaLabel": "Vurdering", "maxDiff.best": "Viktigst", "maxDiff.worst": "Minst viktig", "maxDiff.setProgress": "Blokk {k} av {n}", "priority.selectUpTo": "Velg opptil", "priority.options": "alternativer", "priority.thenOrder": "og ordne dem deretter", "priority.selectOptions": "Velg alternativer", "priority.cancel": "Avbryt", "priority.confirm": "Bekreft", "priority.selectOptionNumber": "Velg alternativ #", "priority.prioritized": "Prioritert", "priority.of": "av", "priority.instruction": 'Prioriteringslisten din vises nedenfor. Hvis du \xF8nsker det, kan du ordne valgene dine ved hjelp av pilene. Klikk p\xE5 "Neste" for \xE5 bekrefte valget ditt og fortsette.', "action.send": "Send", "action.back": "Tilbake", "action.next": "Neste", "action.start": "Start!", "message.success": "Takk for tilbakemeldingen!", "message.blocked": "Takk for tiden din - vi avslutter samtalen her.", "message.required": "Vennligst svar f\xF8r du fortsetter.", "message.rateLimit": "For mange foresp\xF8rsler. Pr\xF8ver igjen om {seconds} s..." }, sv: { "placeholder.answer": "Skriv ditt svar h\xE4r...", "placeholder.number": "Skriv ditt nummer h\xE4r...", "placeholder.email": "Skriv din e-post h\xE4r...", "placeholder.date": "Skriv ditt datum h\xE4r...", "placeholder.password": "Skriv ditt l\xF6senord h\xE4r...", "pointSystem.error": "Totala po\xE4ng m\xE5ste vara 100 %", "boolean.yes": "Ja", "boolean.no": "Nej", "upload.cta": "Dra och sl\xE4pp eller klicka f\xF6r att ladda upp", "upload.imagesOnly": "Endast bilder", "upload.anyFileType": "Alla filtyper", "upload.maxFiles": "Max {n} filer", "upload.maxSize": "Max {mb} MB", "upload.tooLarge": "Filen \xE4r f\xF6r stor (max {mb} MB)", "upload.remove": "Ta bort", "select.placeholder": "V\xE4lj ett alternativ", "rating.ariaLabel": "Betyg", "maxDiff.best": "Viktigast", "maxDiff.worst": "Minst viktig", "maxDiff.setProgress": "Block {k} av {n}", "priority.selectUpTo": "V\xE4lj upp till", "priority.options": "alternativ", "priority.thenOrder": "och ordna dem sedan", "priority.selectOptions": "V\xE4lj alternativ", "priority.cancel": "Avbryt", "priority.confirm": "Bekr\xE4fta", "priority.selectOptionNumber": "V\xE4lj alternativ #", "priority.prioritized": "Prioriterat", "priority.of": "av", "priority.instruction": 'Din prioriteringslista visas nedan. Om du vill kan du ordna om dina val med hj\xE4lp av pilarna. Klicka p\xE5 "N\xE4sta" f\xF6r att bekr\xE4fta ditt val och forts\xE4tta.', "action.send": "Skicka", "action.back": "Tillbaka", "action.next": "N\xE4sta", "action.start": "K\xF6r!", "message.success": "Tack f\xF6r din feedback!", "message.blocked": "Tack f\xF6r din tid - vi avslutar samtalet h\xE4r.", "message.required": "Svara innan du forts\xE4tter.", "message.rateLimit": "F\xF6r m\xE5nga f\xF6rfr\xE5gningar. F\xF6rs\xF6ker igen om {seconds} s..." }, ar: { "placeholder.answer": "\u0627\u0643\u062A\u0628 \u0625\u062C\u0627\u0628\u062A\u0643 \u0647\u0646\u0627...", "placeholder.number": "\u0627\u0643\u062A\u0628 \u0631\u0642\u0645\u0643 \u0647\u0646\u0627...", "placeholder.email": "\u0627\u0643\u062A\u0628 \u0628\u0631\u064A\u062F\u0643 \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0647\u0646\u0627...", "placeholder.date": "\u0627\u0643\u062A\u0628 \u062A\u0627\u0631\u064A\u062E\u0643 \u0647\u0646\u0627...", "placeholder.password": "\u0627\u0643\u062A\u0628 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0627\u0644\u062E\u0627\u0635\u0629 \u0628\u0643 \u0647\u0646\u0627...", "pointSystem.error": "\u064A\u062C\u0628 \u0623\u0646 \u062A\u0643\u0648\u0646 \u0627\u0644\u0646\u0642\u0627\u0637 \u0627\u0644\u0625\u062C\u0645\u0627\u0644\u064A\u0629 100 %", "boolean.yes": "\u0646\u0639\u0645", "boolean.no": "\u0644\u0627", "upload.cta": "\u0627\u0633\u062D\u0628 \u0648\u0623\u0641\u0644\u062A \u0623\u0648 \u0627\u0646\u0642\u0631 \u0644\u0644\u062A\u062D\u0645\u064A\u0644", "upload.imagesOnly": "\u0627\u0644\u0635\u0648\u0631 \u0641\u0642\u0637", "upload.anyFileType": "\u0623\u064A \u0646\u0648\u0639 \u0645\u0646 \u0627\u0644\u0645\u0644\u0641\u0627\u062A", "upload.maxFiles": "{n} \u0645\u0644\u0641\u0627\u062A \u0643\u062D\u062F \u0623\u0642\u0635\u0649", "upload.maxSize": "{mb} \u0645\u064A\u063A\u0627\u0628\u0627\u064A\u062A \u0643\u062D\u062F \u0623\u0642\u0635\u0649", "upload.tooLarge": "\u0627\u0644\u0645\u0644\u0641 \u0643\u0628\u064A\u0631 \u062C\u062F\u064B\u0627 (\u0627\u0644\u062D\u062F \u0627\u0644\u0623\u0642\u0635\u0649 {mb} \u0645\u064A\u063A\u0627\u0628\u0627\u064A\u062A)", "upload.remove": "\u0625\u0632\u0627\u0644\u0629", "select.placeholder": "\u0627\u062E\u062A\u0631 \u062E\u064A\u0627\u0631\u064B\u0627", "rating.ariaLabel": "\u0627\u0644\u062A\u0642\u064A\u064A\u0645", "maxDiff.best": "\u0627\u0644\u0623\u0643\u062B\u0631 \u0623\u0647\u0645\u064A\u0629", "maxDiff.worst": "\u0627\u0644\u0623\u0642\u0644 \u0623\u0647\u0645\u064A\u0629", "maxDiff.setProgress": "\u0627\u0644\u0645\u062C\u0645\u0648\u0639\u0629 {k} \u0645\u0646 {n}", "priority.selectUpTo": "\u0627\u062E\u062A\u0631 \u062D\u062A\u0649", "priority.options": "\u062E\u064A\u0627\u0631\u0627\u062A", "priority.thenOrder": "\u062B\u0645 \u0631\u062A\u0628\u0647\u0627", "priority.selectOptions": "\u0627\u062E\u062A\u0631 \u0627\u0644\u062E\u064A\u0627\u0631\u0627\u062A", "priority.cancel": "\u0625\u0644\u063A\u0627\u0621", "priority.confirm": "\u062A\u0623\u0643\u064A\u062F", "priority.selectOptionNumber": "\u0627\u062E\u062A\u0631 \u0627\u0644\u062E\u064A\u0627\u0631 #", "priority.prioritized": "\u062A\u0645 \u0627\u0644\u062A\u0631\u062A\u064A\u0628", "priority.of": "\u0645\u0646", "priority.instruction": '\u062A\u0638\u0647\u0631 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0623\u0648\u0644\u0648\u064A\u0627\u062A \u0627\u0644\u062E\u0627\u0635\u0629 \u0628\u0643 \u0623\u062F\u0646\u0627\u0647. \u0625\u0630\u0627 \u0631\u063A\u0628\u062A\u060C \u064A\u0645\u0643\u0646\u0643 \u0625\u0639\u0627\u062F\u0629 \u062A\u0631\u062A\u064A\u0628 \u0627\u062E\u062A\u064A\u0627\u0631\u0627\u062A\u0643 \u0628\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0627\u0644\u0623\u0633\u0647\u0645. \u0627\u0646\u0642\u0631 \u0639\u0644\u0649 "\u0627\u0644\u062A\u0627\u0644\u064A" \u0644\u062A\u0623\u0643\u064A\u062F \u0627\u062E\u062A\u064A\u0627\u0631\u0643 \u0648\u0627\u0644\u0645\u062A\u0627\u0628\u0639\u0629.', "action.send": "\u0625\u0631\u0633\u0627\u0644", "action.back": "\u0631\u062C\u0648\u0639", "action.next": "\u0627\u0644\u062A\u0627\u0644\u064A", "action.start": "\u0627\u0628\u062F\u0623!", "message.success": "\u0634\u0643\u0631\u064B\u0627 \u0644\u0645\u0644\u0627\u062D\u0638\u0627\u062A\u0643!", "message.blocked": "\u0634\u0643\u0631\u064B\u0627 \u0639\u0644\u0649 \u0648\u0642\u062A\u0643\u060C \u0633\u0646\u0646\u0647\u064A \u0627\u0644\u0645\u062D\u0627\u062F\u062B\u0629 \u0647\u0646\u0627.", "message.required": "\u064A\u0631\u062C\u0649 \u0627\u0644\u0625\u062C\u0627\u0628\u0629 \u0642\u0628\u0644 \u0627\u0644\u0645\u062A\u0627\u0628\u0639\u0629.", "message.rateLimit": "\u0637\u0644\u0628\u0627\u062A \u0643\u062B\u064A\u0631\u0629 \u062C\u062F\u064B\u0627. \u0633\u0646\u0639\u064A\u062F \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629 \u062E\u0644\u0627\u0644 {seconds} \u062B\u0627\u0646\u064A\u0629..." }, bn: { "placeholder.answer": "\u098F\u0996\u09BE\u09A8\u09C7 \u0986\u09AA\u09A8\u09BE\u09B0 \u0989\u09A4\u09CD\u09A4\u09B0 \u09B2\u09BF\u0996\u09C1\u09A8...", "placeholder.number": "\u098F\u0996\u09BE\u09A8\u09C7 \u0986\u09AA\u09A8\u09BE\u09B0 \u09B8\u0982\u0996\u09CD\u09AF\u09BE \u09B2\u09BF\u0996\u09C1\u09A8...", "placeholder.email": "\u098F\u0996\u09BE\u09A8\u09C7 \u0986\u09AA\u09A8\u09BE\u09B0 \u0987\u09AE\u09C7\u0987\u09B2 \u09B2\u09BF\u0996\u09C1\u09A8...", "placeholder.date": "\u098F\u0996\u09BE\u09A8\u09C7 \u0986\u09AA\u09A8\u09BE\u09B0 \u09A4\u09BE\u09B0\u09BF\u0996 \u09B2\u09BF\u0996\u09C1\u09A8...", "placeholder.password": "\u098F\u0996\u09BE\u09A8\u09C7 \u0986\u09AA\u09A8\u09BE\u09B0 \u09AA\u09BE\u09B8\u0993\u09AF\u09BC\u09BE\u09B0\u09CD\u09A1 \u09B2\u09BF\u0996\u09C1\u09A8...", "pointSystem.error": "\u09AE\u09CB\u099F \u09AA\u09AF\u09BC\u09C7\u09A8\u09CD\u099F 100 % \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7", "boolean.yes": "\u09B9\u09CD\u09AF\u09BE\u0981", "boolean.no": "\u09A8\u09BE", "upload.cta": "\u099F\u09C7\u09A8\u09C7 \u0986\u09A8\u09C1\u09A8 \u09AC\u09BE \u0986\u09AA\u09B2\u09CB\u09A1 \u0995\u09B0\u09A4\u09C7 \u0995\u09CD\u09B2\u09BF\u0995 \u0995\u09B0\u09C1\u09A8", "upload.imagesOnly": "\u09B6\u09C1\u09A7\u09C1\u09AE\u09BE\u09A4\u09CD\u09B0 \u099B\u09AC\u09BF", "upload.anyFileType": "\u09AF\u09C7\u0995\u09CB\u09A8\u09CB \u09A7\u09B0\u09A8\u09C7\u09B0 \u09AB\u09BE\u0987\u09B2", "upload.maxFiles": "\u09B8\u09B0\u09CD\u09AC\u09CB\u099A\u09CD\u099A {n}\u099F\u09BF \u09AB\u09BE\u0987\u09B2", "upload.maxSize": "\u09B8\u09B0\u09CD\u09AC\u09CB\u099A\u09CD\u099A {mb} MB", "upload.tooLarge": "\u09AB\u09BE\u0987\u09B2\u099F\u09BF \u0996\u09C1\u09AC \u09AC\u09A1\u09BC (\u09B8\u09B0\u09CD\u09AC\u09CB\u099A\u09CD\u099A {mb} MB)", "upload.remove": "\u09B8\u09B0\u09BE\u09A8", "select.placeholder": "\u098F\u0995\u099F\u09BF \u09AC\u09BF\u0995\u09B2\u09CD\u09AA \u09A8\u09BF\u09B0\u09CD\u09AC\u09BE\u099A\u09A8 \u0995\u09B0\u09C1\u09A8", "rating.ariaLabel": "\u09B0\u09C7\u099F\u09BF\u0982", "maxDiff.best": "\u09B8\u09AC\u099A\u09C7\u09AF\u09BC\u09C7 \u0997\u09C1\u09B0\u09C1\u09A4\u09CD\u09AC\u09AA\u09C2\u09B0\u09CD\u09A3", "maxDiff.worst": "\u09B8\u09AC\u099A\u09C7\u09AF\u09BC\u09C7 \u0995\u09AE \u0997\u09C1\u09B0\u09C1\u09A4\u09CD\u09AC\u09AA\u09C2\u09B0\u09CD\u09A3", "maxDiff.setProgress": "\u09AC\u09CD\u09B2\u0995 {k}/{n}", "priority.selectUpTo": "\u09B8\u09B0\u09CD\u09AC\u09CB\u099A\u09CD\u099A \u09A8\u09BF\u09B0\u09CD\u09AC\u09BE\u099A\u09A8 \u0995\u09B0\u09C1\u09A8", "priority.options": "\u099F\u09BF \u09AC\u09BF\u0995\u09B2\u09CD\u09AA", "priority.thenOrder": "\u09A4\u09BE\u09B0\u09AA\u09B0 \u09B8\u09C7\u0997\u09C1\u09B2\u09CB \u09B8\u09BE\u099C\u09BE\u09A8", "priority.selectOptions": "\u09AC\u09BF\u0995\u09B2\u09CD\u09AA \u09A8\u09BF\u09B0\u09CD\u09AC\u09BE\u099A\u09A8 \u0995\u09B0\u09C1\u09A8", "priority.cancel": "\u09AC\u09BE\u09A4\u09BF\u09B2", "priority.confirm": "\u09A8\u09BF\u09B6\u09CD\u099A\u09BF\u09A4 \u0995\u09B0\u09C1\u09A8", "priority.selectOptionNumber": "\u09AC\u09BF\u0995\u09B2\u09CD\u09AA # \u09A8\u09BF\u09B0\u09CD\u09AC\u09BE\u099A\u09A8 \u0995\u09B0\u09C1\u09A8", "priority.prioritized": "\u0985\u0997\u09CD\u09B0\u09BE\u09A7\u09BF\u0995\u09BE\u09B0\u09AA\u09CD\u09B0\u09BE\u09AA\u09CD\u09A4", "priority.of": "\u098F\u09B0 \u09AE\u09A7\u09CD\u09AF\u09C7", "priority.instruction": '\u0986\u09AA\u09A8\u09BE\u09B0 \u0985\u0997\u09CD\u09B0\u09BE\u09A7\u09BF\u0995\u09BE\u09B0 \u09A4\u09BE\u09B2\u09BF\u0995\u09BE \u09A8\u09BF\u099A\u09C7 \u09A6\u09C7\u0996\u09BE\u09A8\u09CB \u09B9\u09AF\u09BC\u09C7\u099B\u09C7\u0964 \u099A\u09BE\u0987\u09B2\u09C7 \u09A4\u09C0\u09B0 \u099A\u09BF\u09B9\u09CD\u09A8 \u09AC\u09CD\u09AF\u09AC\u09B9\u09BE\u09B0 \u0995\u09B0\u09C7 \u0986\u09AA\u09A8\u09BE\u09B0 \u09AA\u099B\u09A8\u09CD\u09A6\u0997\u09C1\u09B2\u09CB \u09AA\u09C1\u09A8\u09B0\u09BE\u09AF\u09BC \u09B8\u09BE\u099C\u09BE\u09A4\u09C7 \u09AA\u09BE\u09B0\u09C7\u09A8\u0964 "\u09AA\u09B0\u09AC\u09B0\u09CD\u09A4\u09C0" \u0995\u09CD\u09B2\u09BF\u0995 \u0995\u09B0\u09C7 \u0986\u09AA\u09A8\u09BE\u09B0 \u09A8\u09BF\u09B0\u09CD\u09AC\u09BE\u099A\u09A8 \u09A8\u09BF\u09B6\u09CD\u099A\u09BF\u09A4 \u0995\u09B0\u09C1\u09A8 \u098F\u09AC\u0982 \u098F\u0997\u09BF\u09AF\u09BC\u09C7 \u09AF\u09BE\u09A8\u0964', "action.send": "\u09AA\u09BE\u09A0\u09BE\u09A8", "action.back": "\u09AA\u09BF\u099B\u09A8\u09C7", "action.next": "\u09AA\u09B0\u09AC\u09B0\u09CD\u09A4\u09C0", "action.start": "\u09B6\u09C1\u09B0\u09C1 \u0995\u09B0\u09C1\u09A8!", "message.success": "\u0986\u09AA\u09A8\u09BE\u09B0 \u09AE\u09A4\u09BE\u09AE\u09A4\u09C7\u09B0 \u099C\u09A8\u09CD\u09AF \u09A7\u09A8\u09CD\u09AF\u09AC\u09BE\u09A6!", "message.blocked": "\u0986\u09AA\u09A8\u09BE\u09B0 \u09B8\u09AE\u09AF\u09BC\u09C7\u09B0 \u099C\u09A8\u09CD\u09AF \u09A7\u09A8\u09CD\u09AF\u09AC\u09BE\u09A6, \u0986\u09AE\u09B0\u09BE \u098F\u0996\u09BE\u09A8\u09C7\u0987 \u0995\u09A5\u09CB\u09AA\u0995\u09A5\u09A8 \u09B6\u09C7\u09B7 \u0995\u09B0\u099B\u09BF\u0964", "message.required": "\u099A\u09BE\u09B2\u09BF\u09AF\u09BC\u09C7 \u09AF\u09BE\u0993\u09AF\u09BC\u09BE\u09B0 \u0986\u0997\u09C7 \u0985\u09A8\u09C1\u0997\u09CD\u09B0\u09B9 \u0995\u09B0\u09C7 \u0989\u09A4\u09CD\u09A4\u09B0 \u09A6\u09BF\u09A8\u0964", "message.rateLimit": "\u0985\u09A8\u09C7\u0995 \u09AC\u09C7\u09B6\u09BF \u0985\u09A8\u09C1\u09B0\u09CB\u09A7\u0964 {seconds} \u09B8\u09C7\u0995\u09C7\u09A8\u09CD\u09A1\u09C7 \u0986\u09AC\u09BE\u09B0 \u099A\u09C7\u09B7\u09CD\u099F\u09BE \u0995\u09B0\u09BE \u09B9\u099A\u09CD\u099B\u09C7..." }, it: { "boolean.yes": "S\xEC", "boolean.no": "No", "priority.selectUpTo": "Seleziona fino a", "priority.options": "opzioni", "priority.thenOrder": "e poi ordinali", "priority.selectOptions": "Seleziona opzioni", "priority.cancel": "Annulla", "priority.confirm": "Conferma", "priority.selectOptionNumber": "Seleziona opzione #", "priority.prioritized": "Prioritizzate", "priority.of": "di", "priority.instruction": 'La tua lista di priorit\xE0 \xE8 mostrata qui sotto. Se vuoi, puoi riordinare le tue scelte usando le frecce. Clicca su "Avanti" per confermare la selezione e continuare.' }, nl: { "boolean.yes": "Ja", "boolean.no": "Nee", "priority.selectUpTo": "Selecteer tot", "priority.options": "opties", "priority.thenOrder": "en rangschik ze vervolgens", "priority.selectOptions": "Selecteer opties", "priority.cancel": "Annuleren", "priority.confirm": "Bevestigen", "priority.selectOptionNumber": "Selecteer optie #", "priority.prioritized": "Geprioriteerd", "priority.of": "van", "priority.instruction": 'Je prioriteitenlijst wordt hieronder weergegeven. Als je wilt, kun je je keuzes herschikken met behulp van de pijlen. Klik op "Volgende" om je selectie te bevestigen en door te gaan.' }, pl: { "boolean.yes": "Tak", "boolean.no": "Nie", "priority.selectUpTo": "Wybierz do", "priority.options": "opcje", "priority.thenOrder": "a nast\u0119pnie je uporz\u0105dkuj", "priority.selectOptions": "Wybierz opcje", "priority.cancel": "Anuluj", "priority.confirm": "Potwierd\u017A", "priority.selectOptionNumber": "Wybierz opcj\u0119 #", "priority.prioritized": "Priorytetowe", "priority.of": "z", "priority.instruction": 'Twoja lista priorytet\xF3w jest pokazana poni\u017Cej. Je\u015Bli chcesz, mo\u017Cesz zmieni\u0107 kolejno\u015B\u0107 swoich wybor\xF3w za pomoc\u0105 strza\u0142ek. Kliknij "Dalej", aby potwierdzi\u0107 wyb\xF3r i kontynuowa\u0107.' }, ru: { "boolean.yes": "\u0414\u0430", "boolean.no": "\u041D\u0435\u0442", "priority.selectUpTo": "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0434\u043E", "priority.options": "\u0432\u0430\u0440\u0438\u0430\u043D\u0442\u043E\u0432", "priority.thenOrder": "\u0430 \u0437\u0430\u0442\u0435\u043C \u0443\u043F\u043E\u0440\u044F\u0434\u043E\u0447\u044C\u0442\u0435 \u0438\u0445", "priority.selectOptions": "\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u044B", "priority.cancel": "\u041E\u0442\u043C\u0435\u043D\u0430", "priority.confirm": "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C", "priority.selectOptionNumber": "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0432\u0430\u0440\u0438\u0430\u043D\u0442 #", "priority.prioritized": "\u041F\u0440\u0438\u043E\u0440\u0438\u0442\u0435\u0442\u044B", "priority.of": "\u0438\u0437", "priority.instruction": '\u0412\u0430\u0448 \u0441\u043F\u0438\u0441\u043E\u043A \u043F\u0440\u0438\u043E\u0440\u0438\u0442\u0435\u0442\u043E\u0432 \u043E\u0442\u043E\u0431\u0440\u0430\u0436\u0430\u0435\u0442\u0441\u044F \u043D\u0438\u0436\u0435. \u0415\u0441\u043B\u0438 \u0445\u043E\u0442\u0438\u0442\u0435, \u0432\u044B \u043C\u043E\u0436\u0435\u0442\u0435 \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u044C \u043F\u043E\u0440\u044F\u0434\u043E\u043A \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u043E\u0432 \u0441 \u043F\u043E\u043C\u043E\u0449\u044C\u044E \u0441\u0442\u0440\u0435\u043B\u043E\u043A. \u041D\u0430\u0436\u043C\u0438\u0442\u0435 "\u0414\u0430\u043B\u0435\u0435", \u0447\u0442\u043E\u0431\u044B \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C \u0432\u044B\u0431\u043E\u0440 \u0438 \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u044C.' }, ja: { "boolean.yes": "\u306F\u3044", "boolean.no": "\u3044\u3044\u3048", "priority.selectUpTo": "\u6700\u5927", "priority.options": "\u500B\u306E\u30AA\u30D7\u30B7\u30E7\u30F3\u3092\u9078\u629E", "priority.thenOrder": "\u305D\u306E\u5F8C\u4E26\u3079\u66FF\u3048\u3066\u304F\u3060\u3055\u3044", "priority.selectOptions": "\u30AA\u30D7\u30B7\u30E7\u30F3\u3092\u9078\u629E", "priority.cancel": "\u30AD\u30E3\u30F3\u30BB\u30EB", "priority.confirm": "\u78BA\u8A8D", "priority.selectOptionNumber": "\u30AA\u30D7\u30B7\u30E7\u30F3 # \u3092\u9078\u629E", "priority.prioritized": "\u512A\u5148\u9806\u4F4D", "priority.of": "\u306E\u3046\u3061", "priority.instruction": "\u512A\u5148\u9806\u4F4D\u30EA\u30B9\u30C8\u306F\u4EE5\u4E0B\u306B\u8868\u793A\u3055\u308C\u307E\u3059\u3002\u5FC5\u8981\u306B\u5FDC\u3058\u3066\u3001\u77E2\u5370\u3092\u4F7F\u3063\u3066\u9078\u629E\u80A2\u3092\u4E26\u3079\u66FF\u3048\u308B\u3053\u3068\u304C\u3067\u304D\u307E\u3059\u3002\u300C\u6B21\u3078\u300D\u3092\u30AF\u30EA\u30C3\u30AF\u3057\u3066\u9078\u629E\u3092\u78BA\u5B9A\u3057\u3001\u7D9A\u884C\u3057\u3066\u304F\u3060\u3055\u3044\u3002" }, zh: { "boolean.yes": "\u662F", "boolean.no": "\u4E0D", "priority.selectUpTo": "\u6700\u591A\u9009\u62E9", "priority.options": "\u4E2A\u9009\u9879", "priority.thenOrder": "\u7136\u540E\u6392\u5E8F\u5B83\u4EEC", "priority.selectOptions": "\u9009\u62E9\u9009\u9879", "priority.cancel": "\u53D6\u6D88", "priority.confirm": "\u786E\u8BA4", "priority.selectOptionNumber": "\u9009\u62E9\u9009\u9879 #", "priority.prioritized": "\u5DF2\u4F18\u5148", "priority.of": "\u5171", "priority.instruction": "\u4F60\u7684\u4F18\u5148\u5217\u8868\u5982\u4E0B\u6240\u793A\u3002\u5982\u6709\u9700\u8981\uFF0C\u53EF\u4EE5\u4F7F\u7528\u7BAD\u5934\u91CD\u65B0\u6392\u5E8F\u9009\u9879\u3002\u70B9\u51FB\u201C\u4E0B\u4E00\u6B65\u201D\u786E\u8BA4\u9009\u62E9\u5E76\u7EE7\u7EED\u3002" }, ko: { "boolean.yes": "\uC608", "boolean.no": "\uC544\uB2C8", "priority.selectUpTo": "\uCD5C\uB300", "priority.options": "\uAC1C\uC758 \uC635\uC158 \uC120\uD0DD", "priority.thenOrder": "\uADF8\uB7F0 \uB2E4\uC74C \uC815\uB82C\uD558\uC138\uC694", "priority.selectOptions": "\uC635\uC158 \uC120\uD0DD", "priority.cancel": "\uCDE8\uC18C", "priority.confirm": "\uD655\uC778", "priority.selectOptionNumber": "\uC635\uC158 # \uC120\uD0DD", "priority.prioritized": "\uC6B0\uC120\uC21C\uC704", "priority.of": "\uC911", "priority.instruction": '\uC6B0\uC120\uC21C\uC704 \uBAA9\uB85D\uC740 \uC544\uB798\uC5D0 \uD45C\uC2DC\uB429\uB2C8\uB2E4. \uC6D0\uD55C\uB2E4\uBA74 \uD654\uC0B4\uD45C\uB97C \uC0AC\uC6A9\uD574 \uC120\uD0DD \uD56D\uBAA9\uC744 \uC7AC\uC815\uB82C\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4. "\uB2E4\uC74C"\uC744 \uD074\uB9AD\uD558\uC5EC \uC120\uD0DD\uC744 \uD655\uC778\uD558\uACE0 \uACC4\uC18D\uD558\uC138\uC694.' } };
        t2.SUPPORTED_LANGUAGES = ["en", "da", "fi", "no", "es", "sv", "ar", "bn", "de", "pt", "fr"], t2.AVAILABLE_LANGUAGES = Object.keys(n), t2.RTL_LANGUAGES = ["ar"];
        const r = { nb: "no", nn: "no", nob: "no", nno: "no", iw: "he", in: "id", cmn: "zh" };
        function o(e3) {
          if (!e3) return null;
          const t3 = e3.trim().toLowerCase().replace(/_/g, "-");
          if (!t3) return null;
          if (n[t3]) return t3;
          const i2 = t3.split("-")[0], o2 = r[i2] || i2;
          return n[o2] ? o2 : null;
        }
        function a(e3) {
          return o(e3) || "en";
        }
        t2.normalizeLanguage = a, t2.TRANSLATION_KEYS = Object.keys(i), t2.hasOwnTranslation = function(e3, t3) {
          const i2 = o(e3);
          return !!i2 && void 0 !== n[i2][t3];
        }, t2.isRtlLanguage = function(e3) {
          return -1 !== t2.RTL_LANGUAGES.indexOf(a(e3));
        }, t2.isLanguageSupported = function(e3) {
          const i2 = o(e3);
          return !!i2 && -1 !== t2.SUPPORTED_LANGUAGES.indexOf(i2);
        }, t2.t = function(e3, t3, r2) {
          const o2 = n[a(e3)] || i, s = void 0 !== o2[t3] ? o2[t3] : i[t3];
          return r2 ? (function(e4, t4) {
            return Object.keys(t4).reduce(((e5, i2) => e5.replace(new RegExp("\\{" + i2 + "\\}", "g"), String(t4[i2]))), e4);
          })(s, r2) : s;
        };
      }, 5407: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.endpoints = void 0, t2.endpoints = { sdk: { app: (e3, t3) => `sdk/app/${e3}/${t3}`, app_info: (e3, t3) => `sdk/app/${e3}/${t3}/info`, session: (e3) => `sdk/app/session/${e3}/info`, feedback: "sdk/feedback", followUpQuestion: "sdk/followUpQuestion", agentSurveyStart: "sdk/agentSurvey/start", agentSurveyNext: "sdk/agentSurvey/next" } };
      }, 3262: (e2, t2, i) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.placeholder = void 0;
        const n = i(7627);
        t2.placeholder = { answer: (e3) => (0, n.t)(e3, "placeholder.answer"), number: (e3) => (0, n.t)(e3, "placeholder.number"), email: (e3) => (0, n.t)(e3, "placeholder.email"), date: (e3) => (0, n.t)(e3, "placeholder.date"), password: (e3) => (0, n.t)(e3, "placeholder.password"), pointsystemerror: (e3) => (0, n.t)(e3, "pointSystem.error"), upload: { cta: (e3) => (0, n.t)(e3, "upload.cta"), formats: (e3, t3) => (0, n.t)(e3, "image" === t3 ? "upload.imagesOnly" : "upload.anyFileType"), maxFiles: (e3, t3) => (0, n.t)(e3, "upload.maxFiles", { n: t3 }), maxSize: (e3, t3) => (0, n.t)(e3, "upload.maxSize", { mb: t3 }), tooLarge: (e3, t3) => (0, n.t)(e3, "upload.tooLarge", { mb: t3 }), remove: (e3) => (0, n.t)(e3, "upload.remove") } };
      }, 7643: (e2, t2, i) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.renderStartMessage = t2.renderSuccess = t2.renderError = t2.renderActions = t2.renderQuestions = void 0;
        const n = i(4760), r = i(368), o = i(1366), a = i(3433), s = i(9039), l = { small: "1rem", medium: "1.2rem", large: "1.5rem" };
        t2.renderQuestions = function e3(t3, i2 = "standard", d = "en", c = { customIcons: false }, u) {
          if (!t3) throw new Error("[MagicFeedback] No questions provided");
          const p = [], { customIcons: m, id: h } = c;
          return t3.forEach(((f) => {
            var g, y;
            if ((null === (y = null === (g = null == f ? void 0 : f.questionType) || void 0 === g ? void 0 : g.conf) || void 0 === y ? void 0 : y.length) > 0) {
              let t4 = document.createElement("div");
              t4.classList.add("magicfeedback-div");
              const n2 = document.createElement("label");
              n2.setAttribute("for", `magicfeedback-${f.id}`), n2.textContent = (0, o.parseTitle)(f.title, d), n2.classList.add("magicfeedback-label"), t4.appendChild(n2), f.questionType.conf.forEach(((e4) => {
                e4.ref = f.ref, f.assets[e4.id] && (e4.assets = { placeholder: f.assets[e4.id] });
              })), e3(f.questionType.conf, i2, d, c, u).forEach(((e4) => {
                t4.appendChild(e4);
              })), p.push(t4);
            } else {
              const e4 = (function(e5, t4, i3, d2, c2, u2) {
                var p2, m2, h2;
                let f2, g2, { id: y2, title: v, type: b, ref: E, require: A, defaultValue: k, assets: T } = e5, C = document.createElement("div");
                C.classList.add("magicfeedback-div");
                const P = window.innerWidth < 600, S = "slim" === t4 ? (0, o.parseTitle)(v, i3) : null == T ? void 0 : T.placeholder, w = (0, a.shownValueFor)(e5, (0, o.getUrlParam)(E)), O = (null == T ? void 0 : T.maxCharacters) || 0, x = false === (null == T ? void 0 : T.autoAdvance) ? void 0 : c2, L = void 0 !== (null == T ? void 0 : T.randomPosition) && (null == T ? void 0 : T.randomPosition), N = (null == T ? void 0 : T.direction) || "row", I = (null == T ? void 0 : T.order) || "ltr", D = (0, r.getQuestionRenderer)(b);
                if (!D) return C;
                {
                  const r2 = D({ question: e5, format: t4, language: i3, url: d2, send: b === n.FEEDBACKAPPANSWERTYPE.TEXT ? c2 : x, isPhone: P, urlParamValue: w, placeholderText: S, maxCharacters: O, randomPosition: L, direction: N, order: I, productId: u2 });
                  f2 = r2.element, g2 = r2.elementTypeClass;
                }
                f2.id = `magicfeedback-${y2}`, f2.setAttribute("name", E), f2.classList.add(g2), (void 0 !== k || null !== w) && (f2.value = w || k), ["RADIO", "MULTIPLECHOICE", "UPLOAD_IMAGE", "UPLOAD_FILE"].includes(b) || (f2.classList.add("magicfeedback-input"), f2.required = A);
                const R = document.createElement("label");
                R.setAttribute("for", `magicfeedback-${y2}`), R.textContent = (0, o.parseTitle)(v, i3), R.classList.add("magicfeedback-label"), (function(e6, t5) {
                  if ("INFO_PAGE" !== t5.type) return;
                  const { assets: i4 } = t5, n2 = (function(e7) {
                    if (e7) return l[e7] || e7;
                  })(null == i4 ? void 0 : i4.titleSize), r2 = (o2 = null == i4 ? void 0 : i4.titleStyle, Array.isArray(o2) ? o2 : o2 ? [o2] : []);
                  var o2;
                  n2 && e6.style.setProperty("font-size", n2, "important"), (null == i4 ? void 0 : i4.titleAlign) && (e6.style.setProperty("width", "100%", "important"), e6.style.setProperty("align-self", "stretch", "important"), e6.style.setProperty("text-align", i4.titleAlign, "important")), r2.includes("italic") && e6.style.setProperty("font-style", "italic", "important"), r2.includes("bold") && e6.style.setProperty("font-weight", "bold", "important"), r2.includes("underline") && e6.style.setProperty("text-decoration", "underline", "important");
                })(R, e5);
                const _ = document.createElement("label");
                if (_.textContent = (0, o.parseTitle)(null == T ? void 0 : T.subtitle, i3), _.classList.add("magicfeedback-sublabel"), (null === (p2 = null == T ? void 0 : T.subtitleStyle) || void 0 === p2 ? void 0 : p2.includes("italic")) && (_.style.fontStyle = "italic"), (null === (m2 = null == T ? void 0 : T.subtitleStyle) || void 0 === m2 ? void 0 : m2.includes("bold")) && (_.style.fontWeight = "bold"), (null === (h2 = null == T ? void 0 : T.subtitleStyle) || void 0 === h2 ? void 0 : h2.includes("underline")) && (_.style.textDecoration = "underline"), ["CONSENT"].includes(b)) C.classList.add("magicfeedback-consent-container"), C.appendChild(f2), C.appendChild(R), (null == T ? void 0 : T.subtitle) && C.appendChild(_);
                else {
                  if ("slim" !== t4 && (C.appendChild(R), (null == T ? void 0 : T.subtitle) && C.appendChild(_), void 0 !== (null == T ? void 0 : T.general) && "" !== (null == T ? void 0 : T.general))) {
                    const e6 = document.createElement("img");
                    e6.src = null == T ? void 0 : T.general, e6.classList.add("magicfeedback-image"), e6.style.maxWidth = "auto", e6.style.height = "400px", e6.style.margin = "10px 0", C.appendChild(e6);
                  }
                  if ("LONGTEXT" === b && O > 0) {
                    const e6 = document.createElement("div");
                    if (e6.classList.add("magicfeedback-counter"), e6.textContent = `${f2.value.length}/${O}`, e6.style.textAlign = "end", e6.style.fontSize = "15px", e6.style.marginTop = "5px", f2.addEventListener("input", (() => {
                      e6.textContent = `${f2.value.length}/${O}`;
                    })), C.appendChild(f2), C.appendChild(e6), (null == T ? void 0 : T.extraOption) && (null == T ? void 0 : T.extraOptionText)) {
                      const e7 = document.createElement("div");
                      e7.classList.add("magicfeedback-skip-container"), e7.classList.add("magicfeedback-checkbox-container"), e7.style.display = "flex", e7.style.justifyContent = "flex-start";
                      const t5 = document.createElement("input");
                      t5.classList.add("magicfeedback-skip"), t5.type = "checkbox", t5.id = `skip-${E}`, t5.name = E, t5.value = "-", t5.style.cursor = "pointer";
                      const i4 = document.createElement("label");
                      i4.htmlFor = `skip-${E}`, i4.textContent = null == T ? void 0 : T.extraOptionText, i4.style.fontSize = "15px", i4.style.cursor = "pointer", i4.style.margin = "0 5px", t5.addEventListener("click", (() => {
                        f2.value = "-";
                      })), (0, s.autoAdvanceOn)(t5, x, "click"), e7.appendChild(t5), e7.appendChild(i4), C.appendChild(e7);
                    }
                  } else C.appendChild(f2);
                }
                return C;
              })(f, i2, d, "https://survey-dev.magicfeedback.io/assets/emojis" + (m ? `/${h}` : ""), 1 === t3.length ? u : void 0, h);
              p.push(e4);
            }
          })), p;
        }, t2.renderActions = function(e3 = "", t3, i2 = "Submit", n2 = "Back", r2 = "Next") {
          const o2 = document.createElement("div");
          o2.classList.add("magicfeedback-action-container");
          const a2 = document.createElement("button");
          a2.id = "magicfeedback-submit", a2.type = "submit", a2.classList.add("magicfeedback-submit"), a2.textContent = "MAGICSURVEY" === e3 ? r2 || "Next" : i2 || "Submit";
          const s2 = document.createElement("button");
          return s2.id = "magicfeedback-back", s2.type = "button", s2.classList.add("magicfeedback-back"), s2.textContent = n2 || "Back", s2.addEventListener("click", t3), s2.addEventListener("click", (() => {
            a2.removeAttribute("disabled");
          })), "MAGICSURVEY" === e3 && o2.appendChild(s2), o2.appendChild(a2), o2;
        }, t2.renderError = function(e3) {
          const t3 = document.createElement("div");
          return t3.classList.add("magicfeedback-error"), t3.textContent = e3, t3;
        }, t2.renderSuccess = function(e3) {
          const t3 = document.createElement("div");
          return t3.classList.add("magicfeedback-success"), t3.textContent = e3, t3;
        }, t2.renderStartMessage = function(e3, t3 = false, i2 = "Go!", n2 = () => {
        }) {
          const r2 = document.createElement("div");
          r2.classList.add("magicfeedback-start-message-container");
          const o2 = document.createElement("div");
          if (o2.classList.add("magicfeedback-start-message"), o2.innerHTML = e3, r2.appendChild(o2), t3) {
            const e4 = document.createElement("button");
            e4.id = "magicfeedback-start-message-button", e4.classList.add("magicfeedback-start-message-button"), e4.textContent = i2, e4.addEventListener("click", (() => n2())), r2.appendChild(e4);
          }
          return r2;
        };
      }, 9071: function(e2, t2, i) {
        "use strict";
        var n = this && this.__awaiter || function(e3, t3, i2, n2) {
          return new (i2 || (i2 = Promise))((function(r2, o2) {
            function a2(e4) {
              try {
                l2(n2.next(e4));
              } catch (e5) {
                o2(e5);
              }
            }
            function s2(e4) {
              try {
                l2(n2.throw(e4));
              } catch (e5) {
                o2(e5);
              }
            }
            function l2(e4) {
              var t4;
              e4.done ? r2(e4.value) : (t4 = e4.value, t4 instanceof i2 ? t4 : new i2((function(e5) {
                e5(t4);
              }))).then(a2, s2);
            }
            l2((n2 = n2.apply(e3, t3 || [])).next());
          }));
        }, r = this && this.__importDefault || function(e3) {
          return e3 && e3.__esModule ? e3 : { default: e3 };
        };
        Object.defineProperty(t2, "__esModule", { value: true }), t2.getFollowUpQuestion = t2.sendFeedback = t2.getQuestions = t2.getSessionForm = t2.getForm = t2.takePreloadedInfo = t2.validateEmail = t2.header = void 0;
        const o = r(i(6539)), a = r(i(8330)), s = i(5407), l = i(3433);
        function d(e3) {
          if ("undefined" == typeof window) return;
          const i2 = window, n2 = i2.__MAGICFEEDBACK_PRELOADED_INFO__;
          if (n2 && n2.url === e3 && n2.parameters === t2.header["x-magicfeedback-parameters"]) {
            delete i2.__MAGICFEEDBACK_PRELOADED_INFO__;
            try {
              return JSON.parse(n2.body);
            } catch (e4) {
              return;
            }
          }
        }
        t2.header = { Accept: "application/json", "Magicfeedback-Sdk-Version": a.default.version, "x-magicfeedback-parameters": window.location.search || "" }, t2.validateEmail = function(e3) {
          return /\S+@\S+\.\S+/.test(e3);
        }, t2.takePreloadedInfo = d, t2.getForm = function(e3, i2, r2, a2, c) {
          return n(this, void 0, void 0, (function* () {
            try {
              const n2 = (0, l.withLangParam)(e3 + s.endpoints.sdk.app_info(i2, r2), c), a3 = d(n2);
              if (void 0 !== a3) return a3;
              const u = yield (0, o.default)(n2, { method: "GET", headers: t2.header });
              return yield u.json();
            } catch (e4) {
              a2.err(e4);
            }
          }));
        }, t2.getSessionForm = function(e3, i2, r2, a2) {
          return n(this, void 0, void 0, (function* () {
            try {
              const n2 = (0, l.withLangParam)(e3 + s.endpoints.sdk.session(i2), a2), r3 = d(n2);
              if (void 0 !== r3) return r3;
              const c = yield (0, o.default)(n2, { method: "GET", headers: t2.header });
              return yield c.json();
            } catch (e4) {
              r2.err(e4);
            }
          }));
        }, t2.getQuestions = function(e3, i2, r2, a2, d2) {
          return n(this, void 0, void 0, (function* () {
            try {
              const n2 = yield (0, o.default)((0, l.withLangParam)(e3 + s.endpoints.sdk.app(i2, r2), d2), { method: "GET", headers: t2.header });
              if (n2.ok) {
                const e4 = yield n2.json();
                return a2.log(`Received questions for app ${i2}`, e4), e4;
              }
              throw a2.err(`Failed to get questions for app ${i2}:`, n2.status, n2.statusText), new Error("[MagicFeedback] Bad response from server");
            } catch (e4) {
              return a2.err(e4), [];
            }
          }));
        }, t2.sendFeedback = function(e3, i2, r2) {
          return n(this, void 0, void 0, (function* () {
            try {
              const n2 = yield (0, o.default)(e3 + s.endpoints.sdk.feedback, { method: "POST", headers: Object.assign({ "Content-Type": "application/json" }, t2.header), body: JSON.stringify(i2) });
              if (n2.ok) return r2.log(`Form ${i2.integration} submitted successfully!`), (yield n2.json()).sessionId;
              throw r2.err(`Failed to submit form ${i2.integration}:`, n2.status, n2.statusText), new Error(n2.statusText);
            } catch (e4) {
              return r2.err(e4), "";
            }
          }));
        }, t2.getFollowUpQuestion = function(e3, i2, r2) {
          return n(this, void 0, void 0, (function* () {
            try {
              const n2 = yield (0, o.default)(e3 + s.endpoints.sdk.followUpQuestion, { method: "POST", headers: Object.assign({ "Content-Type": "application/json" }, t2.header), body: JSON.stringify(i2) });
              if (n2.ok) return r2.log(`Received follow up question for form ${i2.integration}`), (yield n2.json()) || "";
              throw r2.err(`Failed to get follow up question for form ${i2.integration}:`, n2.status, n2.statusText), new Error(n2.statusText);
            } catch (e4) {
              return r2.err(e4), "";
            }
          }));
        };
      }, 1012: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.SubmitError = void 0;
        class i extends Error {
          constructor(e3, t3) {
            super(t3), this.code = e3, this.name = "SubmitError", Object.setPrototypeOf(this, i.prototype);
          }
        }
        t2.SubmitError = i;
      }, 3433: (e2, t2, i) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.toBaseAnswers = t2.shownValueFor = t2.baseValueMap = t2.withLangParam = t2.detectSurveyLang = t2.normalizeSurveyLang = void 0;
        const n = i(4760), r = { nb: "no", nn: "no", nob: "no", nno: "no" };
        function o(e3) {
          if (!e3 || "string" != typeof e3) return null;
          const t3 = e3.trim().toLowerCase().replace(/_/g, "-").split("-")[0];
          return /^[a-z]{2,3}$/.test(t3) ? r[t3] || t3 : null;
        }
        function a(e3) {
          if (null == e3) return null;
          if ("string" == typeof e3 && e3.trim().startsWith("{")) try {
            e3 = JSON.parse(e3);
          } catch (t3) {
            return e3;
          }
          return "object" == typeof e3 ? void 0 !== e3.value ? String(e3.value) : null : String(e3);
        }
        function s(e3) {
          const t3 = /* @__PURE__ */ new Map(), i2 = null == e3 ? void 0 : e3.value, n2 = null == e3 ? void 0 : e3.baseValue;
          return Array.isArray(i2) && Array.isArray(n2) ? (i2.forEach(((e4, i3) => {
            const r2 = a(e4), o2 = a(n2[i3]);
            null === r2 || null === o2 || t3.has(r2) || t3.set(r2, o2);
          })), t3) : t3;
        }
        t2.normalizeSurveyLang = o, t2.detectSurveyLang = function(e3) {
          return o(e3) || (function() {
            if ("undefined" == typeof navigator) return null;
            const e4 = [...Array.isArray(navigator.languages) ? navigator.languages : [], navigator.language];
            for (const t3 of e4) {
              const e5 = o(t3);
              if (e5) return e5;
            }
            return null;
          })();
        }, t2.withLangParam = function(e3, t3) {
          return t3 ? `${e3}${e3.includes("?") ? "&" : "?"}lang=${encodeURIComponent(t3)}` : e3;
        }, t2.baseValueMap = s, t2.shownValueFor = function(e3, t3) {
          var i2, n2;
          if (null === t3 || !Array.isArray(null == e3 ? void 0 : e3.baseValue)) return t3;
          const r2 = e3.baseValue.findIndex(((e4) => a(e4) === t3));
          return -1 === r2 ? t3 : null !== (n2 = a(null === (i2 = e3.value) || void 0 === i2 ? void 0 : i2[r2])) && void 0 !== n2 ? n2 : t3;
        };
        const l = [n.FEEDBACKAPPANSWERTYPE.RADIO, n.FEEDBACKAPPANSWERTYPE.MULTIPLECHOICE, n.FEEDBACKAPPANSWERTYPE.MULTIPLECHOISE_IMAGE, n.FEEDBACKAPPANSWERTYPE.SELECT];
        t2.toBaseAnswers = function(e3, t3) {
          return e3.map(((e4) => {
            if (e4.key.startsWith("extra-option-")) return e4;
            const i2 = t3.find(((t4) => t4.ref === e4.key)) || t3.find(((t4) => e4.key.includes(t4.ref)));
            if (!i2) return e4;
            const r2 = s(i2);
            if (0 === r2.size) return e4;
            let o2;
            if (l.includes(i2.type)) o2 = (e5) => {
              var t4;
              return "string" == typeof e5 && null !== (t4 = r2.get(e5)) && void 0 !== t4 ? t4 : e5;
            };
            else if (i2.type === n.FEEDBACKAPPANSWERTYPE.PRIORITY_LIST) o2 = (e5) => "string" == typeof e5 ? (function(e6, t4) {
              var i3, n2;
              const r3 = /^(\d+)\.\s?(.*)$/.exec(e6);
              if (!r3) return null !== (i3 = t4.get(e6)) && void 0 !== i3 ? i3 : e6;
              const o3 = r3[2];
              return `${r3[1]}. ${null !== (n2 = t4.get(o3)) && void 0 !== n2 ? n2 : o3}`;
            })(e5, r2) : e5;
            else if (i2.type === n.FEEDBACKAPPANSWERTYPE.POINT_SYSTEM) o2 = (e5) => "string" == typeof e5 ? (function(e6, t4) {
              var i3;
              const n2 = e6.lastIndexOf(":");
              if (-1 === n2) return e6;
              const r3 = e6.substring(0, n2);
              return `${null !== (i3 = t4.get(r3)) && void 0 !== i3 ? i3 : r3}${e6.substring(n2)}`;
            })(e5, r2) : e5;
            else if (i2.type === n.FEEDBACKAPPANSWERTYPE.MULTI_QUESTION_MATRIX) o2 = (e5) => "string" == typeof e5 ? (function(e6, t4) {
              try {
                const i3 = JSON.parse(e6);
                return Array.isArray(i3) ? JSON.stringify(i3.map(((e7) => Object.assign(Object.assign({}, e7), { value: Array.isArray(null == e7 ? void 0 : e7.value) ? e7.value.map(((e8) => {
                  var i4;
                  return null !== (i4 = t4.get(e8)) && void 0 !== i4 ? i4 : e8;
                })) : null == e7 ? void 0 : e7.value })))) : e6;
              } catch (t5) {
                return e6;
              }
            })(e5, r2) : e5;
            else {
              if (i2.type !== n.FEEDBACKAPPANSWERTYPE.MAX_DIFF) return e4;
              o2 = (e5) => "string" == typeof e5 ? (function(e6, t4) {
                try {
                  const i3 = JSON.parse(e6);
                  if (!Array.isArray(i3)) return e6;
                  const n2 = (e7) => {
                    var i4;
                    return "string" == typeof e7 && null !== (i4 = t4.get(e7)) && void 0 !== i4 ? i4 : e7;
                  };
                  return JSON.stringify(i3.map(((e7) => Object.assign(Object.assign({}, e7), { shown: Array.isArray(null == e7 ? void 0 : e7.shown) ? e7.shown.map(n2) : null == e7 ? void 0 : e7.shown, best: n2(null == e7 ? void 0 : e7.best), worst: n2(null == e7 ? void 0 : e7.worst) }))));
                } catch (t5) {
                  return e6;
                }
              })(e5, r2) : e5;
            }
            return Object.assign(Object.assign({}, e4), { value: e4.value.map(o2) });
          }));
        };
      }, 9039: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.answeredInput = t2.autoAdvanceRequested = t2.AUTO_ADVANCE_PARAM = t2.cancelAutoAdvance = t2.autoAdvanceOn = t2.scheduleAutoAdvance = t2.AUTO_ADVANCE_DELAY_MS = void 0, t2.AUTO_ADVANCE_DELAY_MS = 300;
        const i = /* @__PURE__ */ new Map();
        function n(e3, n2) {
          const r = i.get(n2);
          r && clearTimeout(r.timer);
          const o = setTimeout((() => {
            i.delete(n2), e3.isConnected && n2();
          }), t2.AUTO_ADVANCE_DELAY_MS);
          i.set(n2, { timer: o, source: e3 });
        }
        t2.scheduleAutoAdvance = n, t2.autoAdvanceOn = function(e3, t3, i2 = "change") {
          t3 && e3.addEventListener(i2, (() => n(e3, t3)));
        }, t2.cancelAutoAdvance = function(e3) {
          e3 && i.forEach((({ timer: t3, source: n2 }, r) => {
            e3.contains(n2) && (clearTimeout(t3), i.delete(r));
          }));
        }, t2.AUTO_ADVANCE_PARAM = "autoadvance", t2.autoAdvanceRequested = function(e3 = window.location.search) {
          const i2 = new URLSearchParams(e3).get(t2.AUTO_ADVANCE_PARAM);
          return "true" === i2 || "1" === i2;
        }, t2.answeredInput = function(e3, t3) {
          return Array.from(e3.querySelectorAll(".magicfeedback-input")).filter(((e4) => e4.name === t3)).find(((e4) => "radio" === e4.type || "checkbox" === e4.type ? e4.checked : "" !== e4.value)) || null;
        };
      }, 4069: (e2, t2) => {
        "use strict";
        function i(e3) {
          if (!e3) return null;
          const i2 = e3.querySelector(".magicfeedback-div");
          if (!i2) return null;
          const n = i2.querySelector('input:not([type="hidden"]), textarea, select, button');
          if (!n) return null;
          const r = n;
          return r.disabled || r.readOnly ? null : "TEXTAREA" === n.tagName || "INPUT" === n.tagName && t2.AUTOFOCUS_INPUT_TYPES.includes(n.type) ? r : null;
        }
        Object.defineProperty(t2, "__esModule", { value: true }), t2.focusFirstTextQuestion = t2.findAutofocusTarget = t2.AUTOFOCUS_INPUT_TYPES = void 0, t2.AUTOFOCUS_INPUT_TYPES = ["text", "email", "number", "tel", "url", "search"], t2.findAutofocusTarget = i, t2.focusFirstTextQuestion = function(e3) {
          var t3, n;
          if (!e3) return false;
          const r = i(e3);
          if (!r) return false;
          const o = null === (t3 = e3.ownerDocument) || void 0 === t3 ? void 0 : t3.activeElement;
          if (o && !e3.contains(o) && (function(e4) {
            const t4 = e4.tagName;
            return "INPUT" === t4 || "TEXTAREA" === t4 || "SELECT" === t4 || true === e4.isContentEditable;
          })(o)) return false;
          try {
            r.focus({ preventScroll: true });
          } catch (e4) {
            r.focus();
          }
          return (null === (n = e3.ownerDocument) || void 0 === n ? void 0 : n.activeElement) === r;
        };
      }, 9089: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.armGhostTapGuard = t2.GHOST_TAP_GUARD_MS = void 0, t2.GHOST_TAP_GUARD_MS = 400;
        const i = /* @__PURE__ */ new WeakMap();
        t2.armGhostTapGuard = function(e3) {
          e3 && (i.has(e3) || e3.addEventListener("click", ((r) => {
            var o;
            0 !== r.detail && (n() - (null !== (o = i.get(e3)) && void 0 !== o ? o : -1 / 0) >= t2.GHOST_TAP_GUARD_MS || (r.preventDefault(), r.stopPropagation()));
          }), true), i.set(e3, n()));
        };
        const n = () => "undefined" != typeof performance ? performance.now() : Date.now();
      }, 4070: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.Log = void 0, t2.Log = class {
          constructor(e3) {
            this.config = e3;
          }
          log(...e3) {
            this.config.get("debug") && console.log("[MagicFeedback]:", ...e3);
          }
          err(...e3) {
            console.error("[MagicFeedback]:", ...e3);
          }
        };
      }, 8330: (e2) => {
        "use strict";
        e2.exports = JSON.parse('{"name":"@magicfeedback/native","version":"2.2.37","main":"./dist/magicfeedback-sdk.node.js","browser":"./dist/magicfeedback-sdk.browser.js","types":"./dist/types/src/index.d.ts","repository":{"type":"git","url":"git+ssh://git@github.com/MagicFeedback/magicfeedback-sdk.git"},"author":"farias@magicfeedback.io","license":"MIT","private":false,"scripts":{"dev":"vite","build":"webpack","build:watch":"webpack --watch --mode development","release":"npm publish --access public","release:beta":"npm publish --access public --tag beta","release:alpha":"npm publish --access public --tag alpha","test":"jest","test:watch":"jest --watchAll","coverage":"jest --coverage","publish:sdk":"bash publish.sh","publish:sdk:dry-run":"NPM_DRY_RUN=1 bash publish.sh"},"files":["dist"],"devDependencies":{"@babel/preset-typescript":"^7.22.5","@types/node":"^17.0.21","@types/webpack":"^5.28.0","@types/webpack-node-externals":"^2.5.3","c8":"^7.11.0","copy-webpack-plugin":"^11.0.0","jest":"^29.5.0","jest-environment-jsdom":"^29.5.0","jest-fetch-mock":"^3.0.3","nock":"^13.2.4","ts-jest":"^29.1.0","ts-loader":"^9.2.7","ts-node":"^10.7.0","typescript":"^4.6.2","vite":"^2.8.0","vite-plugin-dts":"^0.9.9","webpack":"^5.70.0","webpack-cli":"^4.9.2","webpack-node-externals":"^3.0.0"},"dependencies":{"cross-fetch":"^3.1.5","is-bundling-for-browser-or-node":"^1.1.1"},"description":"MagicFeedbackAI JavaScript Library for [MagicFeedback.io](https://magicfeedback.io/)","bugs":{"url":"https://github.com/MagicFeedback/magicfeedback-sdk/issues"},"homepage":"https://github.com/MagicFeedback/magicfeedback-sdk#readme","directories":{"example":"examples","test":"test"},"style":"./dist/styles/magicfeedback-default.css"}');
      } }, t = {}, (function i(n) {
        var r = t[n];
        if (void 0 !== r) return r.exports;
        var o = t[n] = { exports: {} };
        return e[n].call(o.exports, o, o.exports, i), o.exports;
      })(1422).default;
      var e, t;
    }));
  }
});

// src/ui/logo.ts
var BASE_CSS = "max-height:40px; max-width:100%; object-fit:contain; display:block; margin:12px 0 0 0;";
var MAX_HEIGHT = {
  small: "30px",
  medium: "50px",
  large: "70px"
};
function insertPopupLogo(parent, anchor, style, id) {
  if (!style?.logo) return null;
  if (parent.ownerDocument.getElementById(id)) return null;
  const img = parent.ownerDocument.createElement("img");
  img.id = id;
  img.src = style.logo;
  img.alt = "Logo";
  img.style.cssText = BASE_CSS;
  if (style.logoSize && MAX_HEIGHT[style.logoSize]) {
    img.style.maxHeight = MAX_HEIGHT[style.logoSize];
  }
  switch (style.logoPosition) {
    case "left":
      img.style.margin = "12px 0 0 0";
      img.style.setProperty("margin-inline-start", "0");
      img.style.setProperty("margin-inline-end", "16px");
      break;
    case "right":
      img.style.margin = "12px 0 0 0";
      img.style.setProperty("margin-inline-start", "auto");
      img.style.setProperty("margin-inline-end", "0");
      break;
    case "center":
      img.style.margin = "12px auto 0 auto";
      break;
  }
  parent.insertBefore(img, anchor);
  return img;
}

// src/ui/renderPopup.ts
var import_native = __toESM(require_magicfeedback_sdk_browser());
function ensureStyle(id, css, nonce) {
  let el = document.getElementById(id);
  if (el && nonce && el.getAttribute("nonce") !== nonce) {
    el.remove();
    el = null;
  }
  if (!el) {
    el = document.createElement("style");
    el.id = id;
    if (nonce) el.setAttribute("nonce", nonce);
    el.textContent = css;
    document.head.appendChild(el);
  } else if (el.textContent !== css) {
    el.textContent = css;
  }
  return el;
}
function ensureMagicFeedbackStyles(nonce) {
  ensureStyle("magicfeedback-sdk-styles", style_default, nonce);
}
var SURVEY_ALIGNMENT_STYLE_ID = "deepdots-survey-alignment";
function ensureSurveyAlignmentStyles(nonce) {
  ensureStyle(SURVEY_ALIGNMENT_STYLE_ID, `
    .deepdots-popup .magicfeedback-container,
    .deepdots-popup .magicfeedback-form,
    .deepdots-popup .magicfeedback-div { padding-left: 0; padding-right: 0; }
  `, nonce);
}
function ensureSpinnerStyles(nonce) {
  ensureStyle("deepdots-spinner-styles", `
    /* El enunciado trae margin-top:20px del CSS de surveys, que sumaba al hueco de la barra
       de progreso y descompensaba la simetr\xEDa. Solo se anula en el primero: entre preguntas
       de la misma p\xE1gina sigue separando. */
    .deepdots-popup .magicfeedback-questions .magicfeedback-div:first-child .magicfeedback-label { margin-top: 0; }
    @keyframes ddspin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    .mf-spinner { display:flex; justify-content:center; align-items:center; padding:8px 0; }
    .mf-spinner-circle { width:28px; height:28px; border:3px solid #e0e6ed; border-top-color:#1E293B; border-radius:50%; animation: ddspin 0.9s linear infinite; }
  `, nonce);
}
function ensureResponsiveStyles(nonce) {
  ensureStyle("deepdots-responsive-styles", `
    /* Responsive adjustments */
    @media (max-width: 640px) {
      .deepdots-popup {
        width: calc(100% - 24px) !important;
        max-width: calc(100% - 24px) !important;
        height: auto !important;
        max-height: 90vh !important;
        border-radius: 12px !important;
        padding: calc(16px + env(safe-area-inset-top)) 16px calc(16px + env(safe-area-inset-bottom)) 16px !important;
        box-sizing: border-box;
      }
      .deepdots-popup .mf-spinner-circle { width: 32px; height: 32px; border-width: 4px; }
      .deepdots-popup button { font-size: 16px !important; }
      .deepdots-popup-header button { width:48px; height:48px; }
      .deepdots-popup-header button svg { width:26px; height:26px; }
      /* Apilados en el orden del DOM: la acci\xF3n principal (Send/Start/Complete) arriba y
         Back debajo. */
      .deepdots-popup-footer { flex-direction: column !important; gap: 4px !important; }
      .deepdots-popup-footer button { width: 100%; }
    }
    @media (max-width: 400px) {
      .deepdots-popup { padding: calc(12px + env(safe-area-inset-top)) 12px calc(12px + env(safe-area-inset-bottom)) 12px !important; }
      .deepdots-popup-header button { width:48px; height:48px; }
      .deepdots-popup-header button svg { width:26px; height:26px; }
    }
    @media (orientation: landscape) and (max-height: 480px) {
      .deepdots-popup {
        height: 100vh !important;
        max-height: 100vh !important;
        overflow-y: auto !important;
      }
    }
  `, nonce);
}
function ensureCustomCss(css, nonce) {
  const STYLE_ID = "deepdots-custom-css";
  if (!css) {
    document.getElementById(STYLE_ID)?.remove();
    return;
  }
  document.head.appendChild(ensureStyle(STYLE_ID, css, nonce));
}
function ensureFontFace(family, url, nonce) {
  const css = buildFontFaceCss(family, url);
  if (!css) return;
  ensureStyle("deepdots-font-face", css, nonce);
}
function hasFinePointer() {
  return typeof window !== "undefined" && typeof window.matchMedia === "function" && window.matchMedia("(pointer: fine)").matches;
}
async function renderPopup(container, surveyId, productId, actions, emit, onClose, env = "production", userId, style, sessionId, miniService, analyticsFeedbackSessionId, options) {
  let surveyCompletedEmitted = false;
  let stylesInjected = false;
  let pageDepth = 0;
  let onStartPage = false;
  const cspNonce = options?.cspNonce?.trim() || void 0;
  let labels = getLabels(options?.language);
  let actionLabels = resolveActionLabels(actions, options?.language);
  let direction = directionFor(options?.language);
  const isDark = style?.theme === "dark";
  const theme = {
    popupBg: isDark ? "#1e1e1e" : "#fff",
    // El popup fija su propio fondo, así que debe fijar también el esquema de color.
    // Sin esto los controles de formulario (input/textarea/select) caen al estilo por
    // defecto del navegador: en un host con `prefers-color-scheme: dark` se pintan
    // oscuros con texto blanco sobre el fondo claro del popup.
    colorScheme: isDark ? "dark" : "light",
    textPrimary: isDark ? "#f0f0f0" : "#111",
    closeBtnHoverColor: isDark ? "#fff" : "#000000",
    textMuted: isDark ? "#9ca3af" : "#6b7280",
    progressTrack: isDark ? "#3f3f46" : "#e5e7eb"
  };
  const positionMap = {
    "center": { justifyContent: "center", alignItems: "center", background: "rgba(0,0,0,0.5)" },
    "bottom": { justifyContent: "center", alignItems: "flex-end", padding: "16px", background: "transparent" },
    "bottom-right": { justifyContent: "flex-end", alignItems: "flex-end", padding: "16px", background: "transparent" },
    "bottom-left": { justifyContent: "flex-start", alignItems: "flex-end", padding: "16px", background: "transparent" },
    "top": { justifyContent: "center", alignItems: "flex-start", padding: "16px", background: "transparent" },
    "top-right": { justifyContent: "flex-end", alignItems: "flex-start", padding: "16px", background: "transparent" },
    "top-left": { justifyContent: "flex-start", alignItems: "flex-start", padding: "16px", background: "transparent" }
  };
  const pos = positionMap[style?.position ?? "center"] ?? positionMap["center"];
  const passThrough = pos.background === "transparent";
  const popup = document.createElement("div");
  popup.id = "dd-popup";
  popup.className = "deepdots-popup";
  popup.setAttribute("dir", direction);
  popup.style.cssText = `
      position: relative;
      pointer-events: auto;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      background: ${theme.popupBg};
      color-scheme: ${theme.colorScheme};
      border-radius: 8px;
      padding: 24px;
      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
      max-width: 600px;
      width: 90%;
      max-height: 90vh;
      min-height: 200px;
    `;
  const font = style?.font;
  if (font?.family) {
    const familyValue = buildFontFamilyValue(font.family);
    popup.style.fontFamily = familyValue;
    popup.style.setProperty("--deepdots-font", familyValue);
    popup.classList.add("deepdots-has-font");
    if (font.url) ensureFontFace(font.family, font.url, cspNonce);
  }
  const header = document.createElement("div");
  header.className = "deepdots-popup-header";
  header.style.cssText = "display:flex; justify-content:space-between; align-items:center; gap:12px; width:100%; flex:0 0 auto;";
  const titleEl = document.createElement("h2");
  titleEl.id = "dd-title";
  titleEl.className = "deepdots-popup-title";
  titleEl.style.cssText = `margin:0; font-size:17px; font-weight:600; line-height:1.3; color:${theme.textPrimary}; text-transform:none; text-align:start; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;`;
  titleEl.hidden = true;
  const setTitle = (value) => {
    if (!value) return;
    titleEl.textContent = value;
    titleEl.hidden = false;
  };
  setTitle(options?.title);
  header.appendChild(titleEl);
  const closeBtn = document.createElement("button");
  closeBtn.id = "dd-close";
  closeBtn.type = "button";
  closeBtn.setAttribute("aria-label", labels.closeAria);
  closeBtn.innerHTML = `
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M5 5L19 19M5 19L19 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="butt"/>
      </svg>
    `;
  closeBtn.style.cssText = `
      background:transparent;
      border:none;
      width:32px;
      height:32px;
      display:flex;
      align-items:center;
      justify-content:center;
      border-radius: 8px;
      cursor:pointer;
      color:${theme.textPrimary};
      padding:4px;
      transition: color .15s ease, transform .15s ease;
      box-shadow: none !important;
    `;
  closeBtn.onmouseenter = () => {
    closeBtn.style.color = theme.closeBtnHoverColor;
    closeBtn.style.transform = "scale(1.06)";
  };
  closeBtn.onmouseleave = () => {
    closeBtn.style.color = theme.textPrimary;
    closeBtn.style.transform = "scale(1)";
  };
  const closeFromChrome = () => {
    emit("popup_clicked", surveyId, { action: "close_icon" });
    onClose();
  };
  closeBtn.onclick = closeFromChrome;
  closeBtn.style.flex = "0 0 auto";
  closeBtn.style.marginLeft = "auto";
  header.appendChild(closeBtn);
  let progressEnabled = options?.showProgressBar === true;
  let progressShowUnit = true;
  let progressUnit = "fraction";
  const progressEl = document.createElement("div");
  progressEl.id = "dd-progress";
  progressEl.className = "deepdots-progress";
  progressEl.style.cssText = "display:none; flex-direction:column; gap:8px; width:100%; flex:0 0 auto; padding:16px 0; box-sizing:border-box;";
  const progressHead = document.createElement("div");
  progressHead.className = "deepdots-progress-head";
  progressHead.style.cssText = "display:flex; flex-direction:row; justify-content:space-between; align-items:center; width:100%; gap:8px;";
  const progressLabel = document.createElement("span");
  progressLabel.id = "dd-progress-label";
  progressLabel.style.cssText = "font-size:13px; line-height:1.2;";
  const progressCurrent = document.createElement("span");
  progressCurrent.id = "dd-progress-current";
  progressCurrent.style.cssText = `font-weight:700; color:${theme.textPrimary};`;
  const progressTotal = document.createElement("span");
  progressTotal.id = "dd-progress-total";
  progressTotal.style.cssText = `font-weight:400; color:${theme.textMuted};`;
  progressLabel.appendChild(progressCurrent);
  progressLabel.appendChild(progressTotal);
  const progressFollowUp = document.createElement("span");
  progressFollowUp.id = "dd-progress-followup";
  progressFollowUp.textContent = labels.followUp;
  progressFollowUp.style.cssText = "display:none; font-size:12px; font-weight:600; color:#fff; background:rgba(59,130,246,0.44); border-radius:999px; padding:2px 10px;";
  progressHead.appendChild(progressLabel);
  progressHead.appendChild(progressFollowUp);
  const progressTrack = document.createElement("div");
  progressTrack.className = "deepdots-progress-track";
  progressTrack.style.cssText = `width:100%; height:4px; border-radius:999px; background:${theme.progressTrack}; overflow:hidden;`;
  const progressBar = document.createElement("div");
  progressBar.id = "dd-progress-bar";
  progressBar.style.cssText = "height:100%; width:0%; background:#22C55E; border-radius:999px; transition:width 450ms ease;";
  progressTrack.appendChild(progressBar);
  progressEl.appendChild(progressHead);
  progressEl.appendChild(progressTrack);
  function updateProgress(p) {
    const total = typeof p.total === "number" ? p.total : 0;
    const progress = typeof p.progress === "number" ? p.progress : 0;
    if (!progressEnabled || onStartPage || p.completed || total <= 1) {
      progressEl.style.display = "none";
      containerContent.style.paddingTop = "16px";
      return;
    }
    progressEl.style.display = "flex";
    containerContent.style.paddingTop = "0";
    const current = Math.min(total, Math.max(1, progress + 1));
    const pct = Math.min(100, Math.max(0, current / total * 100));
    progressBar.style.width = `${pct}%`;
    const label = Math.min(total, Math.max(1, Math.floor(progress) + 1));
    progressLabel.style.display = progressShowUnit ? "block" : "none";
    if (progressUnit === "percentage") {
      progressCurrent.textContent = `${Math.round(pct)}%`;
      progressTotal.textContent = "";
    } else {
      progressCurrent.textContent = `${labels.question} ${label}`;
      progressTotal.textContent = ` ${labels.of} ${total}`;
    }
    progressFollowUp.style.display = p.followup ? "inline-block" : "none";
  }
  ensureMagicFeedbackStyles(cspNonce);
  ensureSurveyAlignmentStyles(cspNonce);
  ensureSpinnerStyles(cspNonce);
  ensureResponsiveStyles(cspNonce);
  ensureCustomCss(options?.surveyCss, cspNonce);
  const containerContent = document.createElement("div");
  containerContent.id = "dd-content";
  containerContent.className = "deepdots-popup-container-content";
  containerContent.style.cssText = "display:flex; flex-direction:column; flex:1 1 auto; min-height:0; padding:16px 0 0 0; overflow:hidden;";
  const main = document.createElement("div");
  main.id = "dd-main";
  main.className = "deepdots-popup-main";
  main.style.cssText = "display:flex; flex-direction:column; width:100%; flex:1 1 auto; min-height:0; overflow-y:auto;";
  const formWrapper = document.createElement("div");
  formWrapper.id = "dd-form-wrapper";
  formWrapper.style.cssText = "width:100%; flex: 1 1 auto;";
  const errorHint = document.createElement("div");
  errorHint.id = "dd-error";
  errorHint.className = "deepdots-error-hint";
  errorHint.style.cssText = `
      display: none;
      margin: 12px 0 0 0;
      padding: 10px 12px;
      border-radius: 6px;
      background: #FEF3C7; /* amber-100 */
      color: #92400E; /* amber-700 */
      border: 1px solid #FCD34D; /* amber-300 */
      font-size: 13px;
    `;
  errorHint.setAttribute("role", "alert");
  errorHint.setAttribute("aria-live", "polite");
  const spinnerEl = document.createElement("div");
  spinnerEl.className = "mf-spinner";
  spinnerEl.setAttribute("role", "status");
  spinnerEl.setAttribute("aria-label", labels.loadingAria);
  spinnerEl.innerHTML = '<div class="mf-spinner-circle"></div>';
  spinnerEl.style.cssText = "position:absolute; top:50%; left:50%; transform:translate(-50%,-50%);";
  const formDivId = `magicfeedback-form-${surveyId}`;
  const formHost = document.createElement("div");
  formHost.id = formDivId;
  formHost.style.cssText = "width:100%; visibility:hidden;";
  formWrapper.appendChild(spinnerEl);
  formWrapper.appendChild(formHost);
  main.appendChild(formWrapper);
  const loadErrorEl = document.createElement("div");
  loadErrorEl.id = "dd-load-error";
  loadErrorEl.className = "deepdots-load-error";
  loadErrorEl.setAttribute("role", "alert");
  loadErrorEl.style.cssText = `display:none; width:100%; text-align:center; padding:24px 0; font-size:15px; color:${theme.textPrimary};`;
  main.appendChild(loadErrorEl);
  main.appendChild(errorHint);
  const footer = document.createElement("div");
  footer.id = "dd-footer";
  footer.className = "deepdots-popup-footer";
  footer.setAttribute("data-actions-wrapper", "true");
  footer.style.cssText = "display:flex; flex-direction: row-reverse ;justify-content:space-between; align-items:center; gap:4px; margin-top:auto; width:100%; padding-top:12px;";
  const backButton = document.createElement("button");
  backButton.id = "dd-back";
  backButton.className = "dd-nav-btn";
  backButton.textContent = actionLabels.back;
  backButton.style.cssText = `
      background: transparent;
      color: ${theme.textMuted};
      border: none;
      min-height: 44px;
      padding: 12px 24px;
      border-radius: 999px; /* p\xEDldora, como el Button de Material3 en KMP */
      cursor: pointer;
      font-size: 15px;
      font-weight: 600;
      transition: filter .15s ease;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      text-align: center;
    `;
  backButton.onmouseenter = () => {
    backButton.style.filter = "brightness(0.9)";
  };
  backButton.onmouseleave = () => {
    backButton.style.filter = "brightness(1)";
  };
  backButton.onclick = () => {
    emit("popup_clicked", surveyId, { action: "back" });
    formInstance?.back?.();
  };
  const startButton = document.createElement("button");
  startButton.id = "dd-start";
  startButton.className = "dd-nav-btn";
  startButton.textContent = actionLabels.start;
  startButton.style.cssText = `
      background: #1E293B;
      color: #fff;
      border: none;
      min-height: 44px;
      padding: 12px 24px;
      border-radius: 999px; /* p\xEDldora, como el Button de Material3 en KMP */
      cursor: pointer;
      font-size: 15px;
      font-weight: 600;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      transition: filter .15s ease;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      text-align: center;
    `;
  startButton.onclick = () => {
    emit("popup_clicked", surveyId, { action: "start_survey" });
    formInstance?.startForm?.();
    onStartPage = false;
    updateProgress({ progress: formInstance?.progress, total: formInstance?.total });
  };
  const closeButton = document.createElement("button");
  closeButton.id = "dd-complete";
  closeButton.className = "dd-nav-btn";
  closeButton.textContent = actionLabels.complete;
  closeButton.style.cssText = `
      background: #1E293B;
      color: #fff;
      border: none;
      min-height: 44px;
      padding: 12px 24px;
      border-radius: 999px; /* p\xEDldora, como el Button de Material3 en KMP */
      cursor: pointer;
      font-size: 15px;
      font-weight: 600;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      transition: filter .15s ease;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      text-align: center;
    `;
  closeButton.onmouseenter = () => {
    closeButton.style.filter = "brightness(0.9)";
  };
  closeButton.onmouseleave = () => {
    closeButton.style.filter = "brightness(1)";
  };
  closeButton.onclick = () => {
    emit("popup_clicked", surveyId, { action: "complete" });
    onClose();
  };
  const submitButton = document.createElement("button");
  submitButton.id = "dd-submit";
  submitButton.className = "dd-nav-btn";
  submitButton.textContent = actionLabels.accept;
  submitButton.style.cssText = `
      background: #1E293B;
      color: #fff;
      border: none;
      min-height: 44px;
      padding: 12px 24px;
      border-radius: 999px; /* p\xEDldora, como el Button de Material3 en KMP */
      cursor: pointer;
      font-size: 15px;
      font-weight: 600;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      transition: filter .15s ease;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      text-align: center;
    `;
  const cancelButton = document.createElement("button");
  cancelButton.id = "dd-cancel";
  cancelButton.type = "button";
  cancelButton.className = "dd-nav-btn";
  cancelButton.textContent = actionLabels.decline;
  cancelButton.style.cssText = submitButton.style.cssText;
  cancelButton.onclick = closeFromChrome;
  submitButton.onclick = () => {
    if (!surveyCompletedEmitted) {
      emit("popup_clicked", surveyId, { action: "manual_send" });
      formInstance?.send?.();
    }
  };
  function applyLabels(lang) {
    labels = getLabels(lang);
    actionLabels = resolveActionLabels(actions, lang);
    backButton.textContent = actionLabels.back;
    startButton.textContent = actionLabels.start;
    closeButton.textContent = actionLabels.complete;
    submitButton.textContent = actionLabels.accept;
    cancelButton.textContent = actionLabels.decline;
    loadErrorEl.textContent = labels.errorLoad;
    closeBtn.setAttribute("aria-label", labels.closeAria);
    spinnerEl.setAttribute("aria-label", labels.loadingAria);
    progressFollowUp.textContent = labels.followUp;
    direction = directionFor(lang);
    popup.setAttribute("dir", direction);
  }
  backButton.style.display = "none";
  startButton.style.display = "none";
  submitButton.style.display = "none";
  closeButton.style.display = "none";
  cancelButton.style.display = "none";
  footer.appendChild(submitButton);
  footer.appendChild(backButton);
  footer.appendChild(closeButton);
  footer.appendChild(startButton);
  footer.appendChild(cancelButton);
  containerContent.appendChild(main);
  footer.style.flex = "0 0 auto";
  containerContent.appendChild(footer);
  function updateButtons(state) {
    backButton.style.display = "none";
    startButton.style.display = "none";
    submitButton.style.display = "none";
    closeButton.style.display = "none";
    cancelButton.style.display = "none";
    backButton.style.width = "";
    startButton.style.width = "";
    submitButton.style.width = "";
    closeButton.style.width = "";
    switch (state) {
      case "loading":
        break;
      case "start":
        startButton.style.display = "inline-flex";
        startButton.style.width = "100%";
        break;
      case "in_progress_first":
        submitButton.style.display = "inline-flex";
        submitButton.style.width = "";
        setLoading(false);
        break;
      case "in_progress_next":
        backButton.style.display = "inline-flex";
        submitButton.style.display = "inline-flex";
        setLoading(false);
        break;
      case "completed":
        closeButton.style.display = "inline-flex";
        closeButton.style.width = "100%";
        setLoading(false);
        break;
      case "error":
        setLoading(false);
        break;
      case "load_error":
        cancelButton.style.display = "inline-flex";
        break;
    }
  }
  function updateNavButtons() {
    updateButtons(pageDepth > 0 ? "in_progress_next" : "in_progress_first");
  }
  let successMessageHtml = "";
  function showSuccessScreen() {
    progressEl.style.display = "none";
    formWrapper.style.display = "none";
    let done = main.querySelector(".deepdots-success");
    if (!done) {
      done = document.createElement("div");
      done.className = "deepdots-success";
      done.style.cssText = `width:100%; text-align:center; padding:24px 0; color:${theme.textPrimary};`;
      main.insertBefore(done, errorHint);
    }
    done.innerHTML = successMessageHtml || "<p>Thank you for your feedback!</p>";
    done.querySelectorAll("img").forEach((img) => {
      img.style.cssText = "max-width:100%; height:auto; margin:0 auto 16px auto; display:block;";
    });
  }
  let loadFailed = false;
  function showLoadError(reason) {
    sdkWarn("[Deepdots] survey failed to load:", reason);
    if (loadFailed) return;
    loadFailed = true;
    progressEl.style.display = "none";
    formWrapper.style.display = "none";
    errorHint.style.display = "none";
    loadErrorEl.textContent = labels.errorLoad;
    loadErrorEl.style.display = "block";
    setLoading(false);
    updateButtons("load_error");
    reveal();
  }
  popup.appendChild(header);
  popup.appendChild(progressEl);
  popup.appendChild(containerContent);
  container.innerHTML = "";
  container.appendChild(popup);
  container.style.display = "flex";
  container.style.visibility = "hidden";
  container.style.pointerEvents = "none";
  container.style.justifyContent = pos.justifyContent;
  container.style.alignItems = pos.alignItems;
  container.style.background = pos.background;
  if (pos.padding) container.style.padding = pos.padding;
  let revealed = false;
  let revealTimer = null;
  let surveyLoaded = false;
  let openFocusDone = false;
  function autofocusOnOpen() {
    if (openFocusDone || !revealed || !surveyLoaded) return;
    openFocusDone = true;
    if (hasFinePointer()) formInstance?.focusFirstQuestion?.();
  }
  function reveal() {
    if (revealed) return;
    revealed = true;
    if (revealTimer !== null) {
      clearTimeout(revealTimer);
      revealTimer = null;
    }
    if (!container.contains(popup)) return;
    container.style.visibility = "visible";
    container.style.pointerEvents = passThrough ? "none" : "";
    autofocusOnOpen();
  }
  function revealWhenPainted2() {
    if (revealed) return;
    revealWhenPainted(popup, reveal);
  }
  revealTimer = setTimeout(reveal, REVEAL_TIMEOUT_MS);
  function setLoading(isLoading) {
    spinnerEl.style.display = isLoading ? "flex" : "none";
    setSurveyBusy(formWrapper, isLoading);
    if (!isLoading) {
      formHost.style.visibility = "visible";
      revealWhenPainted2();
    }
    footer.style.display = isLoading ? "none" : "flex";
    backButton.disabled = isLoading;
    startButton.disabled = isLoading;
    closeButton.disabled = isLoading;
    submitButton.disabled = isLoading;
    submitButton.style.opacity = isLoading ? "0.6" : "1";
    submitButton.style.cursor = isLoading ? "not-allowed" : "pointer";
    if (isLoading) {
      updateButtons("loading");
    }
  }
  setLoading(true);
  if (typeof window === "undefined" || typeof document === "undefined") {
    return;
  }
  let formInstance = null;
  try {
    if (!import_native.default || typeof import_native.default.form !== "function") {
      sdkWarn("[MagicFeedback] form() no disponible. Fallback manual.");
      showLoadError("form() not available");
      return;
    }
    import_native.default.init(
      {
        debug: true,
        env: env === "production" ? "prod" : "dev"
      }
    );
    const { profile, metadata } = buildSurveyIdentity(userId ?? null, sessionId ?? null, miniService ?? null, analyticsFeedbackSessionId ?? null);
    formInstance = import_native.default.form(surveyId, productId, profile, metadata);
    const generateOptions = {
      addButton: false,
      getMetaData: true,
      // La pantalla final la pinta el popup: `renderSuccess` de @magicfeedback/native usa
      // textContent, así que el mensaje de la plataforma (HTML con imagen) no se vería, y
      // su fallback es un literal genérico que ignora `style.successMessage`.
      addSuccessScreen: false,
      // Surveys multi-idioma: native pide a la API este idioma (el del init o el del
      // dispositivo) y, si el survey no lo tiene, la API sirve el idioma por defecto.
      lang: options?.language,
      // Foco en la primera pregunta de escribir tras Start, Siguiente o Atrás. Native lo
      // aplica después de afterSubmitEvent/onBackEvent, cuando `setLoading(false)` ya ha
      // quitado el `inert`. La apertura va aparte (ver autofocusOnOpen).
      autofocus: "navigation"
    };
    generateOptions.onLoadedEvent = ({ formData, lang, error }) => {
      if (error) {
        showLoadError(error);
        return;
      }
      const shownLang = typeof lang === "string" && lang.trim().length > 0 ? lang : void 0;
      const surveyLang = shownLang ?? (Array.isArray(formData?.lang) ? formData.lang.find((l) => typeof l === "string" && l.trim().length > 0) : void 0);
      if (surveyLang) applyLabels(surveyLang);
      try {
      } catch {
      }
      const s = formData?.style;
      if (s && !stylesInjected) {
        stylesInjected = true;
        if (s.successMessage) successMessageHtml = s.successMessage;
        if (options?.showProgressBar === void 0) progressEnabled = s.showProgressBar === true;
        if (s.showProgressUnit !== void 0) progressShowUnit = s.showProgressUnit !== false;
        if (s.progressUnit) progressUnit = s.progressUnit;
        if (s.loadingBarColor) {
          progressBar.style.background = s.loadingBarColor;
          progressFollowUp.style.background = s.loadingBarColor;
        }
        if (s.boxBackgroundColor) {
          popup.style.background = s.boxBackgroundColor;
        }
        if (s.contentAlign) {
          main.style.justifyContent = s.contentAlign === "center" ? "center" : "flex-start";
        }
        applySurveyPrimaryColor(popup, s);
        if (s.buttonPrimaryColor) {
          submitButton.style.background = s.buttonPrimaryColor;
          submitButton.style.border = "none";
          submitButton.style.color = "#fff";
          startButton.style.background = s.buttonPrimaryColor;
          startButton.style.border = "none";
          startButton.style.color = "#fff";
          closeButton.style.background = s.buttonPrimaryColor;
          closeButton.style.border = "none";
          closeButton.style.color = "#fff";
        }
        if (s.buttonSecondaryColor) {
          backButton.style.background = "transparent";
          backButton.style.color = s.buttonSecondaryColor;
          backButton.style.border = "none";
        }
        insertPopupLogo(popup, progressEl, s, "deepdots-popup-logo");
        if (s.startMessage && s.startMessage !== "") {
          sdkLog(s.startMessage);
          onStartPage = true;
          updateButtons("start");
        } else {
          updateButtons("in_progress_first");
        }
      } else {
        updateButtons("in_progress_first");
      }
      updateProgress({ progress: formInstance.progress, total: formInstance.total });
      setLoading(false);
      if (!surveyLoaded) {
        surveyLoaded = true;
        autofocusOnOpen();
      }
    };
    let lastReportedError = null;
    generateOptions.beforeSubmitEvent = () => {
      setLoading(true);
    };
    generateOptions.afterSubmitEvent = ({ error, completed, total, progress, followup }) => {
      if (error) {
        setLoading(false);
        const { reason, message } = classifySubmitError(error);
        if (reason === "required") {
          errorHint.textContent = labels.errorRequired;
          errorHint.style.display = "block";
          updateNavButtons();
          return;
        }
        errorHint.textContent = labels.errorSubmit;
        errorHint.style.display = "block";
        sdkWarn("[Deepdots] survey submit error:", reason, message);
        if (error !== lastReportedError) {
          lastReportedError = error;
          emit("survey_error", surveyId, { reason, message });
        }
        return;
      }
      errorHint.style.display = "none";
      setLoading(false);
      if (completed) {
        emit("survey_completed", surveyId, { action: "completed" });
        surveyCompletedEmitted = true;
        showSuccessScreen();
        updateButtons("completed");
        updateProgress({ progress, total, completed: true });
        return;
      }
      emit("popup_clicked", surveyId, { action: "partial" });
      pageDepth++;
      updateNavButtons();
      updateProgress({ progress, total, followup });
    };
    generateOptions.onBackEvent = ({ progress, error, followup }) => {
      if (!error) pageDepth = Math.max(0, pageDepth - 1);
      updateNavButtons();
      updateProgress({ progress, total: formInstance.total, followup });
    };
    formInstance.generate(formDivId, generateOptions).catch((err) => {
      sdkError("[MagicFeedback] Error generating form:", err);
      showLoadError(err);
    });
  } catch (e) {
    sdkError("[MagicFeedback] Exception initializing form:", e);
    showLoadError(e);
  }
}
export {
  REVEAL_TIMEOUT_MS,
  SURVEY_ALIGNMENT_STYLE_ID,
  renderPopup
};
//# sourceMappingURL=renderPopup-BKZPAZZG.mjs.map